package com.example.gameboost

import android.content.Context
import android.hardware.display.DisplayManager
import android.view.Display

object Shell {
    fun ready() = AeroAccess.state == AeroAccess.State.Ready

    fun run(cmd: String): String = try {
        val (code, out) = AeroAccess.run(cmd)
        val t = out.trim()
        if (code != 0) "exit $code: $t" else t.ifEmpty { "OK" }
    } catch (e: Throwable) { "Error: ${e.message}" }
}

object Boost {
    fun gameMode(pkg: String, mode: Int = 2) = Shell.run("cmd game set --mode $mode --user 0 ${AeroAccess.sq(pkg)}")
    /**
     * Performance mode (the toggle on the Performance card). Everything is done with shell commands and is reversible:
     * battery saver off, highest supported refresh rate, "performance" game mode for the game,
     * fixed-performance mode (Android 12+, keeps clocks from dropping), and idle background apps trimmed.
     * Settings are saved first, so perfOff puts the phone back exactly as it was.
     */
    fun perfOn(ctx: Context, game: String): String {
        SettingsBackup.save(Keys.PERF + Keys.REFRESH)
        val steps = ArrayList<String>()
        fun ok(r: String) = !(r.startsWith("exit ") || r.startsWith("Error:"))
        if (ok(Shell.run("settings put global low_power 0"))) steps += "battery saver off"
        supportedRates(ctx).maxOrNull()?.let { if (ok(refreshRate(it))) steps += "$it Hz" }
        if (game.isNotBlank() && ok(gameMode(game, 2))) steps += "game mode"
        if (ok(Shell.run("cmd power set-fixed-performance-mode-enabled true"))) steps += "fixed performance"
        killBackground()
        steps += "background trimmed"
        return steps.joinToString(", ")
    }

    /** Undo perfOn: saved settings come back, fixed-performance mode off, game back to the standard game mode. */
    fun perfOff(game: String): String {
        Shell.run("cmd power set-fixed-performance-mode-enabled false")
        if (game.isNotBlank()) gameMode(game, 1)
        return SettingsBackup.restore(Keys.PERF + Keys.REFRESH)
    }

    fun compileSpeed(pkg: String) = Shell.run("cmd package compile -m speed -f ${AeroAccess.sq(pkg)}")
    /** Apps the user chose in Settings > Tools > "Protected apps" (never force-stopped). */
    fun protectedApps(ctx: Context): Set<String> =
        (ctx.getSharedPreferences("games", Context.MODE_PRIVATE).getString("keepApps", "") ?: "")
            .split(",").filter { it.isNotBlank() }.toSet()

    /** Parts of the phone that must keep running or the phone itself breaks (always protected). */
    private val ESSENTIAL = Regex(
        "^(android|com\\.android\\.(systemui|phone|server\\.telecom|shell|bluetooth|nfc|settings|stk|" +
        "providers\\..*|inputmethod\\..*|networkstack.*|permissioncontroller|externalstorage|mediaprovider.*|" +
        "documentsui|packageinstaller|location.*|se|managedprovisioning|keychain|certinstaller)|" +
        "com\\.google\\.android\\.(gms|gsf|inputmethod\\..*|permissioncontroller|networkstack.*|ext\\.services|webview)|" +
        "com\\.samsung\\.android\\.(incallui|dialer|app\\.telephonyui|messaging)|" +
        "com\\.miui\\.(home|securitycenter|powerkeeper)|.*\\.(telecom|telephony|incallui)(\\..*)?|" +
        "com\\.qualcomm\\.(qti|telephony)\\..*|vendor\\..*)$")

    /**
     * Force-stops EVERY running app (user apps and system apps) except:
     * the game that was launched, this app + AeroHUB, the apps the user protected in Settings,
     * and the essential system parts (system UI, home screen, keyboard, phone/calls, Google services...).
     * Only apps that really have a running process are stopped, so it is fast.
     */
    fun forceStopAll(ctx: Context, game: String): String {
        val keep = HashSet<String>(protectedApps(ctx))
        keep += ctx.packageName; keep += AeroHub.PKG
        if (game.isNotBlank()) keep += game
        // current home screen + current keyboard
        Regex("([a-zA-Z][\\w]*(?:\\.[\\w]+)+)/").find(Shell.run("cmd package resolve-activity --brief -c android.intent.category.HOME -a android.intent.action.MAIN"))
            ?.groupValues?.get(1)?.let { keep += it }
        Shell.run("settings get secure default_input_method").substringBefore('/').trim().takeIf { it.contains('.') }?.let { keep += it }
        val installed = Shell.run("pm list packages").lines().map { it.removePrefix("package:").trim() }.filter { it.isNotBlank() && !it.startsWith("exit") }.toSet()
        val running = Shell.run("ps -A -o NAME").lines().map { it.trim().substringBefore(':') }.filter { it in installed }.toSet()
        val targets = running.filter { it !in keep && !ESSENTIAL.matches(it) }
        if (targets.isEmpty()) return "nothing to close"
        Shell.run(targets.joinToString("; ") { "am force-stop ${AeroAccess.sq(it)}" })
        return "closed ${targets.size} apps"
    }
    fun killBackground() = Shell.run("am kill-all")
    /** Refresh rates the display really supports (rounded, ascending). Empty if it cannot be read. */
    fun supportedRates(ctx: Context): List<Int> = runCatching {
        val d = (ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).getDisplay(Display.DEFAULT_DISPLAY)
        d.supportedModes.map { Math.round(it.refreshRate) }.filter { it >= 30 }.distinct().sorted()
    }.getOrDefault(emptyList())

    /** hz <= 0 = back to the phone's original (auto) setting. */
    fun refreshRate(hz: Int): String {
        if (hz <= 0) return SettingsBackup.restore(Keys.REFRESH)
        SettingsBackup.save(Keys.REFRESH)
        return Shell.run("settings put system min_refresh_rate $hz; settings put system peak_refresh_rate $hz")
    }
    /** scale == null = back to the phone's original animation scales. */
    fun animations(scale: String?): String {
        if (scale == null) return SettingsBackup.restore(Keys.ANIM)
        SettingsBackup.save(Keys.ANIM)
        return Shell.run(
            "settings put global window_animation_scale $scale; " +
            "settings put global transition_animation_scale $scale; " +
            "settings put global animator_duration_scale $scale"
        )
    }
    /**
     * pct 0..100, 50 = the phone's own values. Higher = faster touch response:
     * touch-and-hold delay 1000ms (0%) .. 150ms (100%), double-tap window 600..200ms,
     * and the OEM high-sensitivity flag from 70% up (only where the maker supports it).
     */
    fun touch(pct: Int): String {
        val p = pct.coerceIn(0, 100)
        if (p in 45..55) {   // "Normal" = the phone's own value
            val r = SettingsBackup.restore(Keys.TOUCH)
            return if (r.startsWith("nothing")) "OK (normal)" else r
        }
        SettingsBackup.save(Keys.TOUCH)
        val hold = (1000 - (850 * p / 100f)).toInt()
        val multi = (600 - (400 * p / 100f)).toInt()
        val hi = if (p >= 70) 1 else 0
        return Shell.run(
            "settings put secure long_press_timeout $hold; " +
            "settings put secure multi_press_timeout $multi; " +
            "settings put system high_touch_sensitivity_enable $hi"
        )
    }
    fun stats() = Shell.run("cat /proc/meminfo | head -3; dumpsys battery | grep temperature")
}

/** Reads the game's real frame rate from SurfaceFlinger (needs AeroHUB). Returns -1 when it cannot be read. */
object FpsMon {
    private var layer = ""
    private var layerPkg = ""

    private fun findLayer(pkg: String): String {
        val lines = Shell.run("dumpsys SurfaceFlinger --list").lines().map { it.trim() }.filter { it.contains(pkg) }
        val sv = lines.filter { it.startsWith("SurfaceView") && !it.contains("Background") }
        return sv.firstOrNull { it.contains("BLAST") } ?: sv.firstOrNull()
            ?: lines.firstOrNull { !it.contains("Background") && it.contains("BLAST") }
            ?: lines.firstOrNull { !it.contains("Background") } ?: ""
    }

    fun reset() { layer = ""; layerPkg = "" }

    fun sample(pkg: String): Int {
        if (pkg.isBlank()) return -1
        if (layer.isEmpty() || layerPkg != pkg) { layer = findLayer(pkg); layerPkg = pkg }
        if (layer.isEmpty()) return -1
        val out = Shell.run("dumpsys SurfaceFlinger --latency " + AeroAccess.sq(layer))
        val ts = out.lines().drop(1).mapNotNull {
            val p = it.trim().split(Regex("\\s+"))
            if (p.size >= 3) p[1].toLongOrNull() else null
        }.filter { it > 0 && it != Long.MAX_VALUE }
        if (ts.size < 2) { layer = ""; return -1 }
        val last = ts.max()
        return ts.count { it > last - 1_000_000_000L }.coerceIn(1, 240)
    }
}

/** After the one AeroHUB approval, every other permission is granted through AeroHUB's shell access. */
object AutoPerms {
    fun grant(ctx: Context) {
        if (!Shell.ready()) return
        val p = AeroAccess.sq(ctx.packageName)
        Shell.run("appops set $p SYSTEM_ALERT_WINDOW allow")
        Shell.run("pm grant $p android.permission.POST_NOTIFICATIONS")
        Shell.run("pm grant $p android.permission.RECORD_AUDIO")
    }
}

/**
 * Real phone Do Not Disturb (Priority mode) that keeps MEDIA (music / video / game audio) playing.
 * The phone's own DND settings are saved before the first "on" and put back on "off".
 * Call from a background thread.
 */
object Dnd {
    private const val P = "dnd_backup"

    fun set(ctx: Context, on: Boolean): String {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        val sp = ctx.getSharedPreferences(P, Context.MODE_PRIVATE)
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
        // The shell user may grant this app "Do Not Disturb access" (no manual step needed).
        if (!nm.isNotificationPolicyAccessGranted && Shell.ready()) {
            Shell.run("cmd notification allow_dnd ${ctx.packageName}")
            Thread.sleep(300)
        }
        if (!nm.isNotificationPolicyAccessGranted) {
            // Fallback: plain shell DND (priority mode, never "alarms only"/"total silence").
            return Shell.run("cmd notification set_dnd " + if (on) "priority" else "off")
        }
        return if (on) enable(nm, sp, am) else disable(nm, sp)
    }

    private fun enable(nm: android.app.NotificationManager, sp: android.content.SharedPreferences, am: android.media.AudioManager): String {
        if (!sp.contains("filter")) {   // keep the TRUE original, even if "on" is pressed twice
            val old = nm.notificationPolicy
            sp.edit().putInt("filter", nm.currentInterruptionFilter)
                .putInt("cats", old.priorityCategories).putInt("calls", old.priorityCallSenders)
                .putInt("msgs", old.priorityMessageSenders).putInt("fx", old.suppressedVisualEffects).commit()
        }
        val p = nm.notificationPolicy
        var cats = p.priorityCategories
        if (android.os.Build.VERSION.SDK_INT >= 28)   // MEDIA / SYSTEM / ALARMS categories exist from Android 9
            cats = cats or android.app.NotificationManager.Policy.PRIORITY_CATEGORY_MEDIA or
                android.app.NotificationManager.Policy.PRIORITY_CATEGORY_SYSTEM or
                android.app.NotificationManager.Policy.PRIORITY_CATEGORY_ALARMS
        val musicBefore = am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)
        nm.setNotificationPolicy(android.app.NotificationManager.Policy(cats, p.priorityCallSenders, p.priorityMessageSenders, p.suppressedVisualEffects))
        nm.setInterruptionFilter(android.app.NotificationManager.INTERRUPTION_FILTER_PRIORITY)
        Thread.sleep(300)
        // Safety net for phones that still mute media: put the media volume back.
        if (musicBefore > 0 && am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC) == 0)
            am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, musicBefore, 0)
        return "OK (media stays on)"
    }

    private fun disable(nm: android.app.NotificationManager, sp: android.content.SharedPreferences): String {
        if (sp.contains("filter")) {
            nm.setNotificationPolicy(android.app.NotificationManager.Policy(
                sp.getInt("cats", 0), sp.getInt("calls", 0), sp.getInt("msgs", 0), sp.getInt("fx", 0)))
            nm.setInterruptionFilter(sp.getInt("filter", android.app.NotificationManager.INTERRUPTION_FILTER_ALL)
                .let { if (it == android.app.NotificationManager.INTERRUPTION_FILTER_UNKNOWN) android.app.NotificationManager.INTERRUPTION_FILTER_ALL else it })
            sp.edit().clear().commit()
        } else nm.setInterruptionFilter(android.app.NotificationManager.INTERRUPTION_FILTER_ALL)
        return "OK"
    }
}
