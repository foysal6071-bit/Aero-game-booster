package com.example.gameboost

import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import rikka.shizuku.Shizuku
import java.io.ByteArrayOutputStream
import kotlin.concurrent.thread

/** Shell access through Shizuku. Same API the rest of the app already uses ([state], [run], [sq], ...). */
object AeroAccess {
    enum class State { NotInstalled, NotRunning, NoPermission, Blocked, Ready }

    const val PKG = "moe.shizuku.privileged.api"
    private const val REQ = 4127

    @Volatile var state: State = State.NoPermission; private set
    /** Called on the main thread whenever [state] changes. Use it to refresh the UI (or copy into a Compose mutableStateOf). */
    var onChange: (() -> Unit)? = null

    private var app: Context? = null
    @Volatile private var pollGen = 0
    @Volatile private var listening = false
    private val main = Handler(Looper.getMainLooper())

    /** Call once in Activity.onCreate / Service.onCreate (safe to call again). */
    fun init(context: Context) {
        app = context.applicationContext
        if (!listening) {
            listening = true
            try {
                Shizuku.addBinderReceivedListener { recheck() }
                Shizuku.addBinderDeadListener { recheck() }
                Shizuku.addRequestPermissionResultListener { _, _ -> recheck() }
            } catch (_: Throwable) { listening = false }
        }
    }

    fun context(): Context? = app

    fun installed(context: Context): Boolean =
        runCatching { context.packageManager.getPackageInfo(PKG, 0) }.isSuccess

    fun message(s: State = state): String = when (s) {
        State.NotInstalled -> "Shizuku is not installed"
        State.NotRunning -> "Start Shizuku (Wireless debugging or root), then come back"
        State.NoPermission -> "Tap Allow to give this app Shizuku access"
        State.Blocked -> "Blocked: switch this app on in Shizuku > Authorized apps"
        State.Ready -> "Shizuku connected"
    }

    private fun set(s: State) {
        if (state != s) { state = s; main.post { onChange?.invoke() } }
    }

    private fun checkBlocking() {
        val c = app ?: return
        if (!installed(c)) { set(State.NotInstalled); return }
        val code = try {
            when {
                !Shizuku.pingBinder() || Shizuku.isPreV11() -> -1
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> 1
                else -> 0
            }
        } catch (_: Throwable) { -1 }
        when {
            code < 0 -> set(State.NotRunning)
            code == 0 -> set(if (runCatching { Shizuku.shouldShowRequestPermissionRationale() }.getOrDefault(false)) State.Blocked else State.NoPermission)
            else -> set(State.Ready)
        }
    }

    fun recheck() { thread(isDaemon = true) { runCatching { checkBlocking() } } }

    /** Re-check every ~4 s while the app is on screen (call from onResume/onPause), in case Shizuku was stopped. */
    fun startPolling(context: Context) {
        init(context)
        val g = ++pollGen
        recheck()
        thread(isDaemon = true) {
            while (pollGen == g) {
                try { Thread.sleep(4000) } catch (_: InterruptedException) {}
                if (pollGen == g) runCatching { checkBlocking() }
            }
        }
    }
    fun stopPolling() { pollGen++ }

    /** Shows Shizuku's Allow/Deny popup. The answer arrives through the listener set in [init]. */
    fun requestPermission(@Suppress("UNUSED_PARAMETER") context: Context) {
        try { Shizuku.requestPermission(REQ) } catch (_: Throwable) { recheck() }
    }

    fun openShizuku(context: Context) {
        runCatching {
            context.packageManager.getLaunchIntentForPackage(PKG)
                ?.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                ?.let { context.startActivity(it) }
        }
    }

    /** Safe shell quoting: 'text' with every ' replaced by '\\'' . Always quote file names / package names with it. */
    fun sq(s: String) = "'" + s.replace("'", "'\\''") + "'"

    private fun proc(cmd: String): Process {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        ).apply { isAccessible = true }
        return m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
    }

    private fun readCapped(i: java.io.InputStream, o: ByteArrayOutputStream) {
        try {
            val b = ByteArray(8192)
            while (true) {
                val n = i.read(b)
                if (n < 0) break
                synchronized(o) { val room = 512 * 1024 - o.size(); if (room > 0) o.write(b, 0, minOf(n, room)) }
            }
        } catch (_: Throwable) {}
    }

    /** Runs a shell command as the shell user. Blocking: call from Dispatchers.IO / a background thread. */
    fun run(cmd: String): Pair<Int, String> {
        if (state != State.Ready) throw IllegalStateException("Shizuku is not connected.")
        try {
            val p = proc(cmd)
            runCatching { p.outputStream.close() }
            val out = ByteArrayOutputStream()
            val err = ByteArrayOutputStream()
            val t1 = thread(isDaemon = true) { readCapped(p.inputStream, out) }
            val t2 = thread(isDaemon = true) { readCapped(p.errorStream, err) }
            t1.join(60_000); t2.join(1_000)
            val code = try { p.exitValue() } catch (_: IllegalThreadStateException) { p.destroy(); -1 }
            return code to String(out.toByteArray() + err.toByteArray())
        } catch (e: Exception) {
            recheck()
            throw IllegalStateException("Shizuku: ${e.message ?: "connection failed"}")
        }
    }
}
