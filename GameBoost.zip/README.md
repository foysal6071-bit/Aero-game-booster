# Game Boost
Shizuku ভিত্তিক Android gaming tool (root ছাড়া)।

## ফিচার
Game Mode, speed compile, background kill, refresh rate, animation scale, RAM/temp।

## ব্যবহার
1. Shizuku app install করে চালু করুন
2. APK install করে Permission দিন
3. Game এর package name দিয়ে বাটন চাপুন

> নোট: আসল CPU/GPU overclock এর জন্য root লাগে।
