package com.example.gameboost

import rikka.shizuku.Shizuku

object Shell {
    fun ready() = try {
        Shizuku.pingBinder() &&
            Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    // Shizuku 13+ এ newProcess private, তাই reflection
    fun run(cmd: String): String = try {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        ).apply { isAccessible = true }
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        val err = p.errorStream.bufferedReader().readText()
        p.waitFor()
        (out + err).trim().ifEmpty { "OK" }
    } catch (e: Throwable) { "Error: ${e.message}" }
}

object Boost {
    fun gameMode(pkg: String) = Shell.run("cmd game set --mode 2 --user 0 $pkg")
    fun compileSpeed(pkg: String) = Shell.run("cmd package compile -m speed -f $pkg")
    fun killBackground() = Shell.run("am kill-all")
    fun refreshRate(hz: Int) =
        Shell.run("settings put system min_refresh_rate $hz; settings put system peak_refresh_rate $hz")
    fun animations(scale: String) = Shell.run(
        "settings put global window_animation_scale $scale; " +
        "settings put global transition_animation_scale $scale; " +
        "settings put global animator_duration_scale $scale"
    )
    fun stats() = Shell.run("cat /proc/meminfo | head -3; dumpsys battery | grep temperature")
}
