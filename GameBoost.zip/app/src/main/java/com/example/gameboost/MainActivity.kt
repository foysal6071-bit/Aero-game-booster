package com.example.gameboost

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Screen() } }
    }
}

@Composable
fun Screen() {
    var pkg by remember { mutableStateOf("com.tencent.ig") }
    var log by remember { mutableStateOf("Shizuku চালু করে Permission দিন") }
    var ok by remember { mutableStateOf(Shell.ready()) }

    fun act(f: () -> String) { log = f() }

    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Game Boost", style = MaterialTheme.typography.headlineMedium)
            Text(if (ok) "Shizuku: Connected ✅" else "Shizuku: Not ready ❌")
            Button(onClick = {
                try { Shizuku.requestPermission(1) } catch (_: Throwable) {}
                ok = Shell.ready()
            }) { Text("Permission দিন / Refresh") }

            OutlinedTextField(
                value = pkg, onValueChange = { pkg = it },
                label = { Text("Game package name") }, modifier = Modifier.fillMaxWidth()
            )
            Button({ act { Boost.gameMode(pkg) } }, Modifier.fillMaxWidth()) { Text("Game Mode: Performance") }
            Button({ act { Boost.compileSpeed(pkg) } }, Modifier.fillMaxWidth()) { Text("Compile (speed)") }
            Button({ act { Boost.killBackground() } }, Modifier.fillMaxWidth()) { Text("Background app বন্ধ") }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ act { Boost.refreshRate(90) } }) { Text("90Hz") }
                Button({ act { Boost.refreshRate(120) } }) { Text("120Hz") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ act { Boost.animations("0.5") } }) { Text("Anim 0.5x") }
                Button({ act { Boost.animations("1") } }) { Text("Anim Reset") }
            }
            Button({ act { Boost.stats() } }, Modifier.fillMaxWidth()) { Text("RAM / Temp দেখুন") }
            Divider()
            Text(log, style = MaterialTheme.typography.bodySmall)
        }
    }
}
