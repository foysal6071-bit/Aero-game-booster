# Aero Boost
AeroHUB ভিত্তিক Android gaming tool (root ছাড়া)।

## AeroHUB access
1. AeroHUB app install করে server চালু করুন
2. Aero Boost খুলে CONNECT চাপুন, Allow দিন
3. AeroHUB > Apps এ এই app এর switch চালু রাখুন

## ফিচার
Game Mode, speed compile, RAM clean, refresh rate, animation scale, stats।

## In-game panel
Aero Boost এ "IN-GAME PANEL" চালু করুন (Display over other apps permission দিন)।
গেমের ভিতর বাম কিনারা থেকে ডানে টান দিন।
