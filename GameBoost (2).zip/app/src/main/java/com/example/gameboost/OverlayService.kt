package com.example.gameboost

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.min

/** In-game edge-swipe panel, styled like Xiaomi Game Turbo. */
class OverlayService : Service() {

    companion object { @Volatile var running = false }

    private val BLUE = 0xFF3AA0E8.toInt()
    private val BG = 0xF2161C28.toInt()
    private val TILE = 0xFF1F2735.toInt()
    private val LINE = 0xFF3A4458.toInt()
    private val TXT = 0xFFE6ECF5.toInt()
    private val DIMT = 0xFF8E9BB3.toInt()
    private val LIME = 0xFF00FF9C.toInt()

    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private var handle: View? = null
    private var scrim: FrameLayout? = null
    private var timerTv: TextView? = null

    private var dnd = false
    private var rec = false
    private var hz = false
    private var gmode = 2
    private var vmode = 0
    private var timerRunning = false
    private var timerStart = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        AeroAccess.init(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("overlay", "Game panel", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "overlay")
            .setContentTitle("Aero Boost")
            .setContentText("Swipe from the left edge in game")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            var t = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                t = t or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            startForeground(1, n, t)
        } else startForeground(1, n)
        addHandle()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onDestroy() {
        running = false
        ui.removeCallbacksAndMessages(null)
        hidePanel()
        handle?.let { runCatching { wm.removeView(it) } }
        handle = null
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun box(fill: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(r).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    // ---------- edge handle ----------
    private fun addHandle() {
        val v = FrameLayout(this)
        val pill = View(this).apply { background = box(0x883AA0E8.toInt(), 2) }
        v.addView(pill, FrameLayout.LayoutParams(dp(4), dp(64), Gravity.CENTER_VERTICAL or Gravity.START).apply { leftMargin = dp(2) })
        var downX = 0f
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> downX = e.rawX
                MotionEvent.ACTION_MOVE -> if (e.rawX - downX > dp(30)) showPanel()
                MotionEvent.ACTION_UP -> if (abs(e.rawX - downX) < dp(6)) showPanel()
            }
            true
        }
        val lp = WindowManager.LayoutParams(
            dp(24), dp(220),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.START or Gravity.CENTER_VERTICAL }
        wm.addView(v, lp)
        handle = v
    }

    // ---------- panel window ----------
    private fun showPanel() {
        if (scrim != null) return
        AeroAccess.startPolling(this)
        val dm = resources.displayMetrics
        val s = FrameLayout(this).apply {
            setBackgroundColor(0x66000000)
            setOnClickListener { hidePanel() }
        }
        val pw = min((dm.widthPixels * 0.78f).toInt(), dp(620))
        val ph = min(dm.heightPixels - dp(16), dp(330))
        val p = buildPanel()
        s.addView(p, FrameLayout.LayoutParams(pw, ph, Gravity.START or Gravity.CENTER_VERTICAL).apply { leftMargin = dp(28) })
        wm.addView(
            s,
            WindowManager.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
        )
        scrim = s
        p.translationX = -pw.toFloat()
        p.animate().translationX(0f).setDuration(200).start()
    }

    private fun hidePanel() {
        AeroAccess.stopPolling()
        scrim?.let { runCatching { wm.removeView(it) } }
        scrim = null
        timerTv = null
    }

    // ---------- UI pieces ----------
    private fun ic(res: Int, tint: Int) = ImageView(this).apply {
        setImageResource(res)
        setColorFilter(tint)
    }

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun squareTile(res: Int, text: String, click: () -> Unit): LinearLayout {
        val me = this
        return LinearLayout(me).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = box(TILE, 6, LINE)
            setPadding(dp(4), dp(6), dp(4), dp(6))
            addView(ic(res, BLUE), LinearLayout.LayoutParams(dp(28), dp(28)))
            addView(label(text, 10f, DIMT).apply { gravity = Gravity.CENTER })
            setOnClickListener { click() }
        }
    }

    private fun listRow(res: Int, text: String, divider: Boolean, click: () -> Unit): LinearLayout {
        val me = this
        return LinearLayout(me).apply {
            orientation = LinearLayout.VERTICAL
            val r = LinearLayout(me).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(8), 0, dp(8))
                addView(ic(res, BLUE), LinearLayout.LayoutParams(dp(18), dp(18)))
                addView(label(text, 12f, TXT).apply { setPadding(dp(10), 0, 0, 0) })
                setOnClickListener { click() }
            }
            addView(r)
            if (divider) addView(View(me).apply { setBackgroundColor(LINE) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1))
        }
    }

    private fun toolItem(res: Int, text: String, on: Boolean, click: (LinearLayout) -> Unit): LinearLayout {
        val me = this
        return LinearLayout(me).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(8), dp(4), dp(8))
            addView(ic(res, if (on) LIME else BLUE), LinearLayout.LayoutParams(dp(24), dp(24)))
            addView(label(text, 10f, if (on) LIME else TXT).apply { gravity = Gravity.CENTER; setPadding(0, dp(3), 0, 0) })
            setOnClickListener { click(this) }
        }
    }

    private fun setOn(v: LinearLayout, on: Boolean) {
        (v.getChildAt(0) as ImageView).setColorFilter(if (on) LIME else BLUE)
        (v.getChildAt(1) as TextView).setTextColor(if (on) LIME else TXT)
    }

    private fun wideTile(res: Int, text: String, filled: Boolean, click: () -> Unit): Pair<LinearLayout, TextView> {
        val me = this
        val tv = label(text, 13f, TXT).apply { setPadding(dp(10), 0, 0, 0) }
        val l = LinearLayout(me).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = box(if (filled) 0xFF2A3345.toInt() else Color.TRANSPARENT, 6, LINE)
            setPadding(dp(10), dp(12), dp(10), dp(12))
            addView(ic(res, DIMT), LinearLayout.LayoutParams(dp(22), dp(22)))
            addView(tv)
            setOnClickListener { click() }
        }
        return l to tv
    }

    private fun gameName() = when (gmode) { 1 -> "Standard"; 3 -> "Battery saver"; else -> "Performance" }

    private fun buildPanel(): LinearLayout {
        val me = this
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val root = LinearLayout(me).apply { orientation = LinearLayout.HORIZONTAL; isClickable = true }

        // --- left strip: games ---
        val strip = LinearLayout(me).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(5), dp(6), dp(5), dp(6)) }
        (getSharedPreferences("games", MODE_PRIVATE).getString("list", "") ?: "")
            .split(",").filter { it.isNotBlank() }.forEach { p ->
                try {
                    val iv = ImageView(me).apply {
                        setImageDrawable(packageManager.getApplicationIcon(p))
                        setOnClickListener {
                            packageManager.getLaunchIntentForPackage(p)?.let {
                                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(it)
                            }
                            hidePanel()
                        }
                    }
                    strip.addView(iv, LinearLayout.LayoutParams(dp(42), dp(42)).apply { setMargins(0, dp(4), 0, dp(4)) })
                } catch (_: Throwable) {}
            }
        root.addView(ScrollView(me).apply { background = box(BG, 14, LINE); addView(strip) }, LinearLayout.LayoutParams(dp(56), match))

        // --- main panel ---
        val col = LinearLayout(me).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(8), dp(10), dp(10)) }
        val mainSv = ScrollView(me).apply { background = box(BG, 14, LINE); addView(col) }
        col.addView(label("AERO TURBO", 15f, BLUE).apply {
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
            letterSpacing = 0.08f
        })

        val body = LinearLayout(me).apply { orientation = LinearLayout.HORIZONTAL }
        val left = LinearLayout(me).apply { orientation = LinearLayout.VERTICAL }
        left.addView(squareTile(R.drawable.ic_rocket, "Clear memory") { act("Clear memory") { Boost.killBackground() } },
            LinearLayout.LayoutParams(match, 0, 1f).apply { bottomMargin = dp(6) })
        left.addView(squareTile(R.drawable.ic_trash, "Free up storage") { act("Free storage") { Shell.run("pm trim-caches 100G") } },
            LinearLayout.LayoutParams(match, 0, 1f))
        body.addView(left, LinearLayout.LayoutParams(dp(78), match))

        val card = LinearLayout(me).apply {
            orientation = LinearLayout.VERTICAL
            background = box(TILE, 6, LINE)
            setPadding(dp(12), dp(8), dp(12), dp(10))
        }
        card.addView(label("Boost performance", 12f, TXT, true).apply { gravity = Gravity.CENTER })
        card.addView(listRow(R.drawable.ic_tune, "Clear memory automatically", true) { act("Clear memory") { Boost.killBackground() } })
        card.addView(listRow(R.drawable.ic_storage, "Free up storage space", true) { act("Free storage") { Shell.run("pm trim-caches 100G") } })
        card.addView(listRow(R.drawable.ic_chart, "Monitor performance", false) { act("Monitor") { Boost.stats() } })
        card.addView(label("Boost", 14f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF2B86C5.toInt(), 0xFF52B5EE.toInt()))
                .apply { cornerRadius = dp(4).toFloat() }
            setPadding(0, dp(9), 0, dp(9))
            setOnClickListener {
                act("Boost") {
                    val g = currentGame()
                    val a = if (g.isNotBlank()) Boost.gameMode(g, gmode) else "no game found"
                    "mode: $a | ram: ${Boost.killBackground()}"
                }
            }
        }, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(6) })
        body.addView(card, LinearLayout.LayoutParams(0, wrap, 1f).apply { leftMargin = dp(8) })
        col.addView(body, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(6) })

        // --- toolbar ---
        val bar = LinearLayout(me).apply { orientation = LinearLayout.HORIZONTAL }
        val tp = { LinearLayout.LayoutParams(dp(72), wrap) }
        bar.addView(toolItem(R.drawable.ic_dnd, "DND", dnd) { v ->
            dnd = !dnd; setOn(v, dnd)
            act("DND " + if (dnd) "on" else "off") { Shell.run("cmd notification set_dnd " + if (dnd) "on" else "off") }
        }, tp())
        bar.addView(toolItem(R.drawable.ic_cut, "Screenshot", false) {
            hidePanel()
            ui.postDelayed({
                thread {
                    val r = Shell.run("mkdir -p /sdcard/Pictures/AeroBoost; screencap -p /sdcard/Pictures/AeroBoost/shot_${System.currentTimeMillis()}.png")
                    ui.post { toast(if (r == "OK") "Screenshot saved" else r) }
                }
            }, 400)
        }, tp())
        bar.addView(toolItem(R.drawable.ic_video, "Record", rec) { v ->
            rec = !rec; setOn(v, rec)
            if (rec) {
                hidePanel()
                thread {
                    Shell.run("mkdir -p /sdcard/Movies/AeroBoost; nohup screenrecord --time-limit 180 /sdcard/Movies/AeroBoost/rec_${System.currentTimeMillis()}.mp4 >/dev/null 2>&1 &")
                    ui.post { toast("Recording...") }
                }
            } else act("Record stop") { Shell.run("pkill -2 screenrecord"); "saved" }
        }, tp())
        bar.addView(toolItem(R.drawable.ic_gear, "Settings", false) {
            hidePanel()
            startActivity(Intent(me, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }, tp())
        bar.addView(toolItem(R.drawable.ic_bolt, "120Hz", hz) { v ->
            hz = !hz; setOn(v, hz)
            act(if (hz) "120Hz" else "60Hz") { Boost.refreshRate(if (hz) 120 else 60) }
        }, tp())
        bar.addView(toolItem(R.drawable.ic_rocket, "Mode", false) {
            gmode = gmode % 3 + 1
            act("Mode " + gameName()) { Boost.gameMode(currentGame(), gmode) }
        }, tp())
        col.addView(
            HorizontalScrollView(me).apply {
                background = box(TILE, 6, LINE)
                isHorizontalScrollBarEnabled = false
                addView(bar)
            },
            LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(8) }
        )

        // --- bottom tiles ---
        val bottom = LinearLayout(me).apply { orientation = LinearLayout.HORIZONTAL }
        val voiceBox = LinearLayout(me).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            background = box(TILE, 6, LINE)
            setPadding(dp(10), dp(8), dp(10), dp(10))
        }
        val (voiceTile, _) = wideTile(R.drawable.ic_mic, "Voice changer", true) {}
        voiceTile.setOnClickListener {
            voiceBox.visibility = if (voiceBox.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            mainSv.post { mainSv.fullScroll(View.FOCUS_DOWN) }
        }
        val names = listOf("Girl", "Robot", "Cat")
        val chipRow = LinearLayout(me).apply { orientation = LinearLayout.HORIZONTAL }
        val chips = names.map { n -> label(n, 12f, TXT, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(8)) } }
        fun paint() {
            chips.forEachIndexed { i, v ->
                val sel = i == vmode
                v.background = if (sel) box(BLUE, 6) else box(Color.TRANSPARENT, 6, LINE)
                v.setTextColor(if (sel) 0xFF05070D.toInt() else TXT)
            }
        }
        chips.forEachIndexed { i, v ->
            v.setOnClickListener { vmode = i; paint() }
            chipRow.addView(v, LinearLayout.LayoutParams(0, wrap, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        paint()
        voiceBox.addView(label("Pick a voice, hold the button and talk. It plays when you let go.", 10f, DIMT))
        voiceBox.addView(chipRow, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(8) })
        val talk = label("Hold to talk", 14f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF2B86C5.toInt(), 0xFF52B5EE.toInt()))
                .apply { cornerRadius = dp(4).toFloat() }
            setPadding(0, dp(12), 0, dp(12))
        }
        talk.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                        toast("Allow the microphone in Aero Boost first")
                    } else if (VoiceFx.start()) {
                        talk.text = "Recording..."
                    } else toast("Microphone is busy")
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (VoiceFx.active) {
                        talk.text = "Hold to talk"
                        VoiceFx.finish(vmode)
                    }
                }
            }
            true
        }
        voiceBox.addView(talk, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(8) })
        val (timerTile, tTv) = wideTile(R.drawable.ic_hourglass, timerText(), false) {}
        timerTv = tTv
        timerTile.setOnClickListener {
            timerRunning = !timerRunning
            if (timerRunning) { timerStart = System.currentTimeMillis(); tick() }
            tTv.text = timerText()
        }
        if (timerRunning) tick()
        bottom.addView(voiceTile, LinearLayout.LayoutParams(0, wrap, 1f).apply { rightMargin = dp(4) })
        bottom.addView(timerTile, LinearLayout.LayoutParams(0, wrap, 1f).apply { leftMargin = dp(4) })
        col.addView(bottom, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(8) })
        col.addView(voiceBox, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(8) })

        root.addView(mainSv, LinearLayout.LayoutParams(0, match, 1f).apply { leftMargin = dp(8) })
        return root
    }

    // ---------- helpers ----------
    private fun timerText(): String {
        if (!timerRunning) return "Timer"
        val s = (System.currentTimeMillis() - timerStart) / 1000
        return "%02d:%02d".format(s / 60, s % 60)
    }

    private fun tick() {
        ui.removeCallbacks(tickRun)
        ui.postDelayed(tickRun, 1000)
    }

    private val tickRun = object : Runnable {
        override fun run() {
            if (!timerRunning) return
            timerTv?.text = timerText()
            ui.postDelayed(this, 1000)
        }
    }

    private fun toast(t: String) = Toast.makeText(this, t.take(200), Toast.LENGTH_LONG).show()

    private fun act(name: String, f: () -> String) {
        toast("$name...")
        thread {
            val r = try { f() } catch (e: Throwable) { "Error: ${e.message}" }
            ui.post { toast("$name: $r") }
        }
    }

    private fun currentGame(): String {
        val r = Shell.run("dumpsys activity activities | grep -m1 -E 'topResumedActivity|mResumedActivity'")
        val p = Regex("([a-zA-Z][a-zA-Z0-9_]*(?:\\.[a-zA-Z0-9_]+)+)/").find(r)?.groupValues?.get(1)
        if (p != null && p != packageName && !p.startsWith("com.android.systemui")) return p
        return getSharedPreferences("games", MODE_PRIVATE).getString("sel", "") ?: ""
    }
}
