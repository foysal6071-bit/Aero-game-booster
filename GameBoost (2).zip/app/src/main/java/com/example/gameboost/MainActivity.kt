package com.example.gameboost

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Bg = Color(0xFF05070D)
private val Panel = Color(0xFF0C1322)
private val Cyan = Color(0xFF00E5FF)
private val Magenta = Color(0xFFFF2BD6)
private val Lime = Color(0xFF00FF9C)
private val Amber = Color(0xFFFFB300)
private val Dim = Color(0xFF7A8AA8)
private val Line = Color(0xFF1F2A44)

class MainActivity : ComponentActivity() {
    private var aero by mutableStateOf(AeroAccess.state)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AeroAccess.init(this)
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), 7)
        AeroAccess.onChange = { aero = AeroAccess.state }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Panel)) {
                Screen(aero)
            }
        }
    }

    override fun onResume() { super.onResume(); AeroAccess.startPolling(this) }
    override fun onPause() { AeroAccess.stopPolling(); super.onPause() }

    @Deprecated("needed for AeroHUB's startActivityForResult")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        AeroAccess.onResult(this, requestCode, resultCode, data)
    }
}

@Composable
fun Screen(aero: AeroAccess.State) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("games", Context.MODE_PRIVATE) }
    var apps by remember { mutableStateOf(listOf<AppInfo>()) }
    var gamePkgs by remember { mutableStateOf((prefs.getString("list", "") ?: "").split(",").filter { it.isNotBlank() }) }
    var pkg by remember { mutableStateOf(prefs.getString("sel", "") ?: "") }
    var showPicker by remember { mutableStateOf(false) }
    var mode by remember { mutableStateOf(2) }
    var hz by remember { mutableStateOf(false) }
    var fast by remember { mutableStateOf(false) }
    var overlay by remember { mutableStateOf(OverlayService.running) }
    var busy by remember { mutableStateOf(false) }
    var boosted by remember { mutableStateOf(false) }
    var log by remember { mutableStateOf("> system ready") }
    val ok = aero == AeroAccess.State.Ready

    LaunchedEffect(Unit) { apps = withContext(Dispatchers.IO) { loadApps(ctx) } }
    val games = gamePkgs.mapNotNull { p -> apps.find { it.pkg == p } }
    val selected = apps.find { it.pkg == pkg }

    fun saveList(l: List<String>) { gamePkgs = l; prefs.edit().putString("list", l.joinToString(",")).apply() }
    fun select(p: String) { pkg = p; boosted = false; prefs.edit().putString("sel", p).apply() }
    fun say(s: String) { log = (log + "\n" + s).lines().takeLast(14).joinToString("\n") }
    fun startGame(p: String = pkg) {
        try { ctx.packageManager.getLaunchIntentForPackage(p)?.let { ctx.startActivity(it) } } catch (_: Throwable) {}
    }
    fun ensureOverlay() {
        if (!OverlayService.running && Settings.canDrawOverlays(ctx)) {
            ctx.startForegroundService(Intent(ctx, OverlayService::class.java))
            overlay = true
        }
    }

    fun run(title: String, needGame: Boolean = false, f: () -> String) {
        if (busy) return
        if (needGame && pkg.isBlank()) { say("! select a game first"); return }
        busy = true
        say("> $title...")
        scope.launch {
            val r = withContext(Dispatchers.IO) { f() }
            say("  $r")
            busy = false
        }
    }

    fun fullBoost() {
        if (busy) return
        if (pkg.isBlank()) { say("! select a game first"); return }
        busy = true
        boosted = false
        say("> BOOST started")
        scope.launch {
            val steps = mutableListOf<Pair<String, () -> String>>(
                "game mode" to { Boost.gameMode(pkg, mode) },
                "clean ram" to { Boost.killBackground() }
            )
            if (fast) steps.add("fast anim" to { Boost.animations("0.5") })
            if (hz) steps.add("120Hz" to { Boost.refreshRate(120) })
            for ((n, f) in steps) {
                val r = withContext(Dispatchers.IO) { f() }
                say("  [$n] $r")
            }
            boosted = true
            busy = false
            startGame()
        }
    }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0B1230), Bg)))) {
        Row(
            Modifier.fillMaxSize().systemBarsPadding().displayCutoutPadding().padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // LEFT: games
            Column(Modifier.weight(1.15f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Header(ok) {
                    if (aero == AeroAccess.State.NoPermission) AeroAccess.requestPermission(ctx)
                    else AeroAccess.openAeroHub(ctx)
                }
                Text(AeroAccess.message(aero), color = Dim, fontSize = 10.sp)
                Text("MY GAMES  ·  hold to remove", color = Cyan, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                LazyVerticalGrid(
                    GridCells.Adaptive(76.dp),
                    Modifier.weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    gridItems(games, key = { it.pkg }) { g ->
                        GameTile(g, g.pkg == pkg, {
                            select(g.pkg)
                            startGame(g.pkg)
                            ensureOverlay()
                            scope.launch { withContext(Dispatchers.IO) { Boost.gameMode(g.pkg, mode) } }
                        }) {
                            saveList(gamePkgs - g.pkg)
                            if (pkg == g.pkg) select("")
                        }
                    }
                    item { AddTile { showPicker = true } }
                }
                Terminal(log.lines().takeLast(3).joinToString("\n"))
            }

            // RIGHT: control panel
            Column(
                Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                BoostButton(150.dp, busy, boosted, ok) { fullBoost() }
                Text(
                    selected?.label ?: "Select a game",
                    color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                ModeSelector(mode) { m ->
                    mode = m
                    run("mode $m", true) { Boost.gameMode(pkg, m) }
                }
                SwitchRow("120 Hz LOCK", "Smoother display", hz) {
                    hz = it
                    run(if (it) "120Hz" else "60Hz") { Boost.refreshRate(if (it) 120 else 60) }
                }
                SwitchRow("FAST ANIMATION", "Scale 0.5x", fast) {
                    fast = it
                    run("anim") { Boost.animations(if (it) "0.5" else "1") }
                }
                SwitchRow("IN-GAME PANEL", "Swipe from left edge", overlay) { on ->
                    if (on) {
                        if (!Settings.canDrawOverlays(ctx)) {
                            ctx.startActivity(
                                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                            say("! allow 'Display over other apps', then switch on again")
                        } else {
                            ctx.startForegroundService(Intent(ctx, OverlayService::class.java))
                            overlay = true
                        }
                    } else {
                        ctx.stopService(Intent(ctx, OverlayService::class.java))
                        overlay = false
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ToolCard("CLEAN RAM", "Kill apps", Lime, Modifier.weight(1f)) { run("clean ram") { Boost.killBackground() } }
                    ToolCard("COMPILE", "Speed", Magenta, Modifier.weight(1f)) { run("compile", true) { Boost.compileSpeed(pkg) } }
                    ToolCard("STATS", "RAM/Temp", Amber, Modifier.weight(1f)) { run("stats") { Boost.stats() } }
                }
            }
        }
    }

    if (showPicker) {
        AppPickerDialog(apps, {
            if (it.pkg !in gamePkgs) saveList(gamePkgs + it.pkg)
            select(it.pkg)
            showPicker = false
        }, { showPicker = false })
    }
}

@Composable
fun Header(ok: Boolean, onConnect: () -> Unit) {
    val t = rememberInfiniteTransition(label = "dot")
    val a by t.animateFloat(0.3f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "a")
    val c = if (ok) Lime else Magenta
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(
                "AERO BOOST",
                style = TextStyle(
                    brush = Brush.horizontalGradient(listOf(Cyan, Magenta)),
                    fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp
                )
            )
            Text("GAME TURBO ENGINE", color = Dim, fontSize = 9.sp, letterSpacing = 2.sp)
        }
        Row(
            Modifier.clip(RoundedCornerShape(50)).border(1.dp, c, RoundedCornerShape(50))
                .clickable(onClick = onConnect).padding(horizontal = 12.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(c.copy(alpha = a)))
            Spacer(Modifier.size(8.dp))
            Text(if (ok) "LINKED" else "CONNECT", color = c, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GameTile(g: AppInfo, selected: Boolean, onClick: () -> Unit, onLong: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        Modifier.clip(shape).combinedClickable(onClick = onClick, onLongClick = onLong).padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(62.dp).clip(shape)
                .border(
                    if (selected) 2.dp else 1.dp,
                    if (selected) Brush.linearGradient(listOf(Cyan, Magenta)) else Brush.linearGradient(listOf(Line, Line)),
                    shape
                ).background(Panel),
            contentAlignment = Alignment.Center
        ) {
            if (g.icon != null) Image(g.icon, null, Modifier.size(50.dp).clip(RoundedCornerShape(12.dp)))
        }
        Spacer(Modifier.height(4.dp))
        Text(
            g.label, color = if (selected) Cyan else Color.White, fontSize = 10.sp,
            maxLines = 1, overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun AddTile(onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(Modifier.clip(shape).clickable(onClick = onClick).padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(62.dp).clip(shape).border(1.dp, Cyan.copy(alpha = 0.6f), shape), contentAlignment = Alignment.Center) {
            Text("+", color = Cyan, fontSize = 28.sp, fontWeight = FontWeight.Light)
        }
        Spacer(Modifier.height(4.dp))
        Text("Add", color = Cyan, fontSize = 10.sp)
    }
}

@Composable
fun ModeSelector(mode: Int, onPick: (Int) -> Unit) {
    val names = listOf(1 to "STANDARD", 2 to "PERFORMANCE", 3 to "SAVER")
    val shape = RoundedCornerShape(12.dp)
    Row(Modifier.fillMaxWidth().clip(shape).background(Panel).border(1.dp, Line, shape).padding(3.dp)) {
        names.forEach { (m, n) ->
            val sel = m == mode
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                    .background(
                        if (sel) Brush.horizontalGradient(listOf(Cyan, Magenta))
                        else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
                    )
                    .clickable { onPick(m) }.padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(n, color = if (sel) Bg else Dim, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }
        }
    }
}

@Composable
fun SwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(Panel).border(1.dp, Line, shape).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.sp)
            Text(sub, color = Dim, fontSize = 10.sp)
        }
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedTrackColor = Cyan, checkedThumbColor = Bg,
                uncheckedTrackColor = Color(0xFF16213A), uncheckedThumbColor = Dim, uncheckedBorderColor = Line
            )
        )
    }
}

@Composable
fun BoostButton(size: Dp, busy: Boolean, boosted: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "ring")
    val angle by t.animateFloat(
        0f, 360f, infiniteRepeatable(tween(if (busy) 900 else 5000, easing = LinearEasing)), label = "angle"
    )
    val pulse by t.animateFloat(0.9f, 1f, infiniteRepeatable(tween(1500), RepeatMode.Reverse), label = "pulse")
    val label = when {
        busy -> "BOOSTING"
        boosted -> "BOOSTED"
        else -> "BOOST"
    }
    val accent = if (boosted && !busy) Lime else Cyan
    Box(
        Modifier.size(size).clip(CircleShape).clickable(enabled = enabled && !busy, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val r = this.size.minDimension / 2 - 10.dp.toPx()
            drawCircle(
                Brush.radialGradient(listOf(accent.copy(alpha = 0.28f), Color.Transparent)),
                radius = this.size.minDimension / 2 * pulse
            )
            rotate(angle) {
                drawCircle(
                    Brush.sweepGradient(listOf(Color.Transparent, accent, Magenta, Color.Transparent)),
                    radius = r, style = Stroke(5.dp.toPx(), cap = StrokeCap.Round)
                )
            }
            drawCircle(Panel, radius = r - 9.dp.toPx())
            drawCircle(accent.copy(alpha = 0.35f), radius = r - 9.dp.toPx(), style = Stroke(1.dp.toPx()))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                label,
                style = TextStyle(
                    brush = Brush.horizontalGradient(listOf(accent, Color.White)),
                    fontSize = 18.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp
                )
            )
            Text(if (enabled) "TAP TO PLAY" else "LINK AEROHUB", color = Dim, fontSize = 8.sp, letterSpacing = 1.sp)
        }
    }
}

@Composable
fun ToolCard(title: String, sub: String, color: Color, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Column(
        modifier.clip(shape).background(Panel)
            .border(1.dp, Brush.linearGradient(listOf(color, color.copy(alpha = 0.1f))), shape)
            .clickable(onClick = onClick).padding(10.dp)
    ) {
        Text(title, color = color, fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.sp, maxLines = 1)
        Text(sub, color = Dim, fontSize = 9.sp)
    }
}

@Composable
fun Terminal(text: String) {
    val shape = RoundedCornerShape(12.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape).background(Color(0xFF02050A))
            .border(1.dp, Lime.copy(alpha = 0.4f), shape).padding(10.dp)
    ) {
        Text(text, color = Lime, fontFamily = FontFamily.Monospace, fontSize = 10.sp, lineHeight = 13.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
    }
}

data class AppInfo(val label: String, val pkg: String, val icon: ImageBitmap?)

fun loadApps(ctx: Context): List<AppInfo> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .distinctBy { it.activityInfo.packageName }
        .filter { it.activityInfo.packageName != ctx.packageName }
        .map { r ->
            AppInfo(
                r.loadLabel(pm).toString(),
                r.activityInfo.packageName,
                runCatching { r.loadIcon(pm).toBitmap(96, 96).asImageBitmap() }.getOrNull()
            )
        }
        .sortedBy { it.label.lowercase() }
}

@Composable
fun AppPickerDialog(apps: List<AppInfo>, onPick: (AppInfo) -> Unit, onDismiss: () -> Unit) {
    var q by remember { mutableStateOf("") }
    val list = apps.filter { it.label.contains(q, ignoreCase = true) }
    val shape = RoundedCornerShape(18.dp)
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier.fillMaxWidth().height(540.dp).clip(shape).background(Panel)
                .border(1.dp, Cyan.copy(alpha = 0.5f), shape).padding(14.dp)
        ) {
            Text("SELECT GAME", color = Cyan, fontWeight = FontWeight.Black, letterSpacing = 3.sp, fontSize = 16.sp)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = q, onValueChange = { q = it },
                placeholder = { Text("Search...", color = Dim) },
                singleLine = true, modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Cyan, unfocusedBorderColor = Color(0xFF1F2A44),
                    cursorColor = Cyan, focusedTextColor = Color.White, unfocusedTextColor = Color.White
                )
            )
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.weight(1f)) {
                items(list, key = { it.pkg }) { a ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                            .clickable { onPick(a) }.padding(vertical = 8.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (a.icon != null) Image(a.icon, null, Modifier.size(40.dp).clip(RoundedCornerShape(9.dp)))
                        Spacer(Modifier.size(12.dp))
                        Column {
                            Text(a.label, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(a.pkg, color = Dim, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
    }
}
