package com.example.gameboost

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.widget.Toast
import android.net.Uri
import android.provider.Settings
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.draw.scale
import androidx.compose.animation.AnimatedContent
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.drawBehind
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Bg = Color(0xFF050B18)
private val Panel = Color(0xFF101D31)
private val Cyan = Color(0xFF19AFFF)
private val Magenta = Color(0xFF287BCE)
private val Lime = Color(0xFF39FF88)
private val Amber = Color(0xFFFFC400)
private val Dim = Color(0xFF7C86A2)
private val Line = Color(0xFF29415E)

class MainActivity : ComponentActivity() {
    private var aero by mutableStateOf(AeroAccess.state)
    private var overlayOk by mutableStateOf(false)

    private fun refreshPerms() {
        overlayOk = Settings.canDrawOverlays(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // fullscreen: status bar and navigation bar hidden (swipe from the edge shows them briefly)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28)
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        hideSystemBars()
        AeroAccess.init(this)
        GameWatch.resume()
        aero = AeroAccess.state
        refreshPerms()
        AeroAccess.onChange = { aero = AeroAccess.state }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Panel)) {
                if (aero == AeroAccess.State.Ready && overlayOk) Screen(aero)
                else SetupScreen(aero, overlayOk,
                    onAero = {
                        when (aero) {
                            AeroAccess.State.NoPermission -> AeroAccess.requestPermission(this@MainActivity)
                            else -> AeroAccess.openAeroHub(this@MainActivity)
                        }
                    },
                    onOverlay = {
                        startActivity(
                            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                )
            }
        }
    }

    private fun hideSystemBars() {
        val c = WindowCompat.getInsetsController(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onResume() { super.onResume(); hideSystemBars(); refreshPerms(); AeroAccess.startPolling(this) }
    override fun onPause() { AeroAccess.stopPolling(); super.onPause() }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshPerms()
    }

    @Deprecated("needed for AeroHUB's startActivityForResult")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        AeroAccess.onResult(this, requestCode, resultCode, data)
    }
}

@Composable
fun SetupScreen(
    aero: AeroAccess.State, overlayOk: Boolean,
    onAero: () -> Unit, onOverlay: () -> Unit
) {
    val aeroOk = aero == AeroAccess.State.Ready
    val aeroBtn = when (aero) {
        AeroAccess.State.NoPermission -> "ALLOW"
        else -> "OPEN"
    }
    Box(Modifier.fillMaxSize().background(Bg).systemBarsPadding().displayCutoutPadding(), contentAlignment = Alignment.Center) {
        Column(
            Modifier.fillMaxWidth(0.8f).verticalScroll(rememberScrollState()).padding(vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("SETUP", color = Cyan, fontWeight = FontWeight.Black, fontSize = 18.sp, letterSpacing = 4.sp)
            Text("Allow these 2 permissions to continue", color = Dim, fontSize = 12.sp)
            SetupRow("AeroHUB", AeroAccess.message(aero), aeroOk, aeroBtn, onAero)
            SetupRow("Display over other apps", "Needed for the in-game panel", overlayOk, "ALLOW", onOverlay)
        }
    }
}

@Composable
private fun SetupRow(title: String, sub: String, done: Boolean, action: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(Panel)
            .border(1.dp, if (done) Lime.copy(alpha = 0.6f) else Line, shape).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(sub, color = Dim, fontSize = 11.sp)
        }
        Spacer(Modifier.size(10.dp))
        if (done) Text("✓ DONE", color = Lime, fontWeight = FontWeight.Black, fontSize = 12.sp)
        else Box(
            Modifier.clip(RoundedCornerShape(10.dp))
                .background(Brush.horizontalGradient(listOf(Color(0xFF7B2FFF), Color(0xFF00E5FF))))
                .clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 10.dp),
            contentAlignment = Alignment.Center
        ) { Text(action, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
    }
}

@Composable
fun Screen(aero: AeroAccess.State) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("games", Context.MODE_PRIVATE) }
    var apps by remember { mutableStateOf(listOf<AppInfo>()) }
    var gamePkgs by remember { mutableStateOf((prefs.getString("list", "") ?: "").split(",").filter { it.isNotBlank() }) }
    var pkg by remember { mutableStateOf(prefs.getString("sel", "") ?: "") }
    var showPicker by remember { mutableStateOf(false) }
    var mode by remember { mutableStateOf(prefs.getInt("mode", 2)) }
    var touch by remember { mutableStateOf(prefs.getInt("touchPct", (prefs.getInt("touch", 3) - 1) * 25)) }   // 0..100, 50 = phone default
    var touchSensy by remember { mutableStateOf(prefs.getInt("touchSensy", 3).coerceIn(1, 5)) }
    var settled by remember { mutableStateOf(false) }
    var connectLater by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf(0) }           // settings category
    var page by remember { mutableStateOf(0) }          // 0 = game launcher, 1 = settings
    var rec by remember { mutableStateOf(false) }
    var battery by remember { mutableStateOf(-1) }
    var cpu by remember { mutableStateOf(-1) }
    val rates = remember { Boost.supportedRates(ctx) }
    var rate by remember { mutableStateOf(0) }   // 0 = auto (phone default)
    var fast by remember { mutableStateOf(false) }
    var overlay by remember { mutableStateOf(OverlayService.running) }
    var busy by remember { mutableStateOf(false) }
    var boosted by remember { mutableStateOf(false) }
    var launching by remember { mutableStateOf(false) }
    var launchSound by remember { mutableStateOf(prefs.getBoolean("launchSound", true)) }
    var inGameShortcuts by remember { mutableStateOf(prefs.getBoolean("inGameShortcuts", true)) }
    var contentRecommendations by remember { mutableStateOf(prefs.getBoolean("contentRecommendations", true)) }
    val sound = remember { LaunchSound(ctx) }
    DisposableEffect(Unit) { onDispose { sound.release() } }
    var launchPct by remember { mutableStateOf(0f) }
    var launchStep by remember { mutableStateOf("") }
    var log by remember { mutableStateOf("> system ready") }
    val ok = aero == AeroAccess.State.Ready

    LaunchedEffect(Unit) { delay(1200); settled = true }   // give the first AeroHUB check time to finish
    BackHandler(enabled = launching) { }   // ignore back while the launch animation runs
    BackHandler(enabled = page == 1 && !launching) { page = 0 }
    LaunchedEffect(ok, page) {
        while (true) {
            val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val l = i?.getIntExtra("level", -1) ?: -1
            val sc = i?.getIntExtra("scale", 100) ?: 100
            battery = if (l < 0 || sc <= 0) -1 else l * 100 / sc
            if (ok && page == 0) {
                cpu = withContext(Dispatchers.IO) {
                    Regex("""(\d+(?:\.\d+)?)%\s*TOTAL""", RegexOption.IGNORE_CASE)
                        .find(Shell.run("dumpsys cpuinfo | grep -i total"))?.groupValues?.get(1)?.toFloatOrNull()?.toInt() ?: -1
                }
            }
            delay(4000)
        }
    }

    LaunchedEffect(Unit) { apps = withContext(Dispatchers.IO) { loadApps(ctx) } }
    val games = gamePkgs.mapNotNull { p -> apps.find { it.pkg == p } }
    val selected = apps.find { it.pkg == pkg }

    fun saveList(l: List<String>) { gamePkgs = l; prefs.edit().putString("list", l.joinToString(",")).apply() }
    fun select(p: String) { pkg = p; boosted = false; prefs.edit().putString("sel", p).apply() }
    fun say(s: String) { log = (log + "\n" + s).lines().takeLast(14).joinToString("\n") }
    fun startGame(p: String = pkg) {
        try { ctx.packageManager.getLaunchIntentForPackage(p)?.let { ctx.startActivity(it) } } catch (_: Throwable) {}
    }
    fun ensureOverlay() {
        if (!OverlayService.running && Settings.canDrawOverlays(ctx)) {
            ctx.startForegroundService(Intent(ctx, OverlayService::class.java))
            overlay = true
        }
    }

    fun run(title: String, needGame: Boolean = false, f: () -> String) {
        if (busy) return
        if (needGame && pkg.isBlank()) { say("! select a game first"); return }
        busy = true
        say("> $title...")
        scope.launch {
            val r = withContext(Dispatchers.IO) { f() }
            say("  $r")
            busy = false
        }
    }

    DisposableEffect(Unit) {
        val l: () -> Unit = { boosted = false; rate = 0; fast = false; touch = 50; prefs.edit().putInt("touchPct", 50).apply(); say("> game closed, phone settings restored") }
        GameWatch.addListener(l)
        onDispose { GameWatch.removeListener(l) }
    }

    LaunchedEffect(ok) {   // show the real state if an earlier boost changed something
        if (!ok) return@LaunchedEffect
        withContext(Dispatchers.IO) {
            if (SettingsBackup.has(Keys.REFRESH)) {
                val v = Shell.run("settings get system peak_refresh_rate").trim().toFloatOrNull()?.let { Math.round(it) } ?: 0
                rate = if (v in rates) v else 0
            }
            if (SettingsBackup.has(Keys.ANIM)) {
                fast = (Shell.run("settings get global window_animation_scale").trim().toFloatOrNull() ?: 1f) < 1f
            }
        }
    }

    fun fullBoost() {
        if (busy) return
        if (pkg.isBlank()) { say("! select a game first"); return }
        val gamePkg = pkg
        busy = true
        boosted = false
        launchPct = 0f
        launchStep = "Preparing"
        launching = true
        if (launchSound) sound.startSpin()
        say("> BOOST started")
        scope.launch {
            val steps = mutableListOf<Pair<String, () -> String>>(
                "game mode" to { Boost.gameMode(pkg, mode) },
                "clean ram" to { Boost.killBackground() }
            )
            if (fast) steps.add("fast anim" to { Boost.animations("0.5") })
            if (rate > 0) { val r = rate; steps.add("${r}Hz" to { Boost.refreshRate(r) }) }
            val total = steps.size + 1
            delay(450)   // let the intro animation play
            for ((i, st) in steps.withIndex()) {
                val (n, f) = st
                launchStep = when (n) {
                    "game mode" -> "Applying game mode"
                    "clean ram" -> "Cleaning memory"
                    "fast anim" -> "Speeding up animations"
                    else -> "Setting refresh rate"
                }
                val t0 = System.currentTimeMillis()
                val r = withContext(Dispatchers.IO) { f() }
                say("  [$n] $r")
                val spent = System.currentTimeMillis() - t0
                if (spent < 350) delay(350 - spent)   // keep each step readable
                launchPct = (i + 1f) / total
            }
            boosted = true
            busy = false
            GameWatch.start(gamePkg)
            launchStep = "Launching game"
            launchPct = 1f
            if (launchSound) sound.lock() else sound.stopSpin()
            delay(750)
            startGame()
            delay(700)   // overlay fades out as the game comes to the front
            launching = false
        }
    }

    fun toggleRecord() {
        rec = !rec
        if (rec) run("record") {
            RecEngine.start(ctx)
            "recording ${RecEngine.res(ctx)}% / ${RecEngine.fps(ctx)}fps / ${RecEngine.mbps(ctx)}Mbps (max 3 min)"
        } else run("record stop") { RecEngine.stop(); "saved" }
    }

    if (page == 0) {
        HomeScreen(
            games = games, selected = selected, modeName = modeName(mode), battery = battery, cpu = cpu,
            rec = rec, busy = busy, linked = ok,
            onSelect = { if (it.pkg != pkg && launchSound) sound.tick(); select(it.pkg) },
            onRemove = { saveList(gamePkgs - it.pkg); if (pkg == it.pkg) select("") },
            onStart = {
                if (pkg.isBlank()) Toast.makeText(ctx, "Add a game first (+)", Toast.LENGTH_SHORT).show()
                else { ensureOverlay(); fullBoost() }
            },
            onMode = { mode = mode % 3 + 1; prefs.edit().putInt("mode", mode).apply() },
            onAdd = { showPicker = true },
            onRec = { toggleRecord() },
            onSettings = { page = 1 },
            onExit = { (ctx as? android.app.Activity)?.finish() }
        )
    } else {
        val swColors = SwitchDefaults.colors(
            checkedTrackColor = Cyan, checkedThumbColor = Color.White,
            uncheckedTrackColor = Color(0xFF1A1233), uncheckedThumbColor = Dim, uncheckedBorderColor = Line
        )
        Box(Modifier.fillMaxSize().background(Color(0xFF05070D))) {
            Column(Modifier.fillMaxSize().systemBarsPadding().displayCutoutPadding().padding(horizontal = 12.dp, vertical = 8.dp)) {
                Row(
                    Modifier.clip(RoundedCornerShape(8.dp)).clickable { page = 0 }.padding(horizontal = 6.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("\u2039", color = Color.White, fontSize = 24.sp)
                    Spacer(Modifier.size(12.dp))
                    Text("Settings", color = Color.White, fontWeight = FontWeight.Medium, fontSize = 17.sp)
                }
                Row(Modifier.weight(1f).padding(top = 6.dp)) {
                    // left: categories
                    Column(Modifier.width(132.dp).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        listOf("General settings", "Performance", "Game Data", "Sensitivity", "Recording", "Tools").forEachIndexed { i, n ->
                            val targetTab = when (i) { 0 -> 0; 1 -> 1; 2 -> 4; 3 -> 2; 4 -> 3; else -> 4 }\n                            val sel = tab == targetTab
                            Box(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp))
                                    .background(
                                        if (sel) Brush.horizontalGradient(listOf(Color(0xFF124B9A), Color(0xFF101A30)))
                                        else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
                                    )
                                    .clickable { tab = when (i) { 0 -> 0; 1 -> 1; 2 -> 4; 3 -> 2; 4 -> 3; else -> 4 } }.padding(horizontal = 10.dp, vertical = 13.dp)
                            ) {
                                Text(n, color = if (sel) Color(0xFF4B9BFF) else Color(0xFF8C93A5), fontSize = 13.sp, fontWeight = if (sel) FontWeight.Medium else FontWeight.Normal, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                    // right: rows
                    Column(Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()).padding(start = 16.dp, end = 6.dp, top = 2.dp)) {
                        when (tab) {
                            0 -> {
                                SettingRow("AERO TURBO", "Improve your gaming experience") {
                                    Switch(checked = overlay, colors = swColors, onCheckedChange = { on ->
                                        if (on) {
                                            if (!Settings.canDrawOverlays(ctx)) {
                                                ctx.startActivity(
                                                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))
                                                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                                )
                                                say("! allow 'Display over other apps', then switch on again")
                                            } else {
                                                ctx.startForegroundService(Intent(ctx, OverlayService::class.java))
                                                overlay = true
                                            }
                                        } else {
                                            ctx.stopService(Intent(ctx, OverlayService::class.java))
                                            overlay = false
                                        }
                                    })
                                }
                                SettingRow("In-game shortcuts", "Swipe from the top side edge of the screen to view") {
                                    Switch(checked = inGameShortcuts, colors = swColors, onCheckedChange = {
                                        inGameShortcuts = it
                                        prefs.edit().putBoolean("inGameShortcuts", it).apply()
                                    })
                                }
                                SettingRow("Content recommendations", "Receive gaming-related content recommendations") {
                                    Switch(checked = contentRecommendations, colors = swColors, onCheckedChange = {
                                        contentRecommendations = it
                                        prefs.edit().putBoolean("contentRecommendations", it).apply()
                                    })
                                }
                                SettingRow("Launch sound", "Play a short sound while the game is launching") {
                                    Switch(checked = launchSound, colors = swColors, onCheckedChange = {
                                        launchSound = it
                                        prefs.edit().putBoolean("launchSound", it).apply()
                                        if (it) sound.lock()
                                    })
                                }
                                Spacer(Modifier.size(12.dp))
                                Terminal(log.lines().takeLast(3).joinToString("\\n"))
                            }
                            1 -> {
                                SettingRow("Game mode", "Standard, performance or battery saver for the selected game") {
                                    Box(Modifier.width(230.dp)) {
                                        ModeSelector(mode) { m ->
                                            mode = m
                                            prefs.edit().putInt("mode", m).apply()
                                            run("mode $m", true) { Boost.gameMode(pkg, m) }
                                        }
                                    }
                                }
                                SettingRow(
                                    "Refresh rate lock",
                                    if (rates.size >= 2) "Lock the display to a rate it supports" else "This display has no other refresh rates"
                                ) {
                                    if (rates.size >= 2) Box(Modifier.width(230.dp)) {
                                        RateSelector(rates, rate) { r ->
                                            rate = r
                                            run(if (r > 0) "${r}Hz" else "auto Hz") { Boost.refreshRate(r) }
                                        }
                                    }
                                }
                                SettingRow("Fast animation", "Scale animations to 0.5x") {
                                    Switch(checked = fast, colors = swColors, onCheckedChange = {
                                        fast = it
                                        run("anim") { Boost.animations(if (it) "0.5" else null) }
                                    })
                                }
                            }
                            2 -> {
                                SettingRow("Touch Sensy", "Adjust the sensitivity preference saved by AERO TURBO") {
                                    Column(Modifier.width(230.dp)) {
                                        TouchSensitivity(
                                            level = touchSensy,
                                            onChange = { touchSensy = it },
                                            onDone = { prefs.edit().putInt("touchSensy", touchSensy).apply() }
                                        )
                                    }
                                }
                                SettingRow("Touch response", "Adjust the response profile. 50% keeps the phone default") {
                                    Column(Modifier.width(230.dp), horizontalAlignment = Alignment.End) {
                                        Text("${touch}%  ${touchName(touch)}", color = Cyan, fontWeight = FontWeight.Medium, fontSize = 12.sp)
                                        Slider(
                                            value = touch.toFloat(), onValueChange = { touch = it.toInt().coerceIn(0, 100) },
                                            onValueChangeFinished = {
                                                prefs.edit().putInt("touchPct", touch).apply()
                                                run("touch response $touch%") { Boost.touch(touch) }
                                            },
                                            valueRange = 0f..100f,
                                            colors = SliderDefaults.colors(thumbColor = Cyan, activeTrackColor = Cyan, inactiveTrackColor = Color(0xFF1A1233))
                                        )
                                    }
                                }
                                Text(
                                    "Touch Sensy is stored as an app preference. Actual touchscreen hardware sensitivity depends on Android and your phone manufacturer.",
                                    color = Dim, fontSize = 11.sp, lineHeight = 15.sp,
                                    modifier = Modifier.padding(top = 8.dp, end = 8.dp)
                                )
                            }
                            3 -> {
                                var rFps by remember { mutableStateOf(RecEngine.fps(ctx)) }
                                var rMb by remember { mutableStateOf(RecEngine.mbps(ctx)) }
                                var rRes by remember { mutableStateOf(RecEngine.res(ctx)) }
                                SettingRow("Frame rate", "Lower = lighter on the game. Needs a phone that supports it") {
                                    ChipRow(RecEngine.FPS.map { "$it" }, RecEngine.FPS.indexOf(rFps)) {
                                        rFps = RecEngine.FPS[it]; prefs.edit().putInt("recFps", rFps).apply()
                                    }
                                }
                                SettingRow("Bitrate (Mbps)", "Higher = clearer video, bigger file") {
                                    ChipRow(RecEngine.MBPS.map { "$it" }, RecEngine.MBPS.indexOf(rMb)) {
                                        rMb = RecEngine.MBPS[it]; prefs.edit().putInt("recMbps", rMb).apply()
                                    }
                                }
                                SettingRow("Resolution", "Percent of the screen size. 75% is a good balance") {
                                    ChipRow(RecEngine.RES.map { "$it%" }, RecEngine.RES.indexOf(rRes)) {
                                        rRes = RecEngine.RES[it]; prefs.edit().putInt("recRes", rRes).apply()
                                    }
                                }
                            }
                            else -> {
                                SettingRow("Restore phone settings", "Undo refresh rate, animation and touch changes made by this app", onClick = {
                                    run("restore") { rate = 0; fast = false; boosted = false; touch = 50; prefs.edit().putInt("touchPct", 50).apply(); GameWatch.stop(); SettingsBackup.restore() }
                                }) {
                                    Text("\u203A", color = Dim, fontSize = 22.sp)
                                }
                                SettingRow("Clean RAM", "Close background apps", onClick = { run("clean ram") { Boost.killBackground() } }) {
                                    Text("\u203A", color = Dim, fontSize = 22.sp)
                                }
                                SettingRow("Compile game", "Speed up the selected game", onClick = { run("compile", true) { Boost.compileSpeed(pkg) } }) {
                                    Text("\u203A", color = Dim, fontSize = 22.sp)
                                }
                                SettingRow("Device stats", "RAM and temperature", onClick = { run("stats") { Boost.stats() } }) {
                                    Text("\u203A", color = Dim, fontSize = 22.sp)
                                }
                                Spacer(Modifier.size(12.dp))
                                Terminal(log.lines().takeLast(3).joinToString("\n"))
                            }
                        }
                    }
                }
            }
        }
    }

    if (settled && !ok && !connectLater) {
        ConnectDialog(
            aero,
            onPrimary = {
                when (aero) {
                    AeroAccess.State.NoPermission -> AeroAccess.requestPermission(ctx)
                    AeroAccess.State.NotInstalled -> connectLater = true
                    else -> AeroAccess.openAeroHub(ctx)
                }
            },
            onLater = { connectLater = true }
        )
    }

    if (showPicker) {
        AppPickerDialog(apps, {
            if (it.pkg !in gamePkgs) saveList(gamePkgs + it.pkg)
            select(it.pkg)
            showPicker = false
        }, { showPicker = false })
    }

    AnimatedVisibility(visible = launching, enter = fadeIn(tween(250)), exit = fadeOut(tween(450))) {
        LaunchOverlay(selected?.label ?: "", selected?.icon, launchStep, launchPct)
    }
}

@Composable
fun LaunchOverlay(name: String, icon: ImageBitmap?, step: String, progress: Float) {
    val t = rememberInfiniteTransition(label = "launch")
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "spin")
    val wave by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1800, easing = LinearEasing)), label = "wave")
    val glow by t.animateFloat(0.55f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "glow")
    val pct by animateFloatAsState(progress, tween(350, easing = FastOutSlowInEasing), label = "pct")
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val pop by animateFloatAsState(if (shown) 1f else 0.4f, tween(520, easing = FastOutSlowInEasing), label = "pop")
    val shape = CutCornerShape(topStart = 12.dp, bottomEnd = 12.dp)
    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF05060C), Color(0xFF1A0B33), Color(0xFF05060C))))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { },
        contentAlignment = Alignment.Center
    ) {
        if (icon != null) Image(icon, null, Modifier.fillMaxSize().blur(40.dp).alpha(0.22f), contentScale = ContentScale.Crop)
        Row(
            Modifier.systemBarsPadding().displayCutoutPadding().padding(horizontal = 32.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(170.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val c = size.minDimension / 2
                    // two expanding shock-wave rings
                    for (k in 0..1) {
                        val w = (wave + k * 0.5f) % 1f
                        drawCircle(Cyan.copy(alpha = (1f - w) * 0.5f), radius = c * (0.55f + 0.45f * w), style = Stroke(2.dp.toPx()))
                    }
                    drawCircle(Brush.radialGradient(listOf(Magenta.copy(alpha = 0.35f * glow), Color.Transparent)), radius = c)
                    rotate(spin) {
                        drawCircle(
                            Brush.sweepGradient(listOf(Color.Transparent, Cyan, Magenta, Color.Transparent)),
                            radius = c * 0.62f, style = Stroke(4.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }
                }
                if (icon != null) Image(
                    icon, null,
                    Modifier.size(72.dp).scale(pop).alpha(pop.coerceIn(0f, 1f)).clip(RoundedCornerShape(16.dp))
                )
            }
            Spacer(Modifier.size(28.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    "LAUNCHING", color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp,
                    modifier = Modifier.alpha(glow)
                )
                Text(
                    name, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black, maxLines = 1,
                    overflow = TextOverflow.Ellipsis, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                )
                Spacer(Modifier.size(16.dp))
                Box(Modifier.fillMaxWidth().height(8.dp).clip(shape).background(Color(0xFF141A33)).border(1.dp, Line, shape)) {
                    Box(
                        Modifier.fillMaxWidth(pct.coerceIn(0.04f, 1f)).fillMaxHeight()
                            .background(Brush.horizontalGradient(listOf(Magenta, Cyan)))
                    )
                }
                Spacer(Modifier.size(8.dp))
                Row {
                    Text("> $step", color = Lime, fontFamily = FontFamily.Monospace, fontSize = 11.sp, modifier = Modifier.weight(1f))
                    Text("${(pct * 100).toInt()}%", color = Dim, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                }
            }
        }
    }
}

fun modeName(m: Int) = when (m) { 1 -> "Default"; 3 -> "Battery saver"; else -> "Performance" }

private val HomeBlue = Color(0xFF00E5FF)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(
    games: List<AppInfo>, selected: AppInfo?, modeName: String, battery: Int, cpu: Int,
    rec: Boolean, busy: Boolean, linked: Boolean,
    onSelect: (AppInfo) -> Unit, onRemove: (AppInfo) -> Unit, onStart: () -> Unit, onMode: () -> Unit,
    onAdd: () -> Unit, onRec: () -> Unit, onSettings: () -> Unit, onExit: () -> Unit
) {
    // swipe to change game: one step = previous / next game in the list
    val curIdx = games.indexOfFirst { it.pkg == selected?.pkg }
    val stepGame = { d: Int ->
        if (games.isNotEmpty()) {
            if (curIdx < 0) onSelect(games[0])
            else games.getOrNull((curIdx + d).coerceIn(0, games.lastIndex))?.let { if (it.pkg != selected?.pkg) onSelect(it) }
        }
    }
    val stepNow by rememberUpdatedState(stepGame)
    val swipePx = with(LocalDensity.current) { 40.dp.toPx() }
    val listState = rememberLazyListState()
    LaunchedEffect(curIdx) { if (curIdx >= 0) listState.animateScrollToItem((curIdx - 1).coerceAtLeast(0)) }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF050B18), Color(0xFF0A1428), Color(0xFF050B18))))) {
        Column(Modifier.fillMaxSize().systemBarsPadding().displayCutoutPadding().padding(horizontal = 18.dp, vertical = 12.dp)) {
            // top bar: stats + actions
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(R.drawable.ic_battery, Color(0xFFC9D6F2), 16.dp)
                Text(if (battery >= 0) " $battery%" else " --%", color = Color(0xFFC9D6F2), fontSize = 12.sp)
                Spacer(Modifier.size(18.dp))
                Icon(R.drawable.ic_cpu, Color(0xFFC9D6F2), 16.dp)
                Text(if (cpu >= 0) " $cpu%" else " --%", color = Color(0xFFC9D6F2), fontSize = 12.sp)
                Spacer(Modifier.weight(1f))
                TopAction(R.drawable.ic_plus, Color(0xFFC9D6F2), onAdd)
                Spacer(Modifier.size(26.dp))
                TopAction(R.drawable.ic_video, if (rec) Color(0xFFFF2D55) else Color(0xFFC9D6F2), onRec)
                Spacer(Modifier.size(26.dp))
                TopAction(R.drawable.ic_gear, Color(0xFFC9D6F2), onSettings)
                Spacer(Modifier.size(26.dp))
                TopAction(R.drawable.ic_exit, Color(0xFFC9D6F2), onExit)
            }

            // middle: game list | preview | start
            Row(Modifier.weight(1f).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.weight(1f).fillMaxHeight().pointerInput(Unit) {
                        var acc = 0f
                        detectVerticalDragGestures(
                            onDragStart = { acc = 0f },
                            onDragEnd = { acc = 0f },
                            onDragCancel = { acc = 0f },
                            onVerticalDrag = { change, dy ->
                                change.consume()
                                acc += dy
                                if (acc <= -swipePx) { stepNow(1); acc = 0f }       // swipe up -> next
                                else if (acc >= swipePx) { stepNow(-1); acc = 0f }  // swipe down -> previous
                            }
                        )
                    },
                    contentAlignment = Alignment.CenterStart
                ) {
                    if (games.isEmpty()) {
                        Text("Tap + to add a game", color = Dim, fontSize = 13.sp)
                    } else {
                        LazyColumn(Modifier.fillMaxWidth(), state = listState, userScrollEnabled = false, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(games, key = { it.pkg }) { g ->
                                val sel = g.pkg == selected?.pkg
                                // smooth + light: only draw-phase animations (no re-layout / re-measure per frame)
                                val spec = tween<Float>(220, easing = FastOutSlowInEasing)
                                val hl by animateFloatAsState(if (sel) 1f else 0f, spec, label = "hl")
                                Row(
                                    Modifier.fillMaxWidth()
                                        .drawBehind { drawRect(Brush.horizontalGradient(listOf(Color(0xFF168DFF).copy(alpha = 0.18f * hl), Color.Transparent))) }
                                        .combinedClickable(onClick = { onSelect(g) }, onLongClick = { onRemove(g) })
                                        .padding(vertical = 8.dp, horizontal = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (g.icon != null && sel) {
                                        Image(g.icon, null, Modifier.size(38.dp).clip(RoundedCornerShape(9.dp)))
                                        Spacer(Modifier.size(10.dp))
                                    }
                                    Text(
                                        g.label, color = if (sel) Color.White else Color(0xFF8593AD),
                                        fontSize = 16.sp,
                                        modifier = Modifier.graphicsLayer {
                                            val k = 0.8f + 0.2f * hl
                                            scaleX = k; scaleY = k; transformOrigin = TransformOrigin(0f, 0.5f)
                                        },
                                        fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal,
                                        maxLines = 1, overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.size(16.dp))
                val card = CutCornerShape(topStart = 14.dp, bottomEnd = 14.dp)
                Box(
                    Modifier.weight(1.5f).aspectRatio(1.75f).clip(card)
                        .background(Color(0x14FFFFFF)).border(1.dp, Color(0x33FFFFFF), card)
                        .pointerInput(Unit) {
                            var acc = 0f; var done = false
                            detectHorizontalDragGestures(
                                onDragStart = { acc = 0f; done = false },
                                onDragEnd = { acc = 0f },
                                onDragCancel = { acc = 0f },
                                onHorizontalDrag = { change, dx ->
                                    change.consume()
                                    acc += dx
                                    if (!done && kotlin.math.abs(acc) >= swipePx) {   // one swipe = one step
                                        done = true
                                        stepNow(if (acc < 0) 1 else -1)               // swipe left -> next
                                    }
                                }
                            )
                        },
                    contentAlignment = Alignment.Center
                ) {
                    // preview cross-fades with a gentle zoom when the selected game changes
                    AnimatedContent(
                        targetState = selected,
                        transitionSpec = {
                            val ii = games.indexOfFirst { it.pkg == initialState?.pkg }
                            val ti = games.indexOfFirst { it.pkg == targetState?.pkg }
                            val dir = if (ti >= ii) 1 else -1   // next slides in from the right, previous from the left
                            (slideInHorizontally(tween(260, easing = FastOutSlowInEasing)) { w -> dir * w / 3 } + fadeIn(tween(220)))
                                .togetherWith(slideOutHorizontally(tween(260, easing = FastOutSlowInEasing)) { w -> -dir * w / 3 } + fadeOut(tween(160)))
                        },
                        contentAlignment = Alignment.Center,
                        label = "preview"
                    ) { game ->
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            if (game?.icon != null) {
                                Image(game.icon, null, Modifier.fillMaxSize().alpha(0.3f), contentScale = ContentScale.Crop)
                                Image(game.icon, null, Modifier.size(84.dp).clip(RoundedCornerShape(18.dp)))
                            }
                        }
                    }
                }
                Spacer(Modifier.size(16.dp))
                Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.CenterEnd) {
                    Box(
                        Modifier.width(160.dp).height(54.dp).clip(CutCornerShape(topStart = 14.dp, bottomEnd = 14.dp)).border(1.dp, Cyan, CutCornerShape(topStart = 14.dp, bottomEnd = 14.dp))
                            .background(Brush.horizontalGradient(listOf(Color(0xFF0877D8), Color(0xFF079BEF)))
                            .clickable(enabled = !busy, onClick = onStart),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(if (busy) "BOOSTING..." else "Start playing", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.2.sp)
                    }
                }
            }

            // bottom: mode + hint
            Box(Modifier.fillMaxWidth().height(46.dp), contentAlignment = Alignment.Center) {
                Column(
                    Modifier.width(230.dp).height(48.dp).clip(CutCornerShape(topStart = 18.dp, bottomEnd = 18.dp))
                        .background(Color(0xFF202C3E)).clickable(onClick = onMode).padding(horizontal = 18.dp, vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(Modifier.width(34.dp).height(3.dp).background(Color(0xFF39AFFF), RoundedCornerShape(2.dp)))
                    Spacer(Modifier.height(6.dp))
                    Text(modeName, color = Color(0xFFC9D6F2), fontSize = 13.sp)
                }
                if (!linked) Text(
                    "AeroHUB not linked: open Settings", color = Dim, fontSize = 10.sp,
                    modifier = Modifier.align(Alignment.CenterStart).clickable(onClick = onSettings)
                )
            }
        }
    }
}

@Composable
private fun Icon(res: Int, tint: Color, size: Dp) =
    Image(painterResource(res), null, Modifier.size(size), colorFilter = ColorFilter.tint(tint))

@Composable
private fun TopAction(res: Int, tint: Color, onClick: () -> Unit) =
    Box(Modifier.size(34.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(res, tint, 24.dp)
    }

fun touchName(p: Int) = when {
    p < 15 -> "Lowest"; p < 40 -> "Low"; p <= 60 -> "Normal"; p < 85 -> "High"; else -> "Highest"
}

@Composable
fun TouchSensitivity(level: Int, onChange: (Int) -> Unit, onDone: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Column(Modifier.fillMaxWidth().clip(shape).background(Panel).border(1.dp, Line, shape).padding(horizontal = 12.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("TOUCH SENSITIVITY", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.sp, modifier = Modifier.weight(1f))
            Text(touchName((level - 1) * 25), color = Cyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
        Slider(
            value = level.toFloat(), onValueChange = { onChange(it.toInt().coerceIn(1, 5)) },
            onValueChangeFinished = onDone, valueRange = 1f..5f, steps = 3,
            colors = SliderDefaults.colors(thumbColor = Cyan, activeTrackColor = Cyan, inactiveTrackColor = Color(0xFF1A1233))
        )
        Text("Low = fewer accidental touches, High = faster response", color = Dim, fontSize = 10.sp)
    }
}

@Composable
fun Header(ok: Boolean, onConnect: () -> Unit) {
    val t = rememberInfiniteTransition(label = "dot")
    val a by t.animateFloat(0.3f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "a")
    val c = if (ok) Lime else Magenta
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(
                "AERO BOOST",
                style = TextStyle(
                    brush = Brush.horizontalGradient(listOf(Cyan, Magenta)),
                    fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp
                )
            )
            Text("AERO TURBO ENGINE", color = Dim, fontSize = 9.sp, letterSpacing = 2.sp)
        }
        Row(
            Modifier.clip(RoundedCornerShape(50)).border(1.dp, c, RoundedCornerShape(50))
                .clickable(onClick = onConnect).padding(horizontal = 12.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(c.copy(alpha = a)))
            Spacer(Modifier.size(8.dp))
            Text(if (ok) "LINKED" else "CONNECT", color = c, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GameTile(g: AppInfo, selected: Boolean, onClick: () -> Unit, onLong: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        Modifier.clip(shape).combinedClickable(onClick = onClick, onLongClick = onLong).padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(62.dp).clip(shape)
                .border(
                    if (selected) 2.dp else 1.dp,
                    if (selected) Brush.linearGradient(listOf(Cyan, Magenta)) else Brush.linearGradient(listOf(Line, Line)),
                    shape
                ).background(Panel),
            contentAlignment = Alignment.Center
        ) {
            if (g.icon != null) Image(g.icon, null, Modifier.size(50.dp).clip(RoundedCornerShape(12.dp)))
        }
        Spacer(Modifier.height(4.dp))
        Text(
            g.label, color = if (selected) Cyan else Color.White, fontSize = 10.sp,
            maxLines = 1, overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun AddTile(onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(Modifier.clip(shape).clickable(onClick = onClick).padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(62.dp).clip(shape).border(1.dp, Cyan.copy(alpha = 0.6f), shape), contentAlignment = Alignment.Center) {
            Text("+", color = Cyan, fontSize = 28.sp, fontWeight = FontWeight.Light)
        }
        Spacer(Modifier.height(4.dp))
        Text("Add", color = Cyan, fontSize = 10.sp)
    }
}

@Composable
fun ModeSelector(mode: Int, onPick: (Int) -> Unit) {
    val names = listOf(1 to "STANDARD", 2 to "PERFORMANCE", 3 to "SAVER")
    val shape = CutCornerShape(topStart = 10.dp, bottomEnd = 10.dp)
    Row(Modifier.fillMaxWidth().clip(shape).background(Panel).border(1.dp, Line, shape).padding(3.dp)) {
        names.forEach { (m, n) ->
            val sel = m == mode
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                    .background(
                        if (sel) Brush.horizontalGradient(listOf(Cyan, Magenta))
                        else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
                    )
                    .clickable { onPick(m) }.padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(n, color = if (sel) Bg else Dim, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }
        }
    }
}

@Composable
fun RateSelector(rates: List<Int>, rate: Int, onPick: (Int) -> Unit) {
    val opts = listOf(0) + rates
    val shape = CutCornerShape(topStart = 10.dp, bottomEnd = 10.dp)
    Row(Modifier.fillMaxWidth().clip(shape).background(Panel).border(1.dp, Line, shape).padding(3.dp)) {
        opts.forEach { r ->
            val sel = r == rate
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                    .background(
                        if (sel) Brush.horizontalGradient(listOf(Cyan, Magenta))
                        else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
                    )
                    .clickable { onPick(r) }.padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(if (r == 0) "AUTO" else r.toString(), color = if (sel) Bg else Dim, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }
        }
    }
}

@Composable
fun SwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(Panel).border(1.dp, Line, shape).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.sp)
            Text(sub, color = Dim, fontSize = 10.sp)
        }
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedTrackColor = Cyan, checkedThumbColor = Bg,
                uncheckedTrackColor = Color(0xFF1A1233), uncheckedThumbColor = Dim, uncheckedBorderColor = Line
            )
        )
    }
}

@Composable
fun SettingRow(title: String, sub: String, onClick: (() -> Unit)? = null, trailing: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth()
                .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
                .padding(horizontal = 4.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.Medium, fontSize = 15.sp)
                Text(sub, color = Dim, fontSize = 12.sp)
            }
            Spacer(Modifier.size(12.dp))
            trailing()
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(Line))
    }
}

@Composable
fun BoostButton(size: Dp, busy: Boolean, boosted: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "ring")
    val angle by t.animateFloat(
        0f, 360f, infiniteRepeatable(tween(if (busy) 900 else 5000, easing = LinearEasing)), label = "angle"
    )
    val pulse by t.animateFloat(0.9f, 1f, infiniteRepeatable(tween(1500), RepeatMode.Reverse), label = "pulse")
    val label = when {
        busy -> "BOOSTING"
        boosted -> "BOOSTED"
        else -> "BOOST"
    }
    val accent = if (boosted && !busy) Lime else Cyan
    Box(
        Modifier.size(size).clip(CircleShape).clickable(enabled = enabled && !busy, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val r = this.size.minDimension / 2 - 10.dp.toPx()
            drawCircle(
                Brush.radialGradient(listOf(accent.copy(alpha = 0.28f), Color.Transparent)),
                radius = this.size.minDimension / 2 * pulse
            )
            rotate(angle) {
                drawCircle(
                    Brush.sweepGradient(listOf(Color.Transparent, accent, Magenta, Color.Transparent)),
                    radius = r, style = Stroke(5.dp.toPx(), cap = StrokeCap.Round)
                )
            }
            drawCircle(Panel, radius = r - 9.dp.toPx())
            drawCircle(accent.copy(alpha = 0.35f), radius = r - 9.dp.toPx(), style = Stroke(1.dp.toPx()))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                label,
                style = TextStyle(
                    brush = Brush.horizontalGradient(listOf(accent, Color.White)),
                    fontSize = 18.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp
                )
            )
            Text(if (enabled) "TAP TO PLAY" else "LINK AEROHUB", color = Dim, fontSize = 8.sp, letterSpacing = 1.sp)
        }
    }
}

@Composable
fun ToolCard(title: String, sub: String, color: Color, modifier: Modifier, onClick: () -> Unit) {
    val shape = CutCornerShape(topStart = 10.dp, bottomEnd = 10.dp)
    Column(
        modifier.clip(shape).background(Panel)
            .border(1.dp, Brush.linearGradient(listOf(color, color.copy(alpha = 0.1f))), shape)
            .clickable(onClick = onClick).padding(10.dp)
    ) {
        Text(title, color = color, fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.sp, maxLines = 1)
        Text(sub, color = Dim, fontSize = 9.sp)
    }
}

@Composable
fun Terminal(text: String) {
    val shape = RoundedCornerShape(12.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape).background(Color(0xFF01030A))
            .border(1.dp, Lime.copy(alpha = 0.4f), shape).padding(10.dp)
    ) {
        Text(text, color = Lime, fontFamily = FontFamily.Monospace, fontSize = 10.sp, lineHeight = 13.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
    }
}

data class AppInfo(val label: String, val pkg: String, val icon: ImageBitmap?)

fun loadApps(ctx: Context): List<AppInfo> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .distinctBy { it.activityInfo.packageName }
        .filter { it.activityInfo.packageName != ctx.packageName }
        .map { r ->
            AppInfo(
                r.loadLabel(pm).toString(),
                r.activityInfo.packageName,
                runCatching { r.loadIcon(pm).toBitmap(96, 96).asImageBitmap() }.getOrNull()
            )
        }
        .sortedBy { it.label.lowercase() }
}

@Composable
fun ConnectDialog(state: AeroAccess.State, onPrimary: () -> Unit, onLater: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    val (title, action) = when (state) {
        AeroAccess.State.NotInstalled -> "AeroHUB is not installed" to "OK"
        AeroAccess.State.NoPermission -> "Connect to AeroHUB" to "Allow"
        AeroAccess.State.NotRunning -> "AeroHUB is not running" to "Open AeroHUB"
        AeroAccess.State.Blocked -> "Access is blocked" to "Open AeroHUB"
        AeroAccess.State.Outdated -> "AeroHUB needs a restart" to "Open AeroHUB"
        AeroAccess.State.Ready -> "" to ""
    }
    Dialog(onDismissRequest = onLater) {
        Column(
            Modifier.fillMaxWidth().clip(shape).background(Panel)
                .border(1.dp, Cyan.copy(alpha = 0.5f), shape).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(AeroAccess.message(state), color = Dim, fontSize = 13.sp)
            Text("Aero Boost needs AeroHUB to run boost commands. Without it most features will not work.", color = Dim, fontSize = 11.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).border(1.dp, Line, RoundedCornerShape(10.dp))
                        .clickable(onClick = onLater).padding(vertical = 11.dp),
                    contentAlignment = Alignment.Center
                ) { Text("Later", color = Color.White, fontSize = 13.sp) }
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                        .background(Brush.horizontalGradient(listOf(Color(0xFF7B2FFF), Color(0xFF00E5FF))))
                        .clickable(onClick = onPrimary).padding(vertical = 11.dp),
                    contentAlignment = Alignment.Center
                ) { Text(action, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
            }
        }
    }
}

@Composable
fun AppPickerDialog(apps: List<AppInfo>, onPick: (AppInfo) -> Unit, onDismiss: () -> Unit) {
    var q by remember { mutableStateOf("") }
    val list = apps.filter { it.label.contains(q, ignoreCase = true) }
    val shape = RoundedCornerShape(18.dp)
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier.fillMaxWidth().height(540.dp).clip(shape).background(Panel)
                .border(1.dp, Cyan.copy(alpha = 0.5f), shape).padding(14.dp)
        ) {
            Text("SELECT GAME", color = Cyan, fontWeight = FontWeight.Black, letterSpacing = 3.sp, fontSize = 16.sp)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = q, onValueChange = { q = it },
                placeholder = { Text("Search...", color = Dim) },
                singleLine = true, modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Cyan, unfocusedBorderColor = Color(0xFF1B3550),
                    cursorColor = Cyan, focusedTextColor = Color.White, unfocusedTextColor = Color.White
                )
            )
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.weight(1f)) {
                items(list, key = { it.pkg }) { a ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                            .clickable { onPick(a) }.padding(vertical = 8.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (a.icon != null) Image(a.icon, null, Modifier.size(40.dp).clip(RoundedCornerShape(9.dp)))
                        Spacer(Modifier.size(12.dp))
                        Column {
                            Text(a.label, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(a.pkg, color = Dim, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ChipRow(items: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        items.forEachIndexed { i, t ->
            val on = i == selected
            val shape = RoundedCornerShape(8.dp)
            Box(
                Modifier.clip(shape)
                    .background(if (on) Cyan else Color(0xFF1A1233))
                    .border(1.dp, if (on) Cyan else Line, shape)
                    .clickable { onSelect(i) }
                    .padding(horizontal = 11.dp, vertical = 6.dp)
            ) { Text(t, color = if (on) Bg else Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium) }
        }
    }
}
