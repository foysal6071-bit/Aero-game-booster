package com.example.gameboost

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.PopupWindow
import android.graphics.drawable.ColorDrawable
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.min

/** In-game edge-swipe panel, styled like Xiaomi Aero Turbo. */
class OverlayService : Service() {

    companion object { @Volatile var running = false }

    // Aero Turbo palette: deep navy surfaces, cool blue accents, and crisp pale text
    private val BLUE = 0xFF08B8FF.toInt()
    private val VIOLET = 0xFF287BCE.toInt()
    private val RED = 0xFFFF526B.toInt()
    private val BG = 0xF20A1428.toInt()
    private val TILE = 0xFF14243D.toInt()
    private val LINE = 0x6687B7E8
    private val TXT = 0xFFEAF3FF.toInt()
    private val DIMT = 0xFF9EADC3.toInt()
    private val LIME = 0xFF45E98A.toInt()

    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private var handle: View? = null
    private var scrim: FrameLayout? = null
    private var panelView: View? = null
    private var panelSlide = 0f   // how far the panel travels off-screen when opening/closing
    private var timerTv: TextView? = null

    private var dnd = false
    private var rec = false
    private var recStart = 0L
    private var recTv: TextView? = null
    private var recView: LinearLayout? = null
    private val recTick = object : Runnable {
        override fun run() {
            if (!rec) return
            val t = ((System.currentTimeMillis() - recStart) / 1000).toInt()
            if (t >= 180) { rec = false; recTv?.text = "Record"; recView?.let { setOn(it, false) }; return }
            recTv?.text = "%02d:%02d".format(t / 60, t % 60)
            ui.postDelayed(this, 500)
        }
    }
    private var fps = 0
    private var fpsPop: PopupWindow? = null
    private var gmode = 2
    private var timerRunning = false
    private var timerStart = 0L

    // boost + fps monitor state (lives in the service, so it survives closing/opening the panel)
    @Volatile private var boosted = false
    @Volatile private var boostBusy = false
    private var boostGame = ""
    private var fpsBefore = -1
    private val hist = ArrayList<Int>()
    @Volatile private var monGen = 0
    private var cardRender: (() -> Unit)? = null
    private var onFps: (() -> Unit)? = null
    private val sp by lazy { getSharedPreferences("panel", MODE_PRIVATE) }

    private fun save() {
        sp.edit().putBoolean("boosted", boosted).putString("game", boostGame).putInt("before", fpsBefore)
            .putBoolean("dnd", dnd).putInt("fps", fps).putInt("gmode", gmode).apply()
    }

    private fun load() {
        boosted = sp.getBoolean("boosted", false); boostGame = sp.getString("game", "") ?: ""
        fpsBefore = sp.getInt("before", -1)
        dnd = sp.getBoolean("dnd", false); fps = sp.getInt("fps", if (sp.getBoolean("hz", false)) 120 else 0)
        gmode = sp.getInt("gmode", 2)
    }

    private fun fpsAfter(): Int = synchronized(hist) {
        if (hist.isEmpty()) -1 else hist.takeLast(3).average().toInt()
    }

    private fun startMonitor() {
        val g = ++monGen
        val game = boostGame
        thread(isDaemon = true) {
            while (monGen == g && boosted) {
                val f = FpsMon.sample(game)
                synchronized(hist) { if (f >= 0) { hist.add(f); if (hist.size > 60) hist.removeAt(0) } }
                ui.post { onFps?.invoke() }
                try { Thread.sleep(if (scrim != null) 1000L else 3000L) } catch (_: InterruptedException) {}
            }
        }
    }

    private fun startBoost() {
        if (boostBusy || boosted) return
        boostBusy = true
        toast("Boost...")
        thread {
            val g = currentGame()
            FpsMon.reset()
            val before = FpsMon.sample(g)
            if (g.isNotBlank()) Boost.gameMode(g, gmode)
            Boost.killBackground()
            boostGame = g; fpsBefore = before
            synchronized(hist) { hist.clear() }
            boosted = true; boostBusy = false
            GameWatch.start(g)
            ui.post { save(); cardRender?.invoke(); toast("Boost ON"); startMonitor() }
        }
    }

    private fun stopBoost() {
        boosted = false; monGen++; fps = 0
        GameWatch.stop()
        save()
        cardRender?.invoke()
        thread {
            val r = SettingsBackup.restore()
            ui.post { toast(if (r.startsWith("restore failed")) r else "Boost stopped, settings restored") }
        }
    }

    private val gameEnded: () -> Unit = {
        if (running) {
            boosted = false; monGen++; fps = 0
            save()
            cardRender?.invoke()
            toast("Game closed, boost ended")
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        AeroAccess.init(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("overlay", "Game panel", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "overlay")
            .setContentTitle("Aero Boost")
            .setContentText("Panel appears only inside your selected games")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else startForeground(1, n)
        load()
        startFgWatch()
        if (boosted) startMonitor()
        GameWatch.addListener(gameEnded)
        GameWatch.resume()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    /** Screen rotated (landscape <-> portrait): close the open panel and move the edge tabs. */
    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        if (scrim != null) hidePanel(false)
        ui.postDelayed({
            listOf(handle, handleR).forEach { v ->
                val lp = v?.layoutParams as? WindowManager.LayoutParams ?: return@forEach
                lp.y = handleY()
                runCatching { wm.updateViewLayout(v, lp) }
            }
        }, 300)
    }

    override fun onDestroy() {
        running = false
        fgGen++
        monGen++
        GameWatch.removeListener(gameEnded)
        if (boosted || GameWatch.active) {   // panel closed while boosting: give the phone its settings back
            boosted = false
            GameWatch.stop()
            thread { SettingsBackup.restore() }
        }
        save()
        ui.removeCallbacksAndMessages(null)
        hidePanel(false)
        handle?.let { runCatching { wm.removeView(it) } }
        handleR?.let { runCatching { wm.removeView(it) } }
        handle = null; handleR = null; handlesShown = false
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun ripple(content: android.graphics.drawable.Drawable, r: Int) =
        android.graphics.drawable.RippleDrawable(
            android.content.res.ColorStateList.valueOf(0x33FFFFFF), content, box(Color.WHITE, r)
        )

    /** Angular (chamfered-corner) neon frame, the core of the gaming look. */
    private fun gbox(fill: Int, stroke: Int, cut: Int = 8, fill2: Int = fill) =
        Chamfer(fill, fill2, stroke, cut * resources.displayMetrics.density, resources.displayMetrics.density)

    private fun gripple(content: android.graphics.drawable.Drawable, cut: Int = 8) =
        android.graphics.drawable.RippleDrawable(
            android.content.res.ColorStateList.valueOf(0x4400E5FF), content, gbox(Color.WHITE, 0, cut)
        )

    private fun panelBg() = gbox(0xF20A1428.toInt(), 0xAA68BFFF.toInt(), 12, 0xF2122038.toInt())

    private fun tileBg(on: Boolean) =
        gripple(if (on) gbox(0x2245E98A, 0xCC45E98A.toInt(), 7) else gbox(TILE, LINE, 7, 0xFF192B46.toInt()), 7)

    private fun glow(tv: TextView, color: Int) = tv.apply { setShadowLayer(dp(6).toFloat(), 0f, 0f, color) }

    private fun box(fill: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(r).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    // ---------- edge handle (single, left edge) ----------
    private var panelRight = false
    private var handleR: View? = null

    private fun screenH() = resources.displayMetrics.heightPixels.coerceAtLeast(1)
    private fun isPortrait() = resources.displayMetrics.heightPixels > resources.displayMetrics.widthPixels
    private fun handleKey() = if (isPortrait()) "handleY_port" else "handleY_land"
    private fun handleY(): Int {
        val h = screenH()
        val f = sp.getFloat(handleKey(), 0.18f)
        return (h * f).toInt().coerceIn(0, (h - dp(80)).coerceAtLeast(0))
    }

    private fun makeHandle(right: Boolean): View {
        val sideG = if (right) Gravity.END else Gravity.START
        val r = dp(8).toFloat()
        // slim MIUI-style tab: only 10dp wide on screen, the touch area around it stays wider
        val v = FrameLayout(this)
        val tab = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setColor(0xE60A0D18.toInt())
                setStroke(dp(1), 0xAA00E5FF.toInt())
                cornerRadii = if (right) floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r) else floatArrayOf(0f, 0f, r, r, r, r, 0f, 0f)
            }
        }
        tab.addView(View(this).apply { background = box(BLUE, 1) },
            FrameLayout.LayoutParams(dp(2), dp(20), Gravity.CENTER))
        v.addView(tab, FrameLayout.LayoutParams(dp(10), dp(56), sideG or Gravity.CENTER_VERTICAL))
        var downX = 0f; var downY = 0f; var startY = 0
        var fired = false; var moving = false
        val longPress = Runnable {
            moving = true
            tab.animate().scaleX(1.25f).scaleY(1.1f).alpha(0.85f).setDuration(100).start()
            v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
        }
        v.setOnTouchListener { _, e ->
            val lp = v.layoutParams as? WindowManager.LayoutParams
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; fired = false; moving = false
                    startY = lp?.y ?: 0
                    ui.postDelayed(longPress, 350)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (moving) {
                        // long-press, then slide up/down to place the tab
                        if (lp != null) {
                            val maxY = (screenH() - lp.height).coerceAtLeast(0)
                            lp.y = (startY + (e.rawY - downY).toInt()).coerceIn(0, maxY)
                            runCatching { wm.updateViewLayout(v, lp) }
                        }
                    } else {
                        if (abs(e.rawY - downY) > dp(8) || abs(e.rawX - downX) > dp(8)) ui.removeCallbacks(longPress)
                        val d = if (right) downX - e.rawX else e.rawX - downX
                        if (!fired && d > dp(14)) { fired = true; panelRight = right; showPanel() }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    ui.removeCallbacks(longPress)
                    if (moving) {
                        moving = false
                        tab.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(120).start()
                        if (lp != null) sp.edit().putFloat(handleKey(), lp.y.toFloat() / screenH()).apply()
                    } else if (e.actionMasked == MotionEvent.ACTION_UP && !fired && abs(e.rawX - downX) < dp(6) && abs(e.rawY - downY) < dp(6)) {
                        panelRight = right; showPanel()
                    }
                }
            }
            true
        }
        v.addOnLayoutChangeListener { view, l, t, rr, bt, _, _, _, _ ->
            if (Build.VERSION.SDK_INT >= 29)
                view.systemGestureExclusionRects = listOf(android.graphics.Rect(0, 0, rr - l, bt - t))
        }
        val dm = resources.displayMetrics
        val lp = WindowManager.LayoutParams(
            dp(24), dp(80),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = sideG or Gravity.TOP
            y = handleY()   // saved spot per orientation; default: upper part of the left edge
            if (Build.VERSION.SDK_INT >= 28)
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(v, lp)
        return v
    }

    private fun addHandle() {
        handle = makeHandle(false)   // one tab, left edge; long-press + slide to move up/down
    }

    // ---------- edge tabs exist only while a selected game is on screen ----------
    @Volatile private var fgGen = 0
    private var handlesShown = false

    private fun selectedGames(): Set<String> =
        (getSharedPreferences("games", MODE_PRIVATE).getString("list", "") ?: "")
            .split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()

    /** Package of the app on screen right now, or null if it could not be read. */
    private fun topPackage(): String? {
        val r = Shell.run("dumpsys activity activities | grep -m1 -E 'topResumedActivity|mResumedActivity'")
        return Regex("([a-zA-Z][a-zA-Z0-9_]*(?:\\.[a-zA-Z0-9_]+)+)/").find(r)?.groupValues?.get(1)
    }

    private fun showHandles() {
        if (handlesShown) return
        handlesShown = true
        addHandle()
    }

    /** Game left the screen: the edge tabs and an open panel disappear. */
    private fun hideHandles() {
        if (!handlesShown) return
        handlesShown = false
        if (scrim != null) hidePanel(false)
        handle?.let { runCatching { wm.removeView(it) } }
        handleR?.let { runCatching { wm.removeView(it) } }
        handle = null; handleR = null
    }

    private fun startFgWatch() {
        val g = ++fgGen
        val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
        thread(isDaemon = true) {
            while (fgGen == g) {
                if (pm.isInteractive) {
                    val top = topPackage()
                    // unreadable result or system UI (shade, recents) on top: keep the current state
                    if (top != null && !top.startsWith("com.android.systemui")) {
                        val inGame = top in selectedGames()
                        ui.post { if (fgGen == g) { if (inGame) showHandles() else hideHandles() } }
                    }
                }
                try { Thread.sleep(1000) } catch (_: InterruptedException) {}
            }
        }
    }

    // ---------- panel window ----------
    private fun showPanel() {
        if (scrim != null) return
        AeroAccess.startPolling(this)
        val dm = resources.displayMetrics
        val right = panelRight
        val s = FrameLayout(this).apply {
            setBackgroundColor(0x99000000.toInt())
            setOnClickListener { hidePanel() }
        }
        val sw = dm.widthPixels.toFloat(); val sh = dm.heightPixels.toFloat()
        val portrait = sh > sw
        val stripW: Int; val gap: Int; val mainW: Int; val mainH: Int; val stripH: Int
        val edgeM: Float; val topM: Int
        if (portrait) {
            // portrait: nearly full width, height from content (scrolls if the screen is short)
            edgeM = sw * 0.02f
            stripW = (sw * 0.115f).toInt()
            gap = (sw * 0.012f).toInt()
            mainW = (sw - 2 * edgeM).toInt() - stripW - gap
            mainH = (sh * 0.58f).toInt().coerceIn(dp(400), dp(580)).coerceAtMost((sh * 0.82f).toInt())
            stripH = (mainH + dp(24)).coerceAtMost((sh * 0.92f).toInt())
            topM = (sh * 0.07f).toInt()
        } else {
            edgeM = sw * 0.048f
            stripW = (sw * 0.068f).toInt()
            gap = (sw * 0.012f).toInt()
            mainW = (sw * 0.333f).toInt()
            mainH = (sh * 0.814f).toInt()
            stripH = (sh * 0.91f).toInt()
            topM = (sh * 0.038f).toInt()
        }
        val p = buildPanel(stripW, stripH, mainW, mainH, gap)
        s.addView(p, FrameLayout.LayoutParams(stripW + gap + mainW, ViewGroup.LayoutParams.WRAP_CONTENT,
            if (portrait) Gravity.CENTER else (if (right) Gravity.END else Gravity.START) or Gravity.TOP).apply {
            if (!portrait) {
                val m = edgeM.toInt()
                if (right) rightMargin = m else leftMargin = m
                topMargin = topM
            }
        })
        wm.addView(
            s,
            WindowManager.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                if (Build.VERSION.SDK_INT >= 28)
                    layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        )
        scrim = s
        panelView = p
        // open animation: dim fades in, panel slides in from its edge with a soft fade
        val m = edgeM
        panelSlide = (stripW + gap + mainW) + m
        s.alpha = 0f
        p.translationX = if (right) panelSlide else -panelSlide
        p.alpha = 0f
        s.animate().alpha(1f).setDuration(240).setInterpolator(DecelerateInterpolator()).start()
        p.animate().translationX(0f).alpha(1f).setDuration(280)
            .setInterpolator(DecelerateInterpolator(1.8f)).start()
    }

    private fun hidePanel(animate: Boolean = true) {
        save()
        cardRender = null; onFps = null; recTv = null; recView = null
        fpsPop?.dismiss(); fpsPop = null
        AeroAccess.stopPolling()
        val s = scrim
        val p = panelView
        scrim = null
        panelView = null
        timerTv = null
        if (s == null) return
        val remove = { runCatching { wm.removeView(s) }; Unit }
        if (!animate || p == null) { remove(); return }
        // close animation: panel slides back out while the dim fades away, then the window is removed
        s.isClickable = false
        s.setOnClickListener(null)
        val out = if (panelRight) panelSlide else -panelSlide
        s.animate().alpha(0f).setDuration(200).setInterpolator(AccelerateInterpolator()).start()
        p.animate().translationX(out).alpha(0f).setDuration(220)
            .setInterpolator(AccelerateInterpolator(1.5f)).withEndAction { remove() }.start()
        ui.postDelayed({ remove() }, 400)   // safety net if the animation is cancelled
    }

    // ---------- UI pieces ----------
    private fun ic(res: Int, tint: Int) = ImageView(this).apply {
        setImageResource(res)
        setColorFilter(tint)
    }

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun badge(res: Int, tint: Int, bg: Int, size: Int = 34, icon: Int = 20) = FrameLayout(this).apply {
        background = box(bg, size / 2)
        addView(ic(res, tint), FrameLayout.LayoutParams(dp(icon), dp(icon), Gravity.CENTER))
        layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
    }

    private fun actionTile(res: Int, text: String, click: () -> Unit): LinearLayout {
        val me = this
        return LinearLayout(me).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = tileBg(false)
            setPadding(dp(2), dp(3), dp(2), dp(3))
            addView(badge(res, BLUE, 0x2600E5FF, 28, 17))
            addView(label(text, 9f, TXT, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(2), 0, 0); maxLines = 2 })
            setOnClickListener { click() }
        }
    }

    private fun toolItem(res: Int, text: String, on: Boolean, click: (LinearLayout) -> Unit): LinearLayout {
        val me = this
        return LinearLayout(me).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = tileBg(on)
            setPadding(dp(1), dp(3), dp(1), dp(3))
            addView(badge(res, if (on) LIME else BLUE, if (on) 0x2639FF88 else 0x2600E5FF, 26, 16))
            addView(label(text, 8.5f, if (on) LIME else TXT, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(2), 0, 0); maxLines = 1 })
            setOnClickListener { click(this) }
        }
    }

    private fun setOn(v: LinearLayout, on: Boolean) {
        val b = v.getChildAt(0) as FrameLayout
        v.background = tileBg(on)
        b.background = box(if (on) 0x2639FF88 else 0x2600E5FF, 11)
        (b.getChildAt(0) as ImageView).setColorFilter(if (on) LIME else BLUE)
        (v.getChildAt(1) as TextView).setTextColor(if (on) LIME else TXT)
    }

    private fun wideTile(res: Int, text: String, filled: Boolean, click: () -> Unit): Pair<LinearLayout, TextView> {
        val me = this
        val tv = label(text, 11f, TXT, true).apply { setPadding(dp(6), 0, 0, 0); maxLines = 1; letterSpacing = 0.08f }
        val l = LinearLayout(me).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = gripple(gbox(TILE, LINE, 7, 0xFF141030.toInt()), 7)
            setPadding(dp(6), dp(7), dp(6), dp(7))
            addView(ic(res, BLUE), LinearLayout.LayoutParams(dp(18), dp(18)))
            addView(tv)
            setOnClickListener { click() }
        }
        return l to tv
    }

    private fun gameName() = when (gmode) { 1 -> "Standard"; 3 -> "Saver"; else -> "Perform" }

    private fun buildPanel(stripW: Int, stripH: Int, mainW: Int, mainH: Int, gap: Int): LinearLayout {
        val me = this
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val root = LinearLayout(me).apply { orientation = LinearLayout.HORIZONTAL; isClickable = true }

        // --- left strip: games ---
        val strip = LinearLayout(me).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(4), dp(6), dp(4), dp(6)) }
        val iconPx = (stripW - dp(8)).coerceAtLeast(dp(24))
        (getSharedPreferences("games", MODE_PRIVATE).getString("list", "") ?: "")
            .split(",").filter { it.isNotBlank() }.forEach { p ->
                try {
                    val iv = ImageView(me).apply {
                        setImageDrawable(packageManager.getApplicationIcon(p))
                        background = box(Color.TRANSPARENT, 9, 0x6600E5FF); clipToOutline = true
                        setOnClickListener { launchFloating(p) }
                        setOnLongClickListener { launchNormal(p); hidePanel(); true }   // long-press = full screen
                    }
                    strip.addView(iv, LinearLayout.LayoutParams(iconPx, iconPx).apply { setMargins(0, dp(3), 0, dp(3)) })
                } catch (_: Throwable) {}
            }
        root.addView(ScrollView(me).apply { background = panelBg(); addView(strip) }, LinearLayout.LayoutParams(stripW, stripH))

        // --- main panel (everything fits in 4 columns) ---
        val col = LinearLayout(me).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(6), dp(8), dp(8)) }
        val mainSv = ScrollView(me).apply { background = panelBg(); isFillViewport = true; addView(col) }

        val head = LinearLayout(me).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(glow(label("AERO TURBO", 13f, BLUE, true), 0xCC00E5FF.toInt()).apply {
            letterSpacing = 0.18f; setTypeface(Typeface.DEFAULT_BOLD, Typeface.BOLD_ITALIC)
        }, LinearLayout.LayoutParams(wrap, wrap))
        val linked = AeroAccess.state == AeroAccess.State.Ready
        head.addView(View(me).apply { background = box(if (linked) LIME else RED, 3) },
            LinearLayout.LayoutParams(dp(6), dp(6)).apply { leftMargin = dp(8) })
        head.addView(label(if (linked) "Linked" else "Not linked", 10f, DIMT).apply { setPadding(dp(4), 0, 0, 0) },
            LinearLayout.LayoutParams(0, wrap, 1f))
        col.addView(head)

        fun cell() = LinearLayout.LayoutParams(0, match, 1f).apply { leftMargin = dp(6) }
        fun cellFirst() = LinearLayout.LayoutParams(0, match, 1f)

        // ---- top block: [Clear memory / Free storage] | [Boost performance card] ----
        val top = LinearLayout(me).apply { orientation = LinearLayout.HORIZONTAL }

        val leftCol = LinearLayout(me).apply { orientation = LinearLayout.VERTICAL }
        leftCol.addView(actionTile(R.drawable.ic_rocket, "Clear memory") { act("Clear memory") { Boost.killBackground() } },
            LinearLayout.LayoutParams(match, 0, 1f))
        leftCol.addView(actionTile(R.drawable.ic_trash, "Free up storage") { act("Free storage") { Shell.run("pm trim-caches 100G") } },
            LinearLayout.LayoutParams(match, 0, 1f).apply { topMargin = dp(4) })
        top.addView(leftCol, LinearLayout.LayoutParams((mainW * 0.25f).toInt(), match))

        val card = LinearLayout(me).apply { orientation = LinearLayout.VERTICAL }
        val YEL = 0xFFFFD60A.toInt()
        var afterTv: TextView? = null
        var beforeTv: TextView? = null
        var chart: View? = null

        fun infoRow(res: Int, text: String, click: () -> Unit) {
            card.addView(View(me).apply { setBackgroundColor(LINE) },
                LinearLayout.LayoutParams(match, dp(1)).apply { topMargin = dp(2) })
            card.addView(LinearLayout(me).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = ripple(box(Color.TRANSPARENT, 6), 6)
                setPadding(0, dp(6), 0, dp(6))
                addView(ic(res, BLUE), LinearLayout.LayoutParams(dp(16), dp(16)))
                addView(label(text, 9.5f, TXT, true).apply { maxLines = 1; setPadding(dp(8), 0, 0, 0) })
                setOnClickListener { click() }
            }, LinearLayout.LayoutParams(match, wrap))
        }

        fun fmt(v: Int) = if (v < 0) "--" else v.toString()

        fun renderCard() {
            card.removeAllViews()
            card.setPadding(dp(7), dp(5), dp(7), dp(5))
            if (!boosted) {
                afterTv = null; beforeTv = null; chart = null
                card.background = gbox(TILE, 0x9900E5FF.toInt(), 9, 0xFF141030.toInt())
                card.addView(label("BOOST PERFORMANCE", 9.5f, TXT, true).apply { gravity = Gravity.END; letterSpacing = 0.08f },
                    LinearLayout.LayoutParams(match, wrap))
                infoRow(R.drawable.ic_tune, "Clear memory automatically") { act("Clear memory") { Boost.killBackground() } }
                infoRow(R.drawable.ic_storage, "Free up storage space") { act("Free storage") { Shell.run("pm trim-caches 100G") } }
                infoRow(R.drawable.ic_chart, "Monitor performance") { act("Monitor") { Boost.stats() } }
                card.addView(View(me), LinearLayout.LayoutParams(match, 0, 1f))
                card.addView(glow(label(if (boostBusy) "BOOSTING..." else "BOOST", 12f, Color.WHITE, true), 0xFF00E5FF.toInt()).apply {
                    gravity = Gravity.CENTER; letterSpacing = 0.2f
                    background = gripple(gbox(0xFF087BEE.toInt(), 0xFF62C8FF.toInt(), 7, 0xFF078FFF.toInt()), 7)
                    setPadding(0, dp(5), 0, dp(5))
                    setOnClickListener { startBoost(); text = "BOOSTING..." }
                }, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(4) })
            } else {
                card.background = gbox(0x1AFFD60A, 0xCCFFD60A.toInt(), 9)
                card.addView(glow(label("PERFORMANCE", 9.5f, YEL, true), 0x99FFD60A.toInt()).apply { gravity = Gravity.END; letterSpacing = 0.08f },
                    LinearLayout.LayoutParams(match, wrap))
                val cv = FpsChart(me, hist, YEL, DIMT)
                chart = cv
                card.addView(cv, LinearLayout.LayoutParams(match, 0, 1f).apply { topMargin = dp(2) })
                val stats = LinearLayout(me).apply { orientation = LinearLayout.HORIZONTAL }
                val aT = label("", 9.5f, TXT, true); val bT = label("", 9.5f, DIMT, true)
                afterTv = aT; beforeTv = bT
                stats.addView(aT, LinearLayout.LayoutParams(0, wrap, 1f))
                stats.addView(bT, LinearLayout.LayoutParams(wrap, wrap))
                card.addView(stats, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(2) })
                card.addView(label("STOP", 11f, YEL, true).apply {
                    gravity = Gravity.CENTER; letterSpacing = 0.2f
                    background = gripple(gbox(0x33FFD60A, 0xCCFFD60A.toInt(), 6), 6)
                    setPadding(0, dp(4), 0, dp(4))
                    setOnClickListener { stopBoost() }
                }, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(3) })
                onFps = {
                    afterTv?.text = "\u25CF ${fmt(fpsAfter())} FPS  After"
                    beforeTv?.text = "\u25CB ${fmt(fpsBefore)} FPS  Before"
                    chart?.invalidate()
                }
                onFps?.invoke()
            }
        }
        cardRender = { renderCard() }
        renderCard()
        top.addView(card, LinearLayout.LayoutParams(0, match, 1f).apply { leftMargin = dp(4) })
        col.addView(top, LinearLayout.LayoutParams(match, 0, 1.9f).apply { topMargin = dp(6) })

        // ---- tools strip (scrolls sideways) ----
        // exactly 4 tools fit the visible width (no half-cut tile); the rest scroll in and snap to a tile edge
        val toolSlot = (mainW - dp(16) - dp(2)) / 4
        val toolW = toolSlot - dp(2)
        var dragActive = false
        val tp = { LinearLayout.LayoutParams(toolW, match).apply { setMargins(dp(1), dp(1), dp(1), dp(1)) } }
        val strip2 = LinearLayout(me).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(2), dp(2), dp(2), dp(2)) }
        val tools = LinkedHashMap<String, LinearLayout>()
        fun reg(id: String, v: LinearLayout) { tools[id] = v }
        reg("shot", toolItem(R.drawable.ic_cut, "Screenshot", false) {
            hidePanel()
            ui.postDelayed({
                thread {
                    val r = Shell.run("mkdir -p /sdcard/Pictures/AeroBoost; screencap -p /sdcard/Pictures/AeroBoost/shot_${System.currentTimeMillis()}.png")
                    ui.post { toast(if (r == "OK") "Screenshot saved" else r) }
                }
            }, 400)
        })
        reg("rec", toolItem(R.drawable.ic_video, "Record", rec) { v ->
            rec = !rec; setOn(v, rec)
            if (rec) {
                recStart = System.currentTimeMillis()
                recView = v; recTv = v.getChildAt(1) as TextView
                recTv?.text = "00:00"
                ui.removeCallbacks(recTick); ui.post(recTick)
                hidePanel()
                thread {
                    RecEngine.start(me)
                    ui.post { toast("Recording...") }
                }
            } else {
                ui.removeCallbacks(recTick)
                (v.getChildAt(1) as TextView).text = "Record"
                act("Record stop") { RecEngine.stop(); "saved" }
            }
        }.also { v ->
            if (rec) { recView = v; recTv = v.getChildAt(1) as TextView; ui.removeCallbacks(recTick); ui.post(recTick) }
        })
        reg("dnd", toolItem(R.drawable.ic_dnd, "DND", dnd) { v ->
            dnd = !dnd; setOn(v, dnd)
            act("DND " + if (dnd) "on" else "off") { Shell.run("cmd notification set_dnd " + if (dnd) "on" else "off") }
        })
        reg("settings", toolItem(R.drawable.ic_gear, "Settings", false) {
            hidePanel()
            startActivity(Intent(me, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        })
        reg("fps", toolItem(R.drawable.ic_bolt, if (fps > 0) "FPS $fps" else "FPS", fps > 0) { v ->
            showFpsPopup(v) { n ->
                fps = n; setOn(v, n > 0)
                (v.getChildAt(1) as TextView).text = if (n > 0) "FPS $n" else "FPS"
                save()
                act(if (n > 0) "FPS $n" else "FPS auto") { Boost.refreshRate(n) }
            }
        })
        reg("mode", toolItem(R.drawable.ic_rocket, gameName(), false) { v ->
            gmode = gmode % 3 + 1
            (v.getChildAt(1) as TextView).text = gameName()
            act("Mode " + gameName()) { Boost.gameMode(currentGame(), gmode) }
        })

        // ---- saved order (long-press + drag to rearrange) ----
        val saved = (sp.getString("toolOrder", "") ?: "").split(",").filter { it in tools }
        val order = (saved + tools.keys.filter { it !in saved }).toMutableList()
        fun fillStrip() {
            strip2.removeAllViews()
            order.forEach { strip2.addView(tools[it]!!, tp()) }
        }
        fillStrip()

        val hsv = HorizontalScrollView(me).apply {
            isHorizontalScrollBarEnabled = false
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
            background = gbox(0x55304460, LINE, 9)
            addView(strip2, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, match))
        }
        col.addView(hsv, LinearLayout.LayoutParams(match, 0, 0.85f).apply { topMargin = dp(6) })
        val snap = Runnable {
            if (!dragActive && toolSlot > 0) {
                val target = Math.round(hsv.scrollX / toolSlot.toFloat()) * toolSlot
                if (target != hsv.scrollX) hsv.smoothScrollTo(target, 0)
            }
        }
        hsv.setOnScrollChangeListener { _, _, _, _, _ -> ui.removeCallbacks(snap); ui.postDelayed(snap, 120) }

        // Long-press a tool, then slide it left/right to a new spot. The others make room; order is saved.
        fun attachDrag(v: LinearLayout) {
            var dragging = false
            var fromIdx = 0; var curIdx = 0
            var downRawX = 0f; var lastRawX = 0f; var downScroll = 0
            var slotW = 1f
            var origBg: android.graphics.drawable.Drawable? = null

            fun update() {
                val n = strip2.childCount
                val raw = (lastRawX - downRawX) + (hsv.scrollX - downScroll)
                val tx = raw.coerceIn(-fromIdx * slotW, (n - 1 - fromIdx) * slotW)
                v.translationX = tx
                val target = Math.round(fromIdx + tx / slotW).coerceIn(0, n - 1)
                if (target != curIdx) {
                    curIdx = target
                    for (j in 0 until n) {
                        if (j == fromIdx) continue
                        val d = when {
                            fromIdx < curIdx && j in (fromIdx + 1)..curIdx -> -slotW
                            fromIdx > curIdx && j in curIdx until fromIdx -> slotW
                            else -> 0f
                        }
                        strip2.getChildAt(j).animate().translationX(d).setDuration(130).start()
                    }
                }
            }

            val autoScroll = object : Runnable {
                override fun run() {
                    if (!dragging) return
                    val loc = IntArray(2); hsv.getLocationOnScreen(loc)
                    val x = lastRawX - loc[0]
                    val edge = dp(28)
                    val dx = when { x < edge -> -dp(5); x > hsv.width - edge -> dp(5); else -> 0 }
                    if (dx != 0) { hsv.scrollBy(dx, 0); update() }
                    ui.postDelayed(this, 16)
                }
            }

            fun drop() {
                dragging = false; dragActive = false
                ui.removeCallbacks(autoScroll)
                v.isPressed = false
                v.animate().translationX((curIdx - fromIdx) * slotW).scaleX(1f).scaleY(1f).alpha(1f)
                    .setDuration(130).withEndAction {
                        if (curIdx != fromIdx) {
                            val id = order.removeAt(fromIdx); order.add(curIdx, id)
                            sp.edit().putString("toolOrder", order.joinToString(",")).apply()
                        }
                        for (i in 0 until strip2.childCount) strip2.getChildAt(i).apply {
                            animate().cancel(); translationX = 0f; translationZ = 0f
                        }
                        v.background = origBg
                        fillStrip()
                    }.start()
            }

            v.setOnLongClickListener {
                val n = strip2.childCount
                if (n < 2) return@setOnLongClickListener true
                dragging = true; dragActive = true
                fromIdx = strip2.indexOfChild(v); curIdx = fromIdx
                slotW = (strip2.getChildAt(1).left - strip2.getChildAt(0).left).toFloat().coerceAtLeast(1f)
                downScroll = hsv.scrollX; downRawX = lastRawX
                hsv.requestDisallowInterceptTouchEvent(true)
                v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                origBg = v.background
                v.background = gbox(0x553B1A66, 0xFFB05CFF.toInt(), 7, 0x5500B8FF)
                v.translationZ = dp(12).toFloat()
                v.animate().scaleX(1.1f).scaleY(1.1f).alpha(0.95f).setDuration(120).start()
                ui.post(autoScroll)
                true
            }
            v.setOnTouchListener { _, e ->
                lastRawX = e.rawX
                if (!dragging) false else {
                    when (e.actionMasked) {
                        MotionEvent.ACTION_MOVE -> update()
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> drop()
                    }
                    true
                }
            }
        }
        tools.values.forEach { attachDrag(it) }

        // ---- bottom row: Timer ----
        val (timerTile, ttv) = wideTile(R.drawable.ic_hourglass, timerText(), false) {}
        timerTv = ttv
        timerTile.setOnClickListener {
            timerRunning = !timerRunning
            if (timerRunning) { timerStart = System.currentTimeMillis(); tick() }
            timerTv?.text = timerText()
        }
        if (timerRunning) tick()
        val bottom = LinearLayout(me).apply { orientation = LinearLayout.HORIZONTAL }
        bottom.addView(timerTile, LinearLayout.LayoutParams(0, match, 1f))
        col.addView(bottom, LinearLayout.LayoutParams(match, 0, 0.6f).apply { topMargin = dp(6) })

        root.addView(mainSv, LinearLayout.LayoutParams(mainW, mainH).apply { leftMargin = gap })
        return root
    }

    // ---------- helpers ----------
    private fun timerText(): String {
        if (!timerRunning) return "Timer"
        val s = (System.currentTimeMillis() - timerStart) / 1000
        return "%02d:%02d".format(s / 60, s % 60)
    }

    private fun tick() {
        ui.removeCallbacks(tickRun)
        ui.postDelayed(tickRun, 1000)
    }

    private val tickRun = object : Runnable {
        override fun run() {
            if (!timerRunning) return
            timerTv?.text = timerText()
            ui.postDelayed(this, 1000)
        }
    }

    private fun launchNormal(p: String) {
        packageManager.getLaunchIntentForPackage(p)?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); runCatching { startActivity(it) }
        }
    }

    private fun settingOn(key: String) = runCatching {
        android.provider.Settings.Global.getInt(contentResolver, key, 0) == 1
    }.getOrDefault(false)

    /** Opens the app in a freeform (floating) window. If the two developer options are off, asks the user to enable them first. */
    private fun launchFloating(p: String) {
        val missing = mutableListOf<String>()
        if (!settingOn("enable_freeform_support")) missing += "Enable freeform windows"
        if (!settingOn("force_resizable_activities")) missing += "Force activities to be resizable"
        if (missing.isEmpty()) startFloating(p) else showFloatPrompt(p, missing)
    }

    private fun startFloating(p: String) {
        hidePanel()
        val comp = packageManager.getLaunchIntentForPackage(p)?.component?.flattenToShortString()
        if (comp == null || !Shell.ready()) { launchNormal(p); return }
        thread {
            val r = Shell.run("am start --user 0 --windowingMode 5 -n ${AeroAccess.sq(comp)}")
            if (r.startsWith("Error") || r.startsWith("exit") || r.contains("Error type", true))
                ui.post { toast("Floating window not supported here, opening normally"); launchNormal(p) }
        }
    }

    private fun showFloatPrompt(p: String, missing: List<String>) {
        var v: FrameLayout? = null
        val close = { v?.let { runCatching { wm.removeView(it) } }; v = null }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = gbox(BG, 0xCC00E5FF.toInt(), 12)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            isClickable = true
            addView(label("Turn on in Developer options", 13f, TXT, true))
            addView(label(missing.joinToString("\n") { "•  $it" }, 12f, BLUE).apply { setPadding(0, dp(8), 0, dp(4)) })
            addView(label("Floating windows need both switched on.", 10f, DIMT))
            val row = LinearLayout(this@OverlayService).apply { orientation = LinearLayout.HORIZONTAL }
            fun btn(t: String, fill: Boolean, c: () -> Unit) = label(t, 11f, if (fill) Color.WHITE else TXT, true).apply {
                gravity = Gravity.CENTER
                background = if (fill) gbox(0xFF7B2FFF.toInt(), 0xFF00E5FF.toInt(), 7, 0xFF00B8FF.toInt()) else gbox(Color.TRANSPARENT, LINE, 7)
                setPadding(0, dp(8), 0, dp(8))
                setOnClickListener { c() }
            }
            row.addView(btn("Open settings", true) {
                close()
                hidePanel()
                runCatching {
                    startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }.onFailure { toast("Open Settings > Developer options") }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(btn("Try anyway", false) {
                close()
                thread {
                    SettingsBackup.save(Keys.FREEFORM)
                    Shell.run("settings put global enable_freeform_support 1; settings put global force_resizable_activities 1")
                    ui.post { startFloating(p) }
                }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(8) })
            addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) })
        }
        val root = FrameLayout(this).apply {
            setBackgroundColor(0x88000000.toInt())
            setOnClickListener { close() }
            addView(card, FrameLayout.LayoutParams(dp(280), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        }
        v = root
        wm.addView(
            root,
            WindowManager.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
        )
    }

    /** Small floating chooser above the FPS tool: 30 / 60 / 90 / 120. */
    private fun showFpsPopup(anchor: View, onPick: (Int) -> Unit) {
        fpsPop?.dismiss()
        lateinit var pw: PopupWindow
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = gbox(BG, 0xCC00E5FF.toInt(), 10)
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }
        val rates = Boost.supportedRates(this).ifEmpty { listOf(60, 90, 120) }
        (listOf(0) + rates).forEachIndexed { i, n ->
            val sel = n == fps
            content.addView(label(if (n == 0) "AUTO" else n.toString(), 12f, if (sel) LIME else TXT, true).apply {
                gravity = Gravity.CENTER
                background = gbox(if (sel) 0x2639FF88 else 0x2600E5FF, if (sel) 0xCC39FF88.toInt() else LINE, 6)
                setPadding(dp(12), dp(8), dp(12), dp(8))
                setOnClickListener { pw.dismiss(); onPick(n) }
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { if (i > 0) leftMargin = dp(6) })
        }
        content.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        pw = PopupWindow(content, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, false).apply {
            isOutsideTouchable = true
            setBackgroundDrawable(ColorDrawable(0))
            elevation = dp(8).toFloat()
        }
        fpsPop = pw
        pw.showAsDropDown(anchor, (anchor.width - content.measuredWidth) / 2, -(anchor.height + content.measuredHeight + dp(4)))
    }

    private fun toast(t: String) = Toast.makeText(this, t.take(200), Toast.LENGTH_LONG).show()

    private fun act(name: String, f: () -> String) {
        toast("$name...")
        thread {
            val r = try { f() } catch (e: Throwable) { "Error: ${e.message}" }
            ui.post { toast("$name: $r") }
        }
    }

    private fun currentGame(): String {
        val r = Shell.run("dumpsys activity activities | grep -m1 -E 'topResumedActivity|mResumedActivity'")
        val p = Regex("([a-zA-Z][a-zA-Z0-9_]*(?:\\.[a-zA-Z0-9_]+)+)/").find(r)?.groupValues?.get(1)
        if (p != null && p != packageName && !p.startsWith("com.android.systemui")) return p
        return getSharedPreferences("games", MODE_PRIVATE).getString("sel", "") ?: ""
    }
}


/** Small line/area chart of the last ~60 FPS samples (0 to 120 FPS, grows if the game goes above 120). */
class FpsChart(c: android.content.Context, private val data: List<Int>, private val col: Int, private val dim: Int) : View(c) {
    private val line = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        style = android.graphics.Paint.Style.STROKE; strokeWidth = 2f * resources.displayMetrics.density; color = col
        strokeJoin = android.graphics.Paint.Join.ROUND
    }
    private val fill = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    private val grid = android.graphics.Paint().apply { color = 0x22FFFFFF; strokeWidth = 1f }
    private val txt = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = dim; textSize = 8f * resources.displayMetrics.scaledDensity
    }

    override fun onDraw(cv: android.graphics.Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val left = txt.measureText("120") + 6f
        val d = synchronized(data) { data.toList() }
        val top = if ((d.maxOrNull() ?: 0) > 120) 240 else 120
        fun y(v: Int) = h - (v.coerceIn(0, top) / top.toFloat()) * (h - 2f) - 1f
        for (v in listOf(0, top / 2, top)) {
            cv.drawLine(left, y(v), w, y(v), grid)
            cv.drawText(v.toString(), 0f, y(v) + txt.textSize / 3f, txt)
        }
        if (d.size < 2) return
        val step = (w - left) / 59f
        val path = android.graphics.Path()
        val area = android.graphics.Path()
        val x0 = w - (d.size - 1) * step
        d.forEachIndexed { i, v ->
            val x = x0 + i * step
            if (i == 0) { path.moveTo(x, y(v)); area.moveTo(x, h); area.lineTo(x, y(v)) } else { path.lineTo(x, y(v)); area.lineTo(x, y(v)) }
        }
        area.lineTo(w, h); area.close()
        fill.shader = android.graphics.LinearGradient(0f, 0f, 0f, h, (col and 0x00FFFFFF) or 0x99000000.toInt(), 0x00000000, android.graphics.Shader.TileMode.CLAMP)
        cv.drawPath(area, fill)
        cv.drawPath(path, line)
    }
}


/** Neon panel with two cut corners (top-left, bottom-right) and a soft glow outline. */
class Chamfer(
    private val c1: Int, private val c2: Int, private val strokeCol: Int,
    private val cut: Float, private val d: Float
) : android.graphics.drawable.Drawable() {
    private val fillP = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    private val lineP = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { style = android.graphics.Paint.Style.STROKE }
    private val path = android.graphics.Path()

    override fun onBoundsChange(b: android.graphics.Rect) {
        val i = d * 0.75f
        val l = b.left + i; val t = b.top + i; val r = b.right - i; val bt = b.bottom - i
        val k = minOf(cut, (r - l) / 2.2f, (bt - t) / 2.2f)
        path.reset()
        path.moveTo(l + k, t); path.lineTo(r, t); path.lineTo(r, bt - k)
        path.lineTo(r - k, bt); path.lineTo(l, bt); path.lineTo(l, t + k); path.close()
        fillP.shader = if (c1 != c2) android.graphics.LinearGradient(
            b.left.toFloat(), b.top.toFloat(), b.right.toFloat(), b.bottom.toFloat(), c1, c2, android.graphics.Shader.TileMode.CLAMP
        ) else null
    }

    override fun draw(cv: android.graphics.Canvas) {
        fillP.color = c1
        cv.drawPath(path, fillP)
        if (strokeCol != 0) {
            lineP.color = (strokeCol and 0x00FFFFFF) or 0x22000000; lineP.strokeWidth = d * 3.5f   // glow
            cv.drawPath(path, lineP)
            lineP.color = strokeCol; lineP.strokeWidth = d * 1.2f
            cv.drawPath(path, lineP)
        }
    }

    override fun setAlpha(a: Int) { fillP.alpha = a; lineP.alpha = a }
    override fun setColorFilter(f: android.graphics.ColorFilter?) { fillP.colorFilter = f; lineP.colorFilter = f }
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity() = android.graphics.PixelFormat.TRANSLUCENT
}
