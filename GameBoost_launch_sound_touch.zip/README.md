# Aero Boost
AeroHUB ভিত্তিক Android gaming tool (root ছাড়া)।

## AeroHUB access
1. AeroHUB app install করে server চালু করুন
2. Aero Boost খুলে CONNECT চাপুন, Allow দিন
3. AeroHUB > Apps এ এই app এর switch চালু রাখুন

## ফিচার
Game Mode, speed compile, RAM clean, refresh rate, animation scale, stats।

## In-game panel
Aero Boost এ "IN-GAME PANEL" চালু করুন (Display over other apps permission দিন)।
গেমের ভিতর বাম বা ডান যেকোনো কিনারা থেকে ভিতরের দিকে টান দিন (নেভিগেশন জেসচারের জন্য কিনারার একটু ভিতর থেকে শুরু করুন)।

## মূল স্ক্রিন
MIUI Game Turbo-র মতো: বামে গেমের তালিকা, মাঝে প্রিভিউ, ডানে "Start playing" (boost করে গেম চালু করে), নিচে মোড (Default/Performance/Battery saver, চাপলে বদলায়)।
উপরে ডানে: + গেম যোগ, রেকর্ড, সেটিংস, বের হওয়া। বাকি সব সেটিংসে (AeroHUB link, 120Hz, animation, in-game panel, tools)।

## Floating window
In-game panel এর বামের গেম/অ্যাপ আইকনে চাপ দিলে app floating (freeform) window তে খোলে; লং-প্রেস করলে পুরো স্ক্রিনে। Developer options এ "Enable freeform windows" ও "Force activities to be resizable" বন্ধ থাকলে app চালু করার সময় সেটা চালু করতে বলবে (Open settings বা Try anyway)। ROM সাপোর্ট না করলে স্বাভাবিকভাবে খোলে।

## Tools সাজানো (নতুন)
In-game panel এর নিচের tools strip (Screenshot, Record, DND, Settings, FPS, Mode) এ যেকোনো tool লং-প্রেস (tap & hold) করে ডানে/বামে swipe করলে জায়গা বদলানো যায়। টানার সময় tool টি উঁচু হয়ে ভাইব্রেট করে, বাকিগুলো সরে জায়গা করে দেয়; কিনারার কাছে নিলে strip নিজে স্ক্রল করে। ছাড়লে নতুন ক্রম সেভ হয় (SharedPreferences "panel" > toolOrder)।

## Gaming UI
নিয়ন সায়ান + ভায়োলেট থিম, কোণা-কাটা (chamfer) ফ্রেম ও glow বর্ডার, বোল্ড ইটালিক হেডার, গ্র্যাডিয়েন্ট BOOST/START PLAYING বাটন। প্যানেল ও মূল অ্যাপ দুটোতেই প্রযোজ্য।

## Game launching animation (নতুন)
"START PLAYING" চাপলে ফুলস্ক্রিন লঞ্চ অ্যানিমেশন চলে: গেমের আইকনের চারপাশে ঘূর্ণায়মান নিয়ন রিং ও শকওয়েভ, "LAUNCHING" লেখা, প্রগ্রেস বার ও ধাপের নাম (Game mode, Clean RAM, Fast animation, Refresh rate)। সব ধাপ শেষ হলে গেম চালু হয় এবং অ্যানিমেশন ফেড-আউট হয়। চলার সময় Back চাপলে কিছু হয় না। কোড: `LaunchOverlay` (MainActivity.kt)।

## Launch sound ও Touch response (নতুন)
- **Launch sound:** গেম লঞ্চ হওয়ার সময় মেকানিক্যাল সাউন্ড বাজে: boost চলার সময় গিয়ার-র‍্যাচেট ও সার্ভো ঘোরার লুপ, শেষে "Launching game" এর মুহূর্তে ভারী লক/ক্লাংক। সাউন্ড ফাইল `res/raw/mech_spin.wav` ও `mech_lock.wav`। Settings > General এ "Launch sound" সুইচে চালু/বন্ধ করা যায়।
- **Touch response:** Settings > Performance এ 0–100% স্লাইডার (50% = ফোনের নিজের মান)। বাড়ালে touch-and-hold ও double-tap দ্রুত সাড়া দেয় (hold 1000ms → 150ms, double-tap 600ms → 200ms), 70% থেকে সাপোর্টেড ফোনে OEM high-sensitivity চালু হয়। স্লাইডার ছাড়লে প্রয়োগ হয়; গেম বন্ধ হলে বা Restore চাপলে আবার 50% এ ফিরে যায়।
