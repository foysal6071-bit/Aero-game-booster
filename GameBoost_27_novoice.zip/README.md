# Aero Boost
AeroHUB ভিত্তিক Android gaming tool (root ছাড়া)।

## AeroHUB access
1. AeroHUB app install করে server চালু করুন
2. Aero Boost খুলে CONNECT চাপুন, Allow দিন
3. AeroHUB > Apps এ এই app এর switch চালু রাখুন

## ফিচার
Game Mode, speed compile, RAM clean, refresh rate, animation scale, stats।

## In-game panel
Aero Boost এ "IN-GAME PANEL" চালু করুন (Display over other apps permission দিন)।
গেমের ভিতর বাম বা ডান যেকোনো কিনারা থেকে ভিতরের দিকে টান দিন (নেভিগেশন জেসচারের জন্য কিনারার একটু ভিতর থেকে শুরু করুন)।

## মূল স্ক্রিন
MIUI Game Turbo-র মতো: বামে গেমের তালিকা, মাঝে প্রিভিউ, ডানে "Start playing" (boost করে গেম চালু করে), নিচে মোড (Default/Performance/Battery saver, চাপলে বদলায়)।
উপরে ডানে: + গেম যোগ, রেকর্ড, সেটিংস, বের হওয়া। বাকি সব সেটিংসে (AeroHUB link, 120Hz, animation, in-game panel, tools)।

## Floating window
In-game panel এর বামের গেম/অ্যাপ আইকনে চাপ দিলে app floating (freeform) window তে খোলে; লং-প্রেস করলে পুরো স্ক্রিনে। Developer options এ "Enable freeform windows" ও "Force activities to be resizable" বন্ধ থাকলে app চালু করার সময় সেটা চালু করতে বলবে (Open settings বা Try anyway)। ROM সাপোর্ট না করলে স্বাভাবিকভাবে খোলে।
