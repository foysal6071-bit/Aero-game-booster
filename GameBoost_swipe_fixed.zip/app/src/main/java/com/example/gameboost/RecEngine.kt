package com.example.gameboost

import android.content.Context
import android.graphics.Point
import android.view.WindowManager

/**
 * Lightweight screen-record engine.
 * Uses the system screenrecord tool with a reduced resolution, a capped frame rate and a low
 * bitrate, and runs at low CPU priority so the game keeps its FPS while recording.
 * Values come from Settings > Recording (prefs "games": recFps, recMbps, recRes).
 */
object RecEngine {
    val FPS = listOf(15, 24, 30, 60)
    val MBPS = listOf(2, 4, 8, 12)
    val RES = listOf(50, 75, 100)          // % of the screen size

    const val D_FPS = 30
    const val D_MBPS = 4
    const val D_RES = 75

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("games", Context.MODE_PRIVATE)

    fun fps(ctx: Context) = prefs(ctx).getInt("recFps", D_FPS)
    fun mbps(ctx: Context) = prefs(ctx).getInt("recMbps", D_MBPS)
    fun res(ctx: Context) = prefs(ctx).getInt("recRes", D_RES)

    @Suppress("DEPRECATION")
    private fun size(ctx: Context, pct: Int): String? {
        if (pct >= 100) return null
        val p = Point()
        (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealSize(p)
        if (p.x <= 0 || p.y <= 0) return null
        val w = (p.x * pct / 100) / 2 * 2      // encoders need even sizes
        val h = (p.y * pct / 100) / 2 * 2
        return "${w}x$h"
    }

    /** Starts recording in the background (max 3 min). Call from a worker thread. */
    fun start(ctx: Context): String {
        val out = "/sdcard/Movies/AeroBoost/rec_${System.currentTimeMillis()}.mp4"
        val common = StringBuilder("--bit-rate ${mbps(ctx) * 1_000_000} --time-limit 180")
        size(ctx, res(ctx))?.let { common.append(" --size $it") }
        // 1st try: low priority + frame-rate cap (needs a newer screenrecord);
        // 2nd try: same without the cap, for phones whose screenrecord has no --max-fps
        val a = "nice -n 10 screenrecord --max-fps ${fps(ctx)} $common $out"
        val b = "screenrecord $common $out"
        return Shell.run("mkdir -p /sdcard/Movies/AeroBoost; nohup sh -c '$a || $b' >/dev/null 2>&1 &")
    }

    fun stop(): String = Shell.run("pkill -2 screenrecord")
}
