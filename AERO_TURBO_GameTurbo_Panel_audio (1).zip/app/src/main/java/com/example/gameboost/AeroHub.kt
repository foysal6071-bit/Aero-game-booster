package com.example.gameboost

import java.io.BufferedReader
import java.io.Closeable
import java.io.IOException
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket
import java.util.Base64

object AeroHub {
    const val PKG = "com.example.mykuzu"
    const val ACTION_REQUEST = "com.example.mykuzu.action.REQUEST_PERMISSION"
    private const val PORT = 27183
    const val MIN_SERVER_VERSION = 4

    private fun request(token: String, line: String, timeoutMs: Int = 90_000): String {
        val s = Socket()
        try {
            s.connect(InetSocketAddress("127.0.0.1", PORT), 2000)
            s.soTimeout = timeoutMs
            s.getOutputStream().apply { write("$token $line\n".toByteArray()); flush() }
            return BufferedReader(InputStreamReader(s.getInputStream())).readLine()
                ?: throw IOException("No reply from AeroHUB")
        } finally { try { s.close() } catch (_: Exception) {} }
    }

    /** code: -1 server not running, 0 running but this app is not allowed, 1 allowed. */
    class Status(val code: Int, val version: Int)

    fun status(token: String): Status = try {
        val r = request(token, "PING", 3000)
        when {
            r == "DENIED" -> Status(0, 0)
            r.startsWith("OK ") -> Status(1, r.split(" ").getOrNull(2)?.toIntOrNull() ?: 1)
            else -> Status(-1, 0)
        }
    } catch (_: Exception) { Status(-1, 0) }

    private fun split(r: String): Pair<Int, ByteArray> {
        if (r == "DENIED") throw SecurityException("AeroHUB denied this app")
        val p = r.split(" ", limit = 2)
        return p[0].toInt() to Base64.getDecoder().decode(p.getOrElse(1) { "" })
    }

    /** Runs a shell command. Returns exit code and text output. Blocking: call from a background thread. */
    fun exec(token: String, cmd: String): Pair<Int, String> {
        val (c, b) = split(request(token, "EXEC " + Base64.getEncoder().encodeToString(cmd.toByteArray())))
        return c to String(b)
    }

    /** Same, but raw bytes (for binary output such as screencap; max 512 KB). */
    fun execBytes(token: String, cmd: String): Pair<Int, ByteArray> =
        split(request(token, "EXEC " + Base64.getEncoder().encodeToString(cmd.toByteArray())))

    fun statusFlags(token: String, what: Int, what2: Int): Boolean =
        request(token, "SBFLAGS $what $what2").startsWith("OK")

    fun beat(token: String) { request(token, "BEAT", 5000) }

    /** Calls [onLine] for each output line until it returns false or the command ends. Blocks. */
    fun stream(token: String, cmd: String, onOpen: (Closeable) -> Unit, onLine: (String) -> Boolean) {
        val s = Socket()
        try {
            s.connect(InetSocketAddress("127.0.0.1", PORT), 2000)
            s.soTimeout = 0
            s.getOutputStream().apply {
                write("$token STREAM ${Base64.getEncoder().encodeToString(cmd.toByteArray())}\n".toByteArray()); flush()
            }
            val r = BufferedReader(InputStreamReader(s.getInputStream()))
            if (r.readLine() != "OK") throw IOException("AeroHUB refused the stream")
            onOpen(s)
            while (true) { val line = r.readLine() ?: break; if (!onLine(line)) break }
        } finally { try { s.close() } catch (_: Exception) {} }
    }
}
