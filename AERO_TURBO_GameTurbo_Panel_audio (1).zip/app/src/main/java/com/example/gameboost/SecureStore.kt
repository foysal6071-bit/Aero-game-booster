package com.example.gameboost

import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Stores secrets encrypted with a key that lives in the Android Keystore and never leaves it. */
object SecureStore {
    private const val ALIAS = "app_secrets"
    private const val SUFFIX = "_enc"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build()
        )
        return gen.generateKey()
    }

    private fun encrypt(plain: String): String {
        val c = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, key()) }
        return Base64.encodeToString(c.iv + c.doFinal(plain.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
    }

    private fun decrypt(blob: String): String {
        val raw = Base64.decode(blob, Base64.NO_WRAP)
        val c = Cipher.getInstance("AES/GCM/NoPadding").apply {
            init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, raw, 0, 12))
        }
        return String(c.doFinal(raw, 12, raw.size - 12), Charsets.UTF_8)
    }

    fun get(prefs: SharedPreferences, name: String): String {
        val enc = prefs.getString(name + SUFFIX, null) ?: return ""
        return runCatching { decrypt(enc) }.getOrDefault("")
    }

    fun put(prefs: SharedPreferences, name: String, value: String) {
        val stored = runCatching { encrypt(value) }.getOrNull() ?: return
        prefs.edit().putString(name + SUFFIX, stored).apply()
    }

    fun remove(prefs: SharedPreferences, name: String) {
        prefs.edit().remove(name + SUFFIX).apply()
    }
}
