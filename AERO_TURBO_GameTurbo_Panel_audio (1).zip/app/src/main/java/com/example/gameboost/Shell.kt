package com.example.gameboost

import android.content.Context
import android.hardware.display.DisplayManager
import android.view.Display

object Shell {
    fun ready() = AeroAccess.state == AeroAccess.State.Ready

    fun run(cmd: String): String = try {
        val (code, out) = AeroAccess.run(cmd)
        val t = out.trim()
        if (code != 0) "exit $code: $t" else t.ifEmpty { "OK" }
    } catch (e: Throwable) { "Error: ${e.message}" }
}

object Boost {
    fun gameMode(pkg: String, mode: Int = 2) = Shell.run("cmd game set --mode $mode --user 0 ${AeroAccess.sq(pkg)}")
    fun compileSpeed(pkg: String) = Shell.run("cmd package compile -m speed -f ${AeroAccess.sq(pkg)}")
    fun killBackground() = Shell.run("am kill-all")
    /** Refresh rates the display really supports (rounded, ascending). Empty if it cannot be read. */
    fun supportedRates(ctx: Context): List<Int> = runCatching {
        val d = (ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).getDisplay(Display.DEFAULT_DISPLAY)
        d.supportedModes.map { Math.round(it.refreshRate) }.filter { it >= 30 }.distinct().sorted()
    }.getOrDefault(emptyList())

    /** hz <= 0 = back to the phone's original (auto) setting. */
    fun refreshRate(hz: Int): String {
        if (hz <= 0) return SettingsBackup.restore(Keys.REFRESH)
        SettingsBackup.save(Keys.REFRESH)
        return Shell.run("settings put system min_refresh_rate $hz; settings put system peak_refresh_rate $hz")
    }
    /** scale == null = back to the phone's original animation scales. */
    fun animations(scale: String?): String {
        if (scale == null) return SettingsBackup.restore(Keys.ANIM)
        SettingsBackup.save(Keys.ANIM)
        return Shell.run(
            "settings put global window_animation_scale $scale; " +
            "settings put global transition_animation_scale $scale; " +
            "settings put global animator_duration_scale $scale"
        )
    }
    /**
     * pct 0..100, 50 = the phone's own values. Higher = faster touch response:
     * touch-and-hold delay 1000ms (0%) .. 150ms (100%), double-tap window 600..200ms,
     * and the OEM high-sensitivity flag from 70% up (only where the maker supports it).
     */
    fun touch(pct: Int): String {
        val p = pct.coerceIn(0, 100)
        if (p in 45..55) {   // "Normal" = the phone's own value
            val r = SettingsBackup.restore(Keys.TOUCH)
            return if (r.startsWith("nothing")) "OK (normal)" else r
        }
        SettingsBackup.save(Keys.TOUCH)
        val hold = (1000 - (850 * p / 100f)).toInt()
        val multi = (600 - (400 * p / 100f)).toInt()
        val hi = if (p >= 70) 1 else 0
        return Shell.run(
            "settings put secure long_press_timeout $hold; " +
            "settings put secure multi_press_timeout $multi; " +
            "settings put system high_touch_sensitivity_enable $hi"
        )
    }
    fun stats() = Shell.run("cat /proc/meminfo | head -3; dumpsys battery | grep temperature")
}

/** Reads the game's real frame rate from SurfaceFlinger (needs AeroHUB). Returns -1 when it cannot be read. */
object FpsMon {
    private var layer = ""
    private var layerPkg = ""

    private fun findLayer(pkg: String): String {
        val lines = Shell.run("dumpsys SurfaceFlinger --list").lines().map { it.trim() }.filter { it.contains(pkg) }
        val sv = lines.filter { it.startsWith("SurfaceView") && !it.contains("Background") }
        return sv.firstOrNull { it.contains("BLAST") } ?: sv.firstOrNull()
            ?: lines.firstOrNull { !it.contains("Background") && it.contains("BLAST") }
            ?: lines.firstOrNull { !it.contains("Background") } ?: ""
    }

    fun reset() { layer = ""; layerPkg = "" }

    fun sample(pkg: String): Int {
        if (pkg.isBlank()) return -1
        if (layer.isEmpty() || layerPkg != pkg) { layer = findLayer(pkg); layerPkg = pkg }
        if (layer.isEmpty()) return -1
        val out = Shell.run("dumpsys SurfaceFlinger --latency " + AeroAccess.sq(layer))
        val ts = out.lines().drop(1).mapNotNull {
            val p = it.trim().split(Regex("\\s+"))
            if (p.size >= 3) p[1].toLongOrNull() else null
        }.filter { it > 0 && it != Long.MAX_VALUE }
        if (ts.size < 2) { layer = ""; return -1 }
        val last = ts.max()
        return ts.count { it > last - 1_000_000_000L }.coerceIn(1, 240)
    }
}

/** After the one AeroHUB approval, every other permission is granted through AeroHUB's shell access. */
object AutoPerms {
    fun grant(ctx: Context) {
        if (!Shell.ready()) return
        val p = AeroAccess.sq(ctx.packageName)
        Shell.run("appops set $p SYSTEM_ALERT_WINDOW allow")
        Shell.run("pm grant $p android.permission.POST_NOTIFICATIONS")
        Shell.run("pm grant $p android.permission.RECORD_AUDIO")
    }
}
