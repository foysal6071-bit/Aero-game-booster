package com.example.gameboost

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool

/**
 * Mechanical launch sound: a looping gear-ratchet / servo whirr while the boost runs,
 * then a heavy latch "clunk" when the game is about to start.
 * Sounds are bundled in res/raw (mech_spin, mech_lock), no network needed.
 */
class LaunchSound(ctx: Context) {
    private val pool = SoundPool.Builder()
        .setMaxStreams(3)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        ).build()
    private val spinId = pool.load(ctx, R.raw.mech_spin, 1)
    private val lockId = pool.load(ctx, R.raw.mech_lock, 1)
    private val tickId = pool.load(ctx, R.raw.switch_tick, 1)
    private val ready = HashSet<Int>()
    private var spinStream = 0

    init { pool.setOnLoadCompleteListener { _, id, status -> if (status == 0) synchronized(ready) { ready.add(id) } } }

    private fun isReady(id: Int) = synchronized(ready) { id in ready }

    fun startSpin() {
        stopSpin()
        if (isReady(spinId)) spinStream = pool.play(spinId, 0.7f, 0.7f, 1, -1, 1f)
    }

    fun stopSpin() {
        if (spinStream != 0) { pool.stop(spinStream); spinStream = 0 }
    }

    /** Ends the spin and plays the final lock sound. */
    fun lock() {
        stopSpin()
        if (isReady(lockId)) pool.play(lockId, 1f, 1f, 2, 0, 1f)
    }

    /** Short click when the selected game changes. */
    fun tick() { if (isReady(tickId)) pool.play(tickId, 0.8f, 0.8f, 1, 0, 1f) }

    fun release() { stopSpin(); pool.release() }
}
