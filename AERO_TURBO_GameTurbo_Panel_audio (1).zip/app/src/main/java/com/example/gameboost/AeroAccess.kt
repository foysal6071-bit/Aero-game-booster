package com.example.gameboost

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.os.Handler
import android.os.Looper
import kotlin.concurrent.thread

object AeroAccess {
    enum class State { NotInstalled, NotRunning, NoPermission, Blocked, Outdated, Ready }

    private const val REQ = 4127
    @Volatile var state: State = State.NoPermission; private set
    /** Called on the main thread whenever [state] changes. Use it to refresh the UI (or copy into a Compose mutableStateOf). */
    var onChange: (() -> Unit)? = null

    private var token = ""
    private var app: Context? = null
    @Volatile private var pollGen = 0
    private val main = Handler(Looper.getMainLooper())

    private fun prefs(c: Context) = c.getSharedPreferences("aerohub", Context.MODE_PRIVATE)

    /** Call once in Activity.onCreate. */
    fun init(context: Context) {
        app = context.applicationContext
        token = SecureStore.get(prefs(context), "token")
    }

    fun context(): Context? = app

    fun installed(context: Context): Boolean =
        runCatching { context.packageManager.getPackageInfo(AeroHub.PKG, 0) }.isSuccess

    fun message(s: State = state): String = when (s) {
        State.NotInstalled -> "AeroHUB is not installed"
        State.NotRunning -> "Start the AeroHUB server (or tap Restart server if it is outdated)"
        State.NoPermission -> "Tap Allow to give this app AeroHUB access"
        State.Blocked -> "Blocked: switch this app on in AeroHUB > Apps"
        State.Outdated -> "AeroHUB is outdated: tap Restart server in AeroHUB"
        State.Ready -> "AeroHUB connected"
    }

    private fun set(s: State) {
        if (state != s) { state = s; main.post { onChange?.invoke() } }
    }

    private fun checkBlocking() {
        val c = app ?: return
        if (!installed(c)) { set(State.NotInstalled); return }
        if (token.isEmpty()) { set(State.NoPermission); return }
        val st = AeroHub.status(token)
        when {
            st.code == -1 -> set(State.NotRunning)
            st.code == 0 -> set(State.Blocked)
            st.version < AeroHub.MIN_SERVER_VERSION -> set(State.Outdated)
            else -> set(State.Ready)
        }
    }

    fun recheck() { thread(isDaemon = true) { runCatching { checkBlocking() } } }

    /** AeroHUB has no "died" callback, so re-check every ~4 s while the app is on screen (call from onResume/onPause). */
    fun startPolling(context: Context) {
        app = context.applicationContext
        val g = ++pollGen
        recheck()
        thread(isDaemon = true) {
            while (pollGen == g) {
                try { Thread.sleep(4000) } catch (_: InterruptedException) {}
                if (pollGen == g) runCatching { checkBlocking() }
            }
        }
    }
    fun stopPolling() { pollGen++ }

    /** Shows AeroHUB's Allow/Deny popup. Must be started from an Activity with startActivityForResult. */
    fun requestPermission(context: Context) {
        val act = generateSequence(context) { (it as? ContextWrapper)?.baseContext }.firstOrNull { it is Activity } as? Activity ?: return
        try {
            act.startActivityForResult(Intent(AeroHub.ACTION_REQUEST).setPackage(AeroHub.PKG), REQ)
        } catch (e: Exception) { set(State.NotInstalled) }
    }

    /** Call from Activity.onActivityResult. */
    fun onResult(context: Context, requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode != REQ) return
        if (resultCode == Activity.RESULT_OK) {
            val t = data?.getStringExtra("token")
            if (!t.isNullOrEmpty()) { token = t; SecureStore.put(prefs(context), "token", t) }
        }
        recheck()
    }

    fun openAeroHub(context: Context) {
        runCatching { context.packageManager.getLaunchIntentForPackage(AeroHub.PKG)?.let { context.startActivity(it) } }
    }

    fun forget(context: Context) { token = ""; SecureStore.remove(prefs(context), "token"); set(State.NoPermission) }

    /** Safe shell quoting: 'text' with every ' replaced by '\'' . Always quote file names / package names with it. */
    fun sq(s: String) = "'" + s.replace("'", "'\\''") + "'"

    /** Runs a shell command as the shell user. Blocking: call from Dispatchers.IO / a background thread. */
    fun run(cmd: String): Pair<Int, String> {
        if (state != State.Ready) throw IllegalStateException("AeroHUB is not connected.")
        try {
            return AeroHub.exec(token, cmd)
        } catch (e: Exception) {
            recheck()
            throw IllegalStateException(
                if (e is SecurityException) "AeroHUB blocked this app. Switch it on in AeroHUB > Apps."
                else "AeroHUB: ${e.message ?: "connection failed"}"
            )
        }
    }
}
