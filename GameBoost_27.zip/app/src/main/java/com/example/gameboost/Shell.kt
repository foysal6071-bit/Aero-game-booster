package com.example.gameboost

object Shell {
    fun ready() = AeroAccess.state == AeroAccess.State.Ready

    fun run(cmd: String): String = try {
        val (code, out) = AeroAccess.run(cmd)
        val t = out.trim()
        if (code != 0) "exit $code: $t" else t.ifEmpty { "OK" }
    } catch (e: Throwable) { "Error: ${e.message}" }
}

object Boost {
    fun gameMode(pkg: String, mode: Int = 2) = Shell.run("cmd game set --mode $mode --user 0 ${AeroAccess.sq(pkg)}")
    fun compileSpeed(pkg: String) = Shell.run("cmd package compile -m speed -f ${AeroAccess.sq(pkg)}")
    fun killBackground() = Shell.run("am kill-all")
    fun refreshRate(hz: Int) =
        Shell.run("settings put system min_refresh_rate $hz; settings put system peak_refresh_rate $hz")
    fun animations(scale: String) = Shell.run(
        "settings put global window_animation_scale $scale; " +
        "settings put global transition_animation_scale $scale; " +
        "settings put global animator_duration_scale $scale"
    )
    /** level 1..5. Touch-and-hold delay works on every phone; the OEM high-sensitivity flag only where the maker supports it. */
    fun touch(level: Int): String {
        val delay = when (level) { 1 -> 1000; 2 -> 500; 3 -> 400; 4 -> 300; else -> 200 }
        val hi = if (level >= 4) 1 else 0
        return Shell.run("settings put secure long_press_timeout $delay; settings put system high_touch_sensitivity_enable $hi")
    }
    fun stats() = Shell.run("cat /proc/meminfo | head -3; dumpsys battery | grep temperature")
}

/** Reads the game's real frame rate from SurfaceFlinger (needs AeroHUB). Returns -1 when it cannot be read. */
object FpsMon {
    private var layer = ""
    private var layerPkg = ""

    private fun findLayer(pkg: String): String {
        val lines = Shell.run("dumpsys SurfaceFlinger --list").lines().map { it.trim() }.filter { it.contains(pkg) }
        val sv = lines.filter { it.startsWith("SurfaceView") && !it.contains("Background") }
        return sv.firstOrNull { it.contains("BLAST") } ?: sv.firstOrNull()
            ?: lines.firstOrNull { !it.contains("Background") && it.contains("BLAST") }
            ?: lines.firstOrNull { !it.contains("Background") } ?: ""
    }

    fun reset() { layer = ""; layerPkg = "" }

    fun sample(pkg: String): Int {
        if (pkg.isBlank()) return -1
        if (layer.isEmpty() || layerPkg != pkg) { layer = findLayer(pkg); layerPkg = pkg }
        if (layer.isEmpty()) return -1
        val out = Shell.run("dumpsys SurfaceFlinger --latency " + AeroAccess.sq(layer))
        val ts = out.lines().drop(1).mapNotNull {
            val p = it.trim().split(Regex("\\s+"))
            if (p.size >= 3) p[1].toLongOrNull() else null
        }.filter { it > 0 && it != Long.MAX_VALUE }
        if (ts.size < 2) { layer = ""; return -1 }
        val last = ts.max()
        return ts.count { it > last - 1_000_000_000L }.coerceIn(1, 240)
    }
}
