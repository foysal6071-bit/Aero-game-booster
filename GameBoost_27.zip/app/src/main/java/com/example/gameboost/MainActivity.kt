package com.example.gameboost

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.widget.Toast
import android.net.Uri
import android.provider.Settings
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Bg = Color(0xFF090D14)
private val Panel = Color(0xFF121926)
private val Cyan = Color(0xFF4C9AFF)
private val Magenta = Color(0xFF7C6CFF)
private val Lime = Color(0xFF2EE6A6)
private val Amber = Color(0xFFFFB84D)
private val Dim = Color(0xFF8693AB)
private val Line = Color(0xFF222C3F)

class MainActivity : ComponentActivity() {
    private var aero by mutableStateOf(AeroAccess.state)
    private var overlayOk by mutableStateOf(false)
    private var micOk by mutableStateOf(false)

    private fun refreshPerms() {
        overlayOk = Settings.canDrawOverlays(this)
        micOk = checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AeroAccess.init(this)
        aero = AeroAccess.state
        refreshPerms()
        AeroAccess.onChange = { aero = AeroAccess.state }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Panel)) {
                if (aero == AeroAccess.State.Ready && overlayOk && micOk) Screen(aero)
                else SetupScreen(aero, overlayOk, micOk,
                    onAero = {
                        when (aero) {
                            AeroAccess.State.NoPermission -> AeroAccess.requestPermission(this@MainActivity)
                            else -> AeroAccess.openAeroHub(this@MainActivity)
                        }
                    },
                    onOverlay = {
                        startActivity(
                            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    },
                    onMic = { requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), 7) }
                )
            }
        }
    }

    override fun onResume() { super.onResume(); refreshPerms(); AeroAccess.startPolling(this) }
    override fun onPause() { AeroAccess.stopPolling(); super.onPause() }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshPerms()
    }

    @Deprecated("needed for AeroHUB's startActivityForResult")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        AeroAccess.onResult(this, requestCode, resultCode, data)
    }
}

@Composable
fun SetupScreen(
    aero: AeroAccess.State, overlayOk: Boolean, micOk: Boolean,
    onAero: () -> Unit, onOverlay: () -> Unit, onMic: () -> Unit
) {
    val aeroOk = aero == AeroAccess.State.Ready
    val aeroBtn = when (aero) {
        AeroAccess.State.NoPermission -> "ALLOW"
        else -> "OPEN"
    }
    Box(Modifier.fillMaxSize().background(Bg).systemBarsPadding().displayCutoutPadding(), contentAlignment = Alignment.Center) {
        Column(
            Modifier.fillMaxWidth(0.8f).verticalScroll(rememberScrollState()).padding(vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("SETUP", color = Cyan, fontWeight = FontWeight.Black, fontSize = 18.sp, letterSpacing = 4.sp)
            Text("Allow these 3 permissions to continue", color = Dim, fontSize = 12.sp)
            SetupRow("AeroHUB", AeroAccess.message(aero), aeroOk, aeroBtn, onAero)
            SetupRow("Display over other apps", "Needed for the in-game panel", overlayOk, "ALLOW", onOverlay)
            SetupRow("Microphone", "Needed for voice effects", micOk, "ALLOW", onMic)
        }
    }
}

@Composable
private fun SetupRow(title: String, sub: String, done: Boolean, action: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(Panel)
            .border(1.dp, if (done) Lime.copy(alpha = 0.6f) else Line, shape).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(sub, color = Dim, fontSize = 11.sp)
        }
        Spacer(Modifier.size(10.dp))
        if (done) Text("✓ DONE", color = Lime, fontWeight = FontWeight.Black, fontSize = 12.sp)
        else Box(
            Modifier.clip(RoundedCornerShape(10.dp))
                .background(Brush.horizontalGradient(listOf(Color(0xFF3B82F6), Color(0xFF22C7EE))))
                .clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 10.dp),
            contentAlignment = Alignment.Center
        ) { Text(action, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
    }
}

@Composable
fun Screen(aero: AeroAccess.State) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("games", Context.MODE_PRIVATE) }
    var apps by remember { mutableStateOf(listOf<AppInfo>()) }
    var gamePkgs by remember { mutableStateOf((prefs.getString("list", "") ?: "").split(",").filter { it.isNotBlank() }) }
    var pkg by remember { mutableStateOf(prefs.getString("sel", "") ?: "") }
    var showPicker by remember { mutableStateOf(false) }
    var mode by remember { mutableStateOf(prefs.getInt("mode", 2)) }
    var touch by remember { mutableStateOf(prefs.getInt("touch", 3)) }
    var settled by remember { mutableStateOf(false) }
    var connectLater by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf(0) }           // settings category
    var page by remember { mutableStateOf(0) }          // 0 = game launcher, 1 = settings
    var rec by remember { mutableStateOf(false) }
    var battery by remember { mutableStateOf(-1) }
    var cpu by remember { mutableStateOf(-1) }
    var hz by remember { mutableStateOf(false) }
    var fast by remember { mutableStateOf(false) }
    var overlay by remember { mutableStateOf(OverlayService.running) }
    var busy by remember { mutableStateOf(false) }
    var boosted by remember { mutableStateOf(false) }
    var log by remember { mutableStateOf("> system ready") }
    val ok = aero == AeroAccess.State.Ready

    LaunchedEffect(Unit) { delay(1200); settled = true }   // give the first AeroHUB check time to finish
    BackHandler(enabled = page == 1) { page = 0 }
    LaunchedEffect(ok, page) {
        while (true) {
            val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val l = i?.getIntExtra("level", -1) ?: -1
            val sc = i?.getIntExtra("scale", 100) ?: 100
            battery = if (l < 0 || sc <= 0) -1 else l * 100 / sc
            if (ok && page == 0) {
                cpu = withContext(Dispatchers.IO) {
                    Regex("""(\d+(?:\.\d+)?)%\s*TOTAL""", RegexOption.IGNORE_CASE)
                        .find(Shell.run("dumpsys cpuinfo | grep -i total"))?.groupValues?.get(1)?.toFloatOrNull()?.toInt() ?: -1
                }
            }
            delay(4000)
        }
    }

    LaunchedEffect(Unit) { apps = withContext(Dispatchers.IO) { loadApps(ctx) } }
    val games = gamePkgs.mapNotNull { p -> apps.find { it.pkg == p } }
    val selected = apps.find { it.pkg == pkg }

    fun saveList(l: List<String>) { gamePkgs = l; prefs.edit().putString("list", l.joinToString(",")).apply() }
    fun select(p: String) { pkg = p; boosted = false; prefs.edit().putString("sel", p).apply() }
    fun say(s: String) { log = (log + "\n" + s).lines().takeLast(14).joinToString("\n") }
    fun startGame(p: String = pkg) {
        try { ctx.packageManager.getLaunchIntentForPackage(p)?.let { ctx.startActivity(it) } } catch (_: Throwable) {}
    }
    fun ensureOverlay() {
        if (!OverlayService.running && Settings.canDrawOverlays(ctx)) {
            ctx.startForegroundService(Intent(ctx, OverlayService::class.java))
            overlay = true
        }
    }

    fun run(title: String, needGame: Boolean = false, f: () -> String) {
        if (busy) return
        if (needGame && pkg.isBlank()) { say("! select a game first"); return }
        busy = true
        say("> $title...")
        scope.launch {
            val r = withContext(Dispatchers.IO) { f() }
            say("  $r")
            busy = false
        }
    }

    fun fullBoost() {
        if (busy) return
        if (pkg.isBlank()) { say("! select a game first"); return }
        busy = true
        boosted = false
        say("> BOOST started")
        scope.launch {
            val steps = mutableListOf<Pair<String, () -> String>>(
                "game mode" to { Boost.gameMode(pkg, mode) },
                "clean ram" to { Boost.killBackground() }
            )
            if (fast) steps.add("fast anim" to { Boost.animations("0.5") })
            if (hz) steps.add("120Hz" to { Boost.refreshRate(120) })
            for ((n, f) in steps) {
                val r = withContext(Dispatchers.IO) { f() }
                say("  [$n] $r")
            }
            boosted = true
            busy = false
            startGame()
        }
    }

    fun toggleRecord() {
        rec = !rec
        if (rec) run("record") {
            Shell.run("mkdir -p /sdcard/Movies/AeroBoost; nohup screenrecord --time-limit 180 /sdcard/Movies/AeroBoost/rec_${System.currentTimeMillis()}.mp4 >/dev/null 2>&1 &")
            "recording (max 3 min)"
        } else run("record stop") { Shell.run("pkill -2 screenrecord"); "saved" }
    }

    if (page == 0) {
        HomeScreen(
            games = games, selected = selected, modeName = modeName(mode), battery = battery, cpu = cpu,
            rec = rec, busy = busy, linked = ok,
            onSelect = { select(it.pkg) },
            onRemove = { saveList(gamePkgs - it.pkg); if (pkg == it.pkg) select("") },
            onStart = {
                if (pkg.isBlank()) Toast.makeText(ctx, "Add a game first (+)", Toast.LENGTH_SHORT).show()
                else { ensureOverlay(); fullBoost() }
            },
            onMode = { mode = mode % 3 + 1; prefs.edit().putInt("mode", mode).apply() },
            onAdd = { showPicker = true },
            onRec = { toggleRecord() },
            onSettings = { page = 1 },
            onExit = { (ctx as? android.app.Activity)?.finish() }
        )
    } else {
        val swColors = SwitchDefaults.colors(
            checkedTrackColor = Cyan, checkedThumbColor = Color.White,
            uncheckedTrackColor = Color(0xFF16213A), uncheckedThumbColor = Dim, uncheckedBorderColor = Line
        )
        Box(Modifier.fillMaxSize().background(Bg)) {
            Column(Modifier.fillMaxSize().systemBarsPadding().displayCutoutPadding().padding(horizontal = 14.dp, vertical = 8.dp)) {
                Row(
                    Modifier.clip(RoundedCornerShape(8.dp)).clickable { page = 0 }.padding(horizontal = 6.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("\u2039", color = Color.White, fontSize = 24.sp)
                    Spacer(Modifier.size(12.dp))
                    Text("Settings", color = Color.White, fontWeight = FontWeight.Medium, fontSize = 17.sp)
                }
                Row(Modifier.weight(1f).padding(top = 6.dp)) {
                    // left: categories
                    Column(Modifier.width(150.dp).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("General", "Performance", "Tools").forEachIndexed { i, n ->
                            val sel = tab == i
                            Box(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp))
                                    .background(
                                        if (sel) Brush.horizontalGradient(listOf(Color(0xFF16356B), Color(0xFF0B1426)))
                                        else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
                                    )
                                    .clickable { tab = i }.padding(horizontal = 14.dp, vertical = 13.dp)
                            ) {
                                Text(n, color = if (sel) Cyan else Dim, fontSize = 14.sp, fontWeight = if (sel) FontWeight.Medium else FontWeight.Normal)
                            }
                        }
                    }
                    // right: rows
                    Column(Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()).padding(start = 18.dp)) {
                        when (tab) {
                            0 -> {
                                SettingRow("In-game panel", "Swipe from the left or right edge of the screen to open") {
                                    Switch(checked = overlay, colors = swColors, onCheckedChange = { on ->
                                        if (on) {
                                            if (!Settings.canDrawOverlays(ctx)) {
                                                ctx.startActivity(
                                                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))
                                                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                                )
                                                say("! allow 'Display over other apps', then switch on again")
                                            } else {
                                                ctx.startForegroundService(Intent(ctx, OverlayService::class.java))
                                                overlay = true
                                            }
                                        } else {
                                            ctx.stopService(Intent(ctx, OverlayService::class.java))
                                            overlay = false
                                        }
                                    })
                                }
                                SettingRow("AeroHUB", AeroAccess.message(aero), onClick = {
                                    if (aero == AeroAccess.State.NoPermission) AeroAccess.requestPermission(ctx)
                                    else AeroAccess.openAeroHub(ctx)
                                }) {
                                    Text(if (ok) "Linked" else "Connect", color = if (ok) Lime else Amber, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                }
                                Spacer(Modifier.size(12.dp))
                                Terminal(log.lines().takeLast(3).joinToString("\n"))
                            }
                            1 -> {
                                SettingRow("Game mode", "Standard, performance or battery saver for the selected game") {
                                    Box(Modifier.width(230.dp)) {
                                        ModeSelector(mode) { m ->
                                            mode = m
                                            prefs.edit().putInt("mode", m).apply()
                                            run("mode $m", true) { Boost.gameMode(pkg, m) }
                                        }
                                    }
                                }
                                SettingRow("120 Hz lock", "Smoother display (applied on Start)") {
                                    Switch(checked = hz, colors = swColors, onCheckedChange = {
                                        hz = it
                                        run(if (it) "120Hz" else "60Hz") { Boost.refreshRate(if (it) 120 else 60) }
                                    })
                                }
                                SettingRow("Fast animation", "Scale animations to 0.5x") {
                                    Switch(checked = fast, colors = swColors, onCheckedChange = {
                                        fast = it
                                        run("anim") { Boost.animations(if (it) "0.5" else "1") }
                                    })
                                }
                                SettingRow("Touch sensitivity", "Low = fewer accidental touches, high = faster response") {
                                    Column(Modifier.width(170.dp), horizontalAlignment = Alignment.End) {
                                        Text(touchName(touch), color = Cyan, fontWeight = FontWeight.Medium, fontSize = 12.sp)
                                        Slider(
                                            value = touch.toFloat(), onValueChange = { touch = it.toInt().coerceIn(1, 5) },
                                            onValueChangeFinished = {
                                                prefs.edit().putInt("touch", touch).apply()
                                                run("touch ${touchName(touch)}") { Boost.touch(touch) }
                                            },
                                            valueRange = 1f..5f, steps = 3,
                                            colors = SliderDefaults.colors(thumbColor = Cyan, activeTrackColor = Cyan, inactiveTrackColor = Color(0xFF16213A))
                                        )
                                    }
                                }
                            }
                            else -> {
                                SettingRow("Clean RAM", "Close background apps", onClick = { run("clean ram") { Boost.killBackground() } }) {
                                    Text("\u203A", color = Dim, fontSize = 22.sp)
                                }
                                SettingRow("Compile game", "Speed up the selected game", onClick = { run("compile", true) { Boost.compileSpeed(pkg) } }) {
                                    Text("\u203A", color = Dim, fontSize = 22.sp)
                                }
                                SettingRow("Device stats", "RAM and temperature", onClick = { run("stats") { Boost.stats() } }) {
                                    Text("\u203A", color = Dim, fontSize = 22.sp)
                                }
                                Spacer(Modifier.size(12.dp))
                                Terminal(log.lines().takeLast(3).joinToString("\n"))
                            }
                        }
                    }
                }
            }
        }
    }

    if (settled && !ok && !connectLater) {
        ConnectDialog(
            aero,
            onPrimary = {
                when (aero) {
                    AeroAccess.State.NoPermission -> AeroAccess.requestPermission(ctx)
                    AeroAccess.State.NotInstalled -> connectLater = true
                    else -> AeroAccess.openAeroHub(ctx)
                }
            },
            onLater = { connectLater = true }
        )
    }

    if (showPicker) {
        AppPickerDialog(apps, {
            if (it.pkg !in gamePkgs) saveList(gamePkgs + it.pkg)
            select(it.pkg)
            showPicker = false
        }, { showPicker = false })
    }
}

fun modeName(m: Int) = when (m) { 1 -> "Default"; 3 -> "Battery saver"; else -> "Performance" }

private val HomeBlue = Color(0xFF2E8BFF)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(
    games: List<AppInfo>, selected: AppInfo?, modeName: String, battery: Int, cpu: Int,
    rec: Boolean, busy: Boolean, linked: Boolean,
    onSelect: (AppInfo) -> Unit, onRemove: (AppInfo) -> Unit, onStart: () -> Unit, onMode: () -> Unit,
    onAdd: () -> Unit, onRec: () -> Unit, onSettings: () -> Unit, onExit: () -> Unit
) {
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0A0F1A), Color(0xFF111B2E), Color(0xFF070A12))))) {
        Column(Modifier.fillMaxSize().systemBarsPadding().displayCutoutPadding().padding(horizontal = 18.dp, vertical = 12.dp)) {
            // top bar: stats + actions
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(R.drawable.ic_battery, Color(0xFFB8C4DA), 16.dp)
                Text(if (battery >= 0) " $battery%" else " --%", color = Color(0xFFB8C4DA), fontSize = 12.sp)
                Spacer(Modifier.size(18.dp))
                Icon(R.drawable.ic_cpu, Color(0xFFB8C4DA), 16.dp)
                Text(if (cpu >= 0) " $cpu%" else " --%", color = Color(0xFFB8C4DA), fontSize = 12.sp)
                Spacer(Modifier.weight(1f))
                TopAction(R.drawable.ic_plus, Color(0xFFB8C4DA), onAdd)
                Spacer(Modifier.size(26.dp))
                TopAction(R.drawable.ic_video, if (rec) Color(0xFFFF4D5E) else Color(0xFFB8C4DA), onRec)
                Spacer(Modifier.size(26.dp))
                TopAction(R.drawable.ic_gear, Color(0xFFB8C4DA), onSettings)
                Spacer(Modifier.size(26.dp))
                TopAction(R.drawable.ic_exit, Color(0xFFB8C4DA), onExit)
            }

            // middle: game list | preview | start
            Row(Modifier.weight(1f).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.CenterStart) {
                    if (games.isEmpty()) {
                        Text("Tap + to add a game", color = Dim, fontSize = 13.sp)
                    } else {
                        LazyColumn(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(games, key = { it.pkg }) { g ->
                                val sel = g.pkg == selected?.pkg
                                Row(
                                    Modifier.fillMaxWidth()
                                        .then(if (sel) Modifier.background(Brush.horizontalGradient(listOf(Color(0x332E8BFF), Color.Transparent))) else Modifier)
                                        .combinedClickable(onClick = { onSelect(g) }, onLongClick = { onRemove(g) })
                                        .padding(vertical = if (sel) 10.dp else 6.dp, horizontal = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (sel && g.icon != null) {
                                        Image(g.icon, null, Modifier.size(38.dp).clip(RoundedCornerShape(9.dp)))
                                        Spacer(Modifier.size(10.dp))
                                    }
                                    Text(
                                        g.label, color = if (sel) Color.White else Color(0xFF8593AD),
                                        fontSize = if (sel) 18.sp else 13.sp,
                                        fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal,
                                        maxLines = 1, overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.size(16.dp))
                val card = RoundedCornerShape(6.dp)
                Box(
                    Modifier.weight(1.5f).aspectRatio(1.75f).clip(card)
                        .background(Color(0x14FFFFFF)).border(1.dp, Color(0x33FFFFFF), card),
                    contentAlignment = Alignment.Center
                ) {
                    if (selected?.icon != null) {
                        Image(selected.icon, null, Modifier.fillMaxSize().blur(28.dp).alpha(0.45f), contentScale = ContentScale.Crop)
                        Image(selected.icon, null, Modifier.size(84.dp).clip(RoundedCornerShape(18.dp)))
                    }
                }
                Spacer(Modifier.size(16.dp))
                Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.CenterEnd) {
                    Box(
                        Modifier.width(150.dp).height(54.dp).clip(RoundedCornerShape(6.dp))
                            .background(Brush.horizontalGradient(listOf(Color(0xFF1558C8), HomeBlue)))
                            .clickable(enabled = !busy, onClick = onStart),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(if (busy) "Boosting..." else "Start playing", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }

            // bottom: mode + hint
            Box(Modifier.fillMaxWidth().height(46.dp), contentAlignment = Alignment.Center) {
                Column(
                    Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onMode).padding(horizontal = 18.dp, vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(Modifier.width(26.dp).height(3.dp).background(HomeBlue, RoundedCornerShape(2.dp)))
                    Spacer(Modifier.height(6.dp))
                    Text(modeName, color = Color(0xFFB8C4DA), fontSize = 13.sp)
                }
                if (!linked) Text(
                    "AeroHUB not linked: open Settings", color = Dim, fontSize = 10.sp,
                    modifier = Modifier.align(Alignment.CenterStart).clickable(onClick = onSettings)
                )
            }
        }
    }
}

@Composable
private fun Icon(res: Int, tint: Color, size: Dp) =
    Image(painterResource(res), null, Modifier.size(size), colorFilter = ColorFilter.tint(tint))

@Composable
private fun TopAction(res: Int, tint: Color, onClick: () -> Unit) =
    Box(Modifier.size(34.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(res, tint, 24.dp)
    }

fun touchName(l: Int) = when (l) { 1 -> "Lowest"; 2 -> "Low"; 3 -> "Normal"; 4 -> "High"; else -> "Highest" }

@Composable
fun TouchSensitivity(level: Int, onChange: (Int) -> Unit, onDone: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Column(Modifier.fillMaxWidth().clip(shape).background(Panel).border(1.dp, Line, shape).padding(horizontal = 12.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("TOUCH SENSITIVITY", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.sp, modifier = Modifier.weight(1f))
            Text(touchName(level), color = Cyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
        Slider(
            value = level.toFloat(), onValueChange = { onChange(it.toInt().coerceIn(1, 5)) },
            onValueChangeFinished = onDone, valueRange = 1f..5f, steps = 3,
            colors = SliderDefaults.colors(thumbColor = Cyan, activeTrackColor = Cyan, inactiveTrackColor = Color(0xFF16213A))
        )
        Text("Low = fewer accidental touches, High = faster response", color = Dim, fontSize = 10.sp)
    }
}

@Composable
fun Header(ok: Boolean, onConnect: () -> Unit) {
    val t = rememberInfiniteTransition(label = "dot")
    val a by t.animateFloat(0.3f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "a")
    val c = if (ok) Lime else Magenta
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(
                "AERO BOOST",
                style = TextStyle(
                    brush = Brush.horizontalGradient(listOf(Cyan, Magenta)),
                    fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp
                )
            )
            Text("GAME TURBO ENGINE", color = Dim, fontSize = 9.sp, letterSpacing = 2.sp)
        }
        Row(
            Modifier.clip(RoundedCornerShape(50)).border(1.dp, c, RoundedCornerShape(50))
                .clickable(onClick = onConnect).padding(horizontal = 12.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(c.copy(alpha = a)))
            Spacer(Modifier.size(8.dp))
            Text(if (ok) "LINKED" else "CONNECT", color = c, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GameTile(g: AppInfo, selected: Boolean, onClick: () -> Unit, onLong: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        Modifier.clip(shape).combinedClickable(onClick = onClick, onLongClick = onLong).padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(62.dp).clip(shape)
                .border(
                    if (selected) 2.dp else 1.dp,
                    if (selected) Brush.linearGradient(listOf(Cyan, Magenta)) else Brush.linearGradient(listOf(Line, Line)),
                    shape
                ).background(Panel),
            contentAlignment = Alignment.Center
        ) {
            if (g.icon != null) Image(g.icon, null, Modifier.size(50.dp).clip(RoundedCornerShape(12.dp)))
        }
        Spacer(Modifier.height(4.dp))
        Text(
            g.label, color = if (selected) Cyan else Color.White, fontSize = 10.sp,
            maxLines = 1, overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun AddTile(onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(Modifier.clip(shape).clickable(onClick = onClick).padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(62.dp).clip(shape).border(1.dp, Cyan.copy(alpha = 0.6f), shape), contentAlignment = Alignment.Center) {
            Text("+", color = Cyan, fontSize = 28.sp, fontWeight = FontWeight.Light)
        }
        Spacer(Modifier.height(4.dp))
        Text("Add", color = Cyan, fontSize = 10.sp)
    }
}

@Composable
fun ModeSelector(mode: Int, onPick: (Int) -> Unit) {
    val names = listOf(1 to "STANDARD", 2 to "PERFORMANCE", 3 to "SAVER")
    val shape = RoundedCornerShape(12.dp)
    Row(Modifier.fillMaxWidth().clip(shape).background(Panel).border(1.dp, Line, shape).padding(3.dp)) {
        names.forEach { (m, n) ->
            val sel = m == mode
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                    .background(
                        if (sel) Brush.horizontalGradient(listOf(Cyan, Magenta))
                        else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
                    )
                    .clickable { onPick(m) }.padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(n, color = if (sel) Bg else Dim, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }
        }
    }
}

@Composable
fun SwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(Panel).border(1.dp, Line, shape).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.sp)
            Text(sub, color = Dim, fontSize = 10.sp)
        }
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedTrackColor = Cyan, checkedThumbColor = Bg,
                uncheckedTrackColor = Color(0xFF16213A), uncheckedThumbColor = Dim, uncheckedBorderColor = Line
            )
        )
    }
}

@Composable
fun SettingRow(title: String, sub: String, onClick: (() -> Unit)? = null, trailing: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth()
                .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
                .padding(horizontal = 4.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.Medium, fontSize = 15.sp)
                Text(sub, color = Dim, fontSize = 12.sp)
            }
            Spacer(Modifier.size(12.dp))
            trailing()
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(Line))
    }
}

@Composable
fun BoostButton(size: Dp, busy: Boolean, boosted: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "ring")
    val angle by t.animateFloat(
        0f, 360f, infiniteRepeatable(tween(if (busy) 900 else 5000, easing = LinearEasing)), label = "angle"
    )
    val pulse by t.animateFloat(0.9f, 1f, infiniteRepeatable(tween(1500), RepeatMode.Reverse), label = "pulse")
    val label = when {
        busy -> "BOOSTING"
        boosted -> "BOOSTED"
        else -> "BOOST"
    }
    val accent = if (boosted && !busy) Lime else Cyan
    Box(
        Modifier.size(size).clip(CircleShape).clickable(enabled = enabled && !busy, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val r = this.size.minDimension / 2 - 10.dp.toPx()
            drawCircle(
                Brush.radialGradient(listOf(accent.copy(alpha = 0.28f), Color.Transparent)),
                radius = this.size.minDimension / 2 * pulse
            )
            rotate(angle) {
                drawCircle(
                    Brush.sweepGradient(listOf(Color.Transparent, accent, Magenta, Color.Transparent)),
                    radius = r, style = Stroke(5.dp.toPx(), cap = StrokeCap.Round)
                )
            }
            drawCircle(Panel, radius = r - 9.dp.toPx())
            drawCircle(accent.copy(alpha = 0.35f), radius = r - 9.dp.toPx(), style = Stroke(1.dp.toPx()))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                label,
                style = TextStyle(
                    brush = Brush.horizontalGradient(listOf(accent, Color.White)),
                    fontSize = 18.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp
                )
            )
            Text(if (enabled) "TAP TO PLAY" else "LINK AEROHUB", color = Dim, fontSize = 8.sp, letterSpacing = 1.sp)
        }
    }
}

@Composable
fun ToolCard(title: String, sub: String, color: Color, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Column(
        modifier.clip(shape).background(Panel)
            .border(1.dp, Brush.linearGradient(listOf(color, color.copy(alpha = 0.1f))), shape)
            .clickable(onClick = onClick).padding(10.dp)
    ) {
        Text(title, color = color, fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.sp, maxLines = 1)
        Text(sub, color = Dim, fontSize = 9.sp)
    }
}

@Composable
fun Terminal(text: String) {
    val shape = RoundedCornerShape(12.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape).background(Color(0xFF02050A))
            .border(1.dp, Lime.copy(alpha = 0.4f), shape).padding(10.dp)
    ) {
        Text(text, color = Lime, fontFamily = FontFamily.Monospace, fontSize = 10.sp, lineHeight = 13.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
    }
}

data class AppInfo(val label: String, val pkg: String, val icon: ImageBitmap?)

fun loadApps(ctx: Context): List<AppInfo> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .distinctBy { it.activityInfo.packageName }
        .filter { it.activityInfo.packageName != ctx.packageName }
        .map { r ->
            AppInfo(
                r.loadLabel(pm).toString(),
                r.activityInfo.packageName,
                runCatching { r.loadIcon(pm).toBitmap(96, 96).asImageBitmap() }.getOrNull()
            )
        }
        .sortedBy { it.label.lowercase() }
}

@Composable
fun ConnectDialog(state: AeroAccess.State, onPrimary: () -> Unit, onLater: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    val (title, action) = when (state) {
        AeroAccess.State.NotInstalled -> "AeroHUB is not installed" to "OK"
        AeroAccess.State.NoPermission -> "Connect to AeroHUB" to "Allow"
        AeroAccess.State.NotRunning -> "AeroHUB is not running" to "Open AeroHUB"
        AeroAccess.State.Blocked -> "Access is blocked" to "Open AeroHUB"
        AeroAccess.State.Outdated -> "AeroHUB needs a restart" to "Open AeroHUB"
        AeroAccess.State.Ready -> "" to ""
    }
    Dialog(onDismissRequest = onLater) {
        Column(
            Modifier.fillMaxWidth().clip(shape).background(Panel)
                .border(1.dp, Cyan.copy(alpha = 0.5f), shape).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(AeroAccess.message(state), color = Dim, fontSize = 13.sp)
            Text("Aero Boost needs AeroHUB to run boost commands. Without it most features will not work.", color = Dim, fontSize = 11.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).border(1.dp, Line, RoundedCornerShape(10.dp))
                        .clickable(onClick = onLater).padding(vertical = 11.dp),
                    contentAlignment = Alignment.Center
                ) { Text("Later", color = Color.White, fontSize = 13.sp) }
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                        .background(Brush.horizontalGradient(listOf(Color(0xFF3B82F6), Color(0xFF22C7EE))))
                        .clickable(onClick = onPrimary).padding(vertical = 11.dp),
                    contentAlignment = Alignment.Center
                ) { Text(action, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
            }
        }
    }
}

@Composable
fun AppPickerDialog(apps: List<AppInfo>, onPick: (AppInfo) -> Unit, onDismiss: () -> Unit) {
    var q by remember { mutableStateOf("") }
    val list = apps.filter { it.label.contains(q, ignoreCase = true) }
    val shape = RoundedCornerShape(18.dp)
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier.fillMaxWidth().height(540.dp).clip(shape).background(Panel)
                .border(1.dp, Cyan.copy(alpha = 0.5f), shape).padding(14.dp)
        ) {
            Text("SELECT GAME", color = Cyan, fontWeight = FontWeight.Black, letterSpacing = 3.sp, fontSize = 16.sp)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = q, onValueChange = { q = it },
                placeholder = { Text("Search...", color = Dim) },
                singleLine = true, modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Cyan, unfocusedBorderColor = Color(0xFF222C3F),
                    cursorColor = Cyan, focusedTextColor = Color.White, unfocusedTextColor = Color.White
                )
            )
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.weight(1f)) {
                items(list, key = { it.pkg }) { a ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                            .clickable { onPick(a) }.padding(vertical = 8.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (a.icon != null) Image(a.icon, null, Modifier.size(40.dp).clip(RoundedCornerShape(9.dp)))
                        Spacer(Modifier.size(12.dp))
                        Column {
                            Text(a.label, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(a.pkg, color = Dim, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
    }
}
