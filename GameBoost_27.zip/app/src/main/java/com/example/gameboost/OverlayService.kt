package com.example.gameboost

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.PopupWindow
import android.graphics.drawable.ColorDrawable
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.min

/** In-game edge-swipe panel, styled like Xiaomi Game Turbo. */
class OverlayService : Service() {

    companion object { @Volatile var running = false }

    private val BLUE = 0xFF4C9AFF.toInt()
    private val BG = 0xF2121822.toInt()
    private val TILE = 0xFF1A2130.toInt()
    private val LINE = 0x26FFFFFF
    private val TXT = 0xFFEAF0FA.toInt()
    private val DIMT = 0xFF8B97AE.toInt()
    private val LIME = 0xFF2EE6A6.toInt()

    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private var handle: View? = null
    private var scrim: FrameLayout? = null
    private var timerTv: TextView? = null
    private var voicePop: PopupWindow? = null

    private var dnd = false
    private var rec = false
    private var hz = false
    private var gmode = 2
    private var vmode = 0
    private var timerRunning = false
    private var timerStart = 0L

    // boost + fps monitor state (lives in the service, so it survives closing/opening the panel)
    @Volatile private var boosted = false
    @Volatile private var boostBusy = false
    private var boostGame = ""
    private var fpsBefore = -1
    private val hist = ArrayList<Int>()
    @Volatile private var monGen = 0
    private var cardRender: (() -> Unit)? = null
    private var onFps: (() -> Unit)? = null
    private val sp by lazy { getSharedPreferences("panel", MODE_PRIVATE) }

    private fun save() {
        sp.edit().putBoolean("boosted", boosted).putString("game", boostGame).putInt("before", fpsBefore)
            .putBoolean("dnd", dnd).putBoolean("hz", hz).putInt("gmode", gmode).putInt("vmode", vmode).apply()
    }

    private fun load() {
        boosted = sp.getBoolean("boosted", false); boostGame = sp.getString("game", "") ?: ""
        fpsBefore = sp.getInt("before", -1)
        dnd = sp.getBoolean("dnd", false); hz = sp.getBoolean("hz", false)
        gmode = sp.getInt("gmode", 2); vmode = sp.getInt("vmode", 0)
    }

    private fun fpsAfter(): Int = synchronized(hist) {
        if (hist.isEmpty()) -1 else hist.takeLast(3).average().toInt()
    }

    private fun startMonitor() {
        val g = ++monGen
        val game = boostGame
        thread(isDaemon = true) {
            while (monGen == g && boosted) {
                val f = FpsMon.sample(game)
                synchronized(hist) { if (f >= 0) { hist.add(f); if (hist.size > 60) hist.removeAt(0) } }
                ui.post { onFps?.invoke() }
                try { Thread.sleep(if (scrim != null) 1000L else 3000L) } catch (_: InterruptedException) {}
            }
        }
    }

    private fun startBoost() {
        if (boostBusy || boosted) return
        boostBusy = true
        toast("Boost...")
        thread {
            val g = currentGame()
            FpsMon.reset()
            val before = FpsMon.sample(g)
            if (g.isNotBlank()) Boost.gameMode(g, gmode)
            Boost.killBackground()
            boostGame = g; fpsBefore = before
            synchronized(hist) { hist.clear() }
            boosted = true; boostBusy = false
            ui.post { save(); cardRender?.invoke(); toast("Boost ON"); startMonitor() }
        }
    }

    private fun stopBoost() {
        boosted = false; monGen++
        save()
        cardRender?.invoke()
        toast("Boost stopped")
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        AeroAccess.init(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("overlay", "Game panel", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "overlay")
            .setContentTitle("Aero Boost")
            .setContentText("Swipe from either screen edge in game")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            var t = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                t = t or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            startForeground(1, n, t)
        } else startForeground(1, n)
        load()
        addHandle()
        if (boosted) startMonitor()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onDestroy() {
        running = false
        monGen++
        save()
        VoiceFx.liveStop()
        ui.removeCallbacksAndMessages(null)
        hidePanel()
        handle?.let { runCatching { wm.removeView(it) } }
        handleR?.let { runCatching { wm.removeView(it) } }
        handle = null; handleR = null
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun ripple(content: android.graphics.drawable.Drawable, r: Int) =
        android.graphics.drawable.RippleDrawable(
            android.content.res.ColorStateList.valueOf(0x33FFFFFF), content, box(Color.WHITE, r)
        )

    private fun panelBg() = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xF2182030.toInt(), 0xF20F141E.toInt())).apply {
        cornerRadius = dp(16).toFloat()
        setStroke(dp(1), 0x26FFFFFF)
    }

    private fun tileBg(on: Boolean) =
        ripple(if (on) box(0x1F2EE6A6, 12, 0x662EE6A6) else box(TILE, 12, LINE), 12)

    private fun box(fill: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(r).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    // ---------- edge handles (left + right) ----------
    private var panelRight = false
    private var handleR: View? = null

    private fun makeHandle(right: Boolean): View {
        val sideG = if (right) Gravity.END else Gravity.START
        val r = dp(8).toFloat()
        // slim MIUI-style tab: only 10dp wide on screen, the touch area around it stays wider
        val v = FrameLayout(this)
        val tab = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setColor(0x99262B36.toInt())
                cornerRadii = if (right) floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r) else floatArrayOf(0f, 0f, r, r, r, r, 0f, 0f)
            }
        }
        tab.addView(View(this).apply { background = box(0xCCFFFFFF.toInt(), 1) },
            FrameLayout.LayoutParams(dp(2), dp(16), Gravity.CENTER))
        v.addView(tab, FrameLayout.LayoutParams(dp(10), dp(56), sideG or Gravity.CENTER_VERTICAL))
        var downX = 0f
        var fired = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; fired = false }
                MotionEvent.ACTION_MOVE -> {
                    val d = if (right) downX - e.rawX else e.rawX - downX
                    if (!fired && d > dp(14)) { fired = true; panelRight = right; showPanel() }
                }
                MotionEvent.ACTION_UP -> if (!fired && abs(e.rawX - downX) < dp(6)) { panelRight = right; showPanel() }
            }
            true
        }
        v.addOnLayoutChangeListener { view, l, t, rr, bt, _, _, _, _ ->
            if (Build.VERSION.SDK_INT >= 29)
                view.systemGestureExclusionRects = listOf(android.graphics.Rect(0, 0, rr - l, bt - t))
        }
        val dm = resources.displayMetrics
        val lp = WindowManager.LayoutParams(
            dp(24), dp(80),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = sideG or Gravity.TOP
            y = (dm.heightPixels * 0.62f).toInt()   // lower-middle, like MIUI Game Turbo
            if (Build.VERSION.SDK_INT >= 28)
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(v, lp)
        return v
    }

    private fun addHandle() {
        handle = makeHandle(false)
        handleR = makeHandle(true)
    }

    // ---------- panel window ----------
    private fun showPanel() {
        if (scrim != null) return
        AeroAccess.startPolling(this)
        val dm = resources.displayMetrics
        val right = panelRight
        val s = FrameLayout(this).apply {
            setBackgroundColor(0x66000000)
            setOnClickListener { hidePanel() }
        }
        val sw = dm.widthPixels.toFloat(); val sh = dm.heightPixels.toFloat()
        val stripW = (sw * 0.068f).toInt()
        val gap = (sw * 0.012f).toInt()
        val mainW = (sw * 0.333f).toInt()
        val mainH = (sh * 0.814f).toInt()
        val stripH = (sh * 0.91f).toInt()
        val p = buildPanel(stripW, stripH, mainW, mainH, gap)
        s.addView(p, FrameLayout.LayoutParams(stripW + gap + mainW, ViewGroup.LayoutParams.WRAP_CONTENT,
            (if (right) Gravity.END else Gravity.START) or Gravity.TOP).apply {
            val m = (sw * 0.048f).toInt()
            if (right) rightMargin = m else leftMargin = m
            topMargin = (sh * 0.038f).toInt()
        })
        wm.addView(
            s,
            WindowManager.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                if (Build.VERSION.SDK_INT >= 28)
                    layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        )
        scrim = s
        p.translationX = if (right) pw.toFloat() else -pw.toFloat()
        p.animate().translationX(0f).setDuration(200).start()
    }

    private fun hidePanel() {
        save()
        cardRender = null; onFps = null
        voicePop?.dismiss(); voicePop = null
        AeroAccess.stopPolling()
        scrim?.let { runCatching { wm.removeView(it) } }
        scrim = null
        timerTv = null
    }

    // ---------- UI pieces ----------
    private fun ic(res: Int, tint: Int) = ImageView(this).apply {
        setImageResource(res)
        setColorFilter(tint)
    }

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun badge(res: Int, tint: Int, bg: Int, size: Int = 34, icon: Int = 20) = FrameLayout(this).apply {
        background = box(bg, size / 2)
        addView(ic(res, tint), FrameLayout.LayoutParams(dp(icon), dp(icon), Gravity.CENTER))
        layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
    }

    private fun actionTile(res: Int, text: String, click: () -> Unit): LinearLayout {
        val me = this
        return LinearLayout(me).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = tileBg(false)
            setPadding(dp(2), dp(3), dp(2), dp(3))
            addView(badge(res, BLUE, 0x264C9AFF, 28, 17))
            addView(label(text, 9f, TXT).apply { gravity = Gravity.CENTER; setPadding(0, dp(2), 0, 0); maxLines = 2 })
            setOnClickListener { click() }
        }
    }

    private fun toolItem(res: Int, text: String, on: Boolean, click: (LinearLayout) -> Unit): LinearLayout {
        val me = this
        return LinearLayout(me).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = tileBg(on)
            setPadding(dp(1), dp(3), dp(1), dp(3))
            addView(badge(res, if (on) LIME else BLUE, if (on) 0x262EE6A6 else 0x264C9AFF, 26, 16))
            addView(label(text, 8.5f, if (on) LIME else DIMT).apply { gravity = Gravity.CENTER; setPadding(0, dp(2), 0, 0); maxLines = 1 })
            setOnClickListener { click(this) }
        }
    }

    private fun setOn(v: LinearLayout, on: Boolean) {
        val b = v.getChildAt(0) as FrameLayout
        v.background = tileBg(on)
        b.background = box(if (on) 0x262EE6A6 else 0x264C9AFF, 11)
        (b.getChildAt(0) as ImageView).setColorFilter(if (on) LIME else BLUE)
        (v.getChildAt(1) as TextView).setTextColor(if (on) LIME else DIMT)
    }

    private fun wideTile(res: Int, text: String, filled: Boolean, click: () -> Unit): Pair<LinearLayout, TextView> {
        val me = this
        val tv = label(text, 11f, TXT).apply { setPadding(dp(6), 0, 0, 0); maxLines = 1 }
        val l = LinearLayout(me).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = box(TILE, 10, LINE)
            setPadding(dp(6), dp(7), dp(6), dp(7))
            addView(ic(res, BLUE), LinearLayout.LayoutParams(dp(18), dp(18)))
            addView(tv)
            setOnClickListener { click() }
        }
        return l to tv
    }

    private fun gameName() = when (gmode) { 1 -> "Standard"; 3 -> "Saver"; else -> "Perform" }

    private fun buildPanel(stripW: Int, stripH: Int, mainW: Int, mainH: Int, gap: Int): LinearLayout {
        val me = this
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val root = LinearLayout(me).apply { orientation = LinearLayout.HORIZONTAL; isClickable = true }

        // --- left strip: games ---
        val strip = LinearLayout(me).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(4), dp(6), dp(4), dp(6)) }
        val iconPx = (stripW - dp(8)).coerceAtLeast(dp(24))
        (getSharedPreferences("games", MODE_PRIVATE).getString("list", "") ?: "")
            .split(",").filter { it.isNotBlank() }.forEach { p ->
                try {
                    val iv = ImageView(me).apply {
                        setImageDrawable(packageManager.getApplicationIcon(p))
                        background = box(Color.TRANSPARENT, 9); clipToOutline = true
                        setOnClickListener { launchFloating(p) }
                        setOnLongClickListener { launchNormal(p); hidePanel(); true }   // long-press = full screen
                    }
                    strip.addView(iv, LinearLayout.LayoutParams(iconPx, iconPx).apply { setMargins(0, dp(3), 0, dp(3)) })
                } catch (_: Throwable) {}
            }
        root.addView(ScrollView(me).apply { background = panelBg(); addView(strip) }, LinearLayout.LayoutParams(stripW, stripH))

        // --- main panel (everything fits in 4 columns) ---
        val col = LinearLayout(me).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(6), dp(8), dp(8)) }
        val mainSv = ScrollView(me).apply { background = panelBg(); isFillViewport = true; addView(col) }

        val head = LinearLayout(me).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(label("AERO TURBO", 13f, BLUE, true).apply { letterSpacing = 0.14f }, LinearLayout.LayoutParams(wrap, wrap))
        val linked = AeroAccess.state == AeroAccess.State.Ready
        head.addView(View(me).apply { background = box(if (linked) LIME else 0xFFFFB84D.toInt(), 3) },
            LinearLayout.LayoutParams(dp(6), dp(6)).apply { leftMargin = dp(8) })
        head.addView(label(if (linked) "Linked" else "Not linked", 10f, DIMT).apply { setPadding(dp(4), 0, 0, 0) },
            LinearLayout.LayoutParams(0, wrap, 1f))
        head.addView(ic(R.drawable.ic_close, DIMT).apply { setOnClickListener { hidePanel() }; setPadding(dp(3), dp(3), dp(3), dp(3)) },
            LinearLayout.LayoutParams(dp(18), dp(18)))
        col.addView(head)

        fun cell() = LinearLayout.LayoutParams(0, match, 1f).apply { leftMargin = dp(6) }
        fun cellFirst() = LinearLayout.LayoutParams(0, match, 1f)

        // ---- top block: [Clear memory / Free storage] | [Boost performance card] ----
        val top = LinearLayout(me).apply { orientation = LinearLayout.HORIZONTAL }

        val leftCol = LinearLayout(me).apply { orientation = LinearLayout.VERTICAL }
        leftCol.addView(actionTile(R.drawable.ic_rocket, "Clear memory") { act("Clear memory") { Boost.killBackground() } },
            LinearLayout.LayoutParams(match, 0, 1f))
        leftCol.addView(actionTile(R.drawable.ic_trash, "Free up storage") { act("Free storage") { Shell.run("pm trim-caches 100G") } },
            LinearLayout.LayoutParams(match, 0, 1f).apply { topMargin = dp(4) })
        top.addView(leftCol, LinearLayout.LayoutParams((mainW * 0.25f).toInt(), match))

        val card = LinearLayout(me).apply { orientation = LinearLayout.VERTICAL }
        val YEL = 0xFFE9D320.toInt()
        var afterTv: TextView? = null
        var beforeTv: TextView? = null
        var chart: View? = null

        fun infoRow(res: Int, text: String, click: () -> Unit) {
            card.addView(View(me).apply { setBackgroundColor(LINE) },
                LinearLayout.LayoutParams(match, dp(1)).apply { topMargin = dp(2) })
            card.addView(LinearLayout(me).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = ripple(box(Color.TRANSPARENT, 6), 6)
                setPadding(0, dp(6), 0, dp(6))
                addView(ic(res, BLUE), LinearLayout.LayoutParams(dp(16), dp(16)))
                addView(label(text, 9.5f, TXT).apply { maxLines = 1; setPadding(dp(8), 0, 0, 0) })
                setOnClickListener { click() }
            }, LinearLayout.LayoutParams(match, wrap))
        }

        fun fmt(v: Int) = if (v < 0) "--" else v.toString()

        fun renderCard() {
            card.removeAllViews()
            card.setPadding(dp(7), dp(5), dp(7), dp(5))
            if (!boosted) {
                afterTv = null; beforeTv = null; chart = null
                card.background = box(TILE, 12, LINE)
                card.addView(label("Boost performance", 10.5f, TXT, true).apply { gravity = Gravity.END },
                    LinearLayout.LayoutParams(match, wrap))
                infoRow(R.drawable.ic_tune, "Clear memory automatically") { act("Clear memory") { Boost.killBackground() } }
                infoRow(R.drawable.ic_storage, "Free up storage space") { act("Free storage") { Shell.run("pm trim-caches 100G") } }
                infoRow(R.drawable.ic_chart, "Monitor performance") { act("Monitor") { Boost.stats() } }
                card.addView(View(me), LinearLayout.LayoutParams(match, 0, 1f))
                card.addView(label(if (boostBusy) "Boosting..." else "Boost", 12f, Color.WHITE, true).apply {
                    gravity = Gravity.CENTER
                    background = ripple(GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF3B82F6.toInt(), 0xFF22C7EE.toInt()))
                        .apply { cornerRadius = dp(8).toFloat() }, 8)
                    setPadding(0, dp(5), 0, dp(5))
                    setOnClickListener { startBoost(); text = "Boosting..." }
                }, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(4) })
            } else {
                card.background = box(0x14E9D320, 12, 0x99E9D320.toInt())
                card.addView(label("Performance", 10.5f, YEL, true).apply { gravity = Gravity.END },
                    LinearLayout.LayoutParams(match, wrap))
                val cv = FpsChart(me, hist, YEL, DIMT)
                chart = cv
                card.addView(cv, LinearLayout.LayoutParams(match, 0, 1f).apply { topMargin = dp(2) })
                val stats = LinearLayout(me).apply { orientation = LinearLayout.HORIZONTAL }
                val aT = label("", 9.5f, TXT, true); val bT = label("", 9.5f, DIMT, true)
                afterTv = aT; beforeTv = bT
                stats.addView(aT, LinearLayout.LayoutParams(0, wrap, 1f))
                stats.addView(bT, LinearLayout.LayoutParams(wrap, wrap))
                card.addView(stats, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(2) })
                card.addView(label("Stop", 11f, YEL, true).apply {
                    gravity = Gravity.CENTER
                    background = ripple(box(0x33E9D320, 8, 0x99E9D320.toInt()), 8)
                    setPadding(0, dp(4), 0, dp(4))
                    setOnClickListener { stopBoost() }
                }, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(3) })
                onFps = {
                    afterTv?.text = "\u25CF ${fmt(fpsAfter())} FPS  After"
                    beforeTv?.text = "\u25CB ${fmt(fpsBefore)} FPS  Before"
                    chart?.invalidate()
                }
                onFps?.invoke()
            }
        }
        cardRender = { renderCard() }
        renderCard()
        top.addView(card, LinearLayout.LayoutParams(0, match, 1f).apply { leftMargin = dp(4) })
        col.addView(top, LinearLayout.LayoutParams(match, 0, 1.9f).apply { topMargin = dp(6) })

        // voice changer box (opens under the grid)
        val voiceBox = LinearLayout(me).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            background = box(TILE, 10, LINE)
            setPadding(dp(8), dp(6), dp(8), dp(8))
        }

        // ---- tools strip (scrolls sideways) ----
        val toolW = ((mainW - dp(20)) / 4.4f).toInt()
        val tp = { LinearLayout.LayoutParams(toolW, match).apply { setMargins(dp(1), dp(1), dp(1), dp(1)) } }
        val strip2 = LinearLayout(me).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(2), dp(2), dp(2), dp(2)) }
        strip2.addView(toolItem(R.drawable.ic_cut, "Screenshot", false) {
            hidePanel()
            ui.postDelayed({
                thread {
                    val r = Shell.run("mkdir -p /sdcard/Pictures/AeroBoost; screencap -p /sdcard/Pictures/AeroBoost/shot_${System.currentTimeMillis()}.png")
                    ui.post { toast(if (r == "OK") "Screenshot saved" else r) }
                }
            }, 400)
        }, tp())
        strip2.addView(toolItem(R.drawable.ic_video, "Record", rec) { v ->
            rec = !rec; setOn(v, rec)
            if (rec) {
                hidePanel()
                thread {
                    Shell.run("mkdir -p /sdcard/Movies/AeroBoost; nohup screenrecord --time-limit 180 /sdcard/Movies/AeroBoost/rec_${System.currentTimeMillis()}.mp4 >/dev/null 2>&1 &")
                    ui.post { toast("Recording...") }
                }
            } else act("Record stop") { Shell.run("pkill -2 screenrecord"); "saved" }
        }, tp())
        strip2.addView(toolItem(R.drawable.ic_dnd, "DND", dnd) { v ->
            dnd = !dnd; setOn(v, dnd)
            act("DND " + if (dnd) "on" else "off") { Shell.run("cmd notification set_dnd " + if (dnd) "on" else "off") }
        }, tp())
        strip2.addView(toolItem(R.drawable.ic_gear, "Settings", false) {
            hidePanel()
            startActivity(Intent(me, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }, tp())
        strip2.addView(toolItem(R.drawable.ic_bolt, "120Hz", hz) { v ->
            hz = !hz; setOn(v, hz)
            act(if (hz) "120Hz" else "60Hz") { Boost.refreshRate(if (hz) 120 else 60) }
        }, tp())
        strip2.addView(toolItem(R.drawable.ic_rocket, gameName(), false) { v ->
            gmode = gmode % 3 + 1
            (v.getChildAt(1) as TextView).text = gameName()
            act("Mode " + gameName()) { Boost.gameMode(currentGame(), gmode) }
        }, tp())
        col.addView(HorizontalScrollView(me).apply {
            isHorizontalScrollBarEnabled = false
            isFillViewport = true
            background = box(Color.TRANSPARENT, 12, LINE)
            addView(strip2, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, match))
        }, LinearLayout.LayoutParams(match, 0, 0.85f).apply { topMargin = dp(6) })

        // ---- bottom row: Voice changer | Timer ----
        fun setWideOn(v: LinearLayout, on: Boolean) {
            v.background = if (on) box(0x1F2EE6A6, 10, 0x662EE6A6) else box(TILE, 10, LINE)
            (v.getChildAt(0) as ImageView).setColorFilter(if (on) LIME else BLUE)
            (v.getChildAt(1) as TextView).setTextColor(if (on) LIME else TXT)
        }
        var showVoiceBox: (Boolean) -> Unit = {}
        val voiceTile = wideTile(R.drawable.ic_mic, "Voice changer", false) {}.first
        if (VoiceFx.liveOn) setWideOn(voiceTile, true)
        // one tap = live voice changer on/off (no hold button any more)
        voiceTile.setOnClickListener {
            if (VoiceFx.liveOn) {
                VoiceFx.liveStop(); setWideOn(voiceTile, false); voiceBox.visibility = View.GONE
            } else if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                toast("Allow the microphone in Aero Boost first")
            } else {
                VoiceFx.liveMode = vmode
                if (VoiceFx.liveStart(this)) { setWideOn(voiceTile, true); showVoiceBox(true) } else toast("Microphone is busy")
            }
        }
        val (timerTile, ttv) = wideTile(R.drawable.ic_hourglass, timerText(), false) {}
        timerTv = ttv
        timerTile.setOnClickListener {
            timerRunning = !timerRunning
            if (timerRunning) { timerStart = System.currentTimeMillis(); tick() }
            timerTv?.text = timerText()
        }
        if (timerRunning) tick()
        val bottom = LinearLayout(me).apply { orientation = LinearLayout.HORIZONTAL }
        bottom.addView(voiceTile, LinearLayout.LayoutParams(0, match, 1.2f))
        bottom.addView(timerTile, LinearLayout.LayoutParams(0, match, 1f).apply { leftMargin = dp(6) })
        col.addView(bottom, LinearLayout.LayoutParams(match, 0, 0.6f).apply { topMargin = dp(6) })

        // voice changer content
        val names = listOf("Girl", "Robot", "Cat")
        val chipRow = LinearLayout(me).apply { orientation = LinearLayout.HORIZONTAL }
        val chips = names.map { n -> label(n, 11f, TXT, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(6)) } }
        fun paint() {
            chips.forEachIndexed { i, v ->
                val sel = i == vmode
                v.background = if (sel) box(BLUE, 6) else box(Color.TRANSPARENT, 6, LINE)
                v.setTextColor(if (sel) 0xFF05070D.toInt() else TXT)
            }
        }
        chips.forEachIndexed { i, v ->
            v.setOnClickListener { vmode = i; VoiceFx.liveMode = i; paint(); save() }
            chipRow.addView(v, LinearLayout.LayoutParams(0, wrap, 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        }
        paint()
        val hint = label("Pick a voice, hold the button and talk. It plays when you let go.", 9f, DIMT)
        voiceBox.addView(hint)
        voiceBox.addView(chipRow, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(6) })
        val talk = label("Hold to talk", 12f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF3B82F6.toInt(), 0xFF22C7EE.toInt()))
                .apply { cornerRadius = dp(6).toFloat() }
            setPadding(0, dp(9), 0, dp(9))
        }
        talk.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                        toast("Allow the microphone in Aero Boost first")
                    } else if (VoiceFx.start()) {
                        talk.text = "Recording..."
                    } else toast("Microphone is busy")
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (VoiceFx.active) {
                        talk.text = "Hold to talk"
                        VoiceFx.finish(vmode)
                    }
                }
            }
            true
        }
        voiceBox.addView(talk, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(6) })
        col.addView(voiceBox, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(6) })
        showVoiceBox = { live ->
            hint.text = if (live) "LIVE: your voice is changed as you talk and plays very quietly from the earpiece. Pick a voice below."
                        else "Pick a voice, hold the button and talk. It plays when you let go."
            talk.visibility = if (live) View.GONE else View.VISIBLE
            voiceBox.visibility = View.VISIBLE
            mainSv.post { mainSv.fullScroll(View.FOCUS_DOWN) }
        }
        if (VoiceFx.liveOn) showVoiceBox(true)

        root.addView(mainSv, LinearLayout.LayoutParams(mainW, mainH).apply { leftMargin = gap })
        return root
    }

    // ---------- helpers ----------
    private fun timerText(): String {
        if (!timerRunning) return "Timer"
        val s = (System.currentTimeMillis() - timerStart) / 1000
        return "%02d:%02d".format(s / 60, s % 60)
    }

    private fun tick() {
        ui.removeCallbacks(tickRun)
        ui.postDelayed(tickRun, 1000)
    }

    private val tickRun = object : Runnable {
        override fun run() {
            if (!timerRunning) return
            timerTv?.text = timerText()
            ui.postDelayed(this, 1000)
        }
    }

    private fun launchNormal(p: String) {
        packageManager.getLaunchIntentForPackage(p)?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); runCatching { startActivity(it) }
        }
    }

    private fun settingOn(key: String) = runCatching {
        android.provider.Settings.Global.getInt(contentResolver, key, 0) == 1
    }.getOrDefault(false)

    /** Opens the app in a freeform (floating) window. If the two developer options are off, asks the user to enable them first. */
    private fun launchFloating(p: String) {
        val missing = mutableListOf<String>()
        if (!settingOn("enable_freeform_support")) missing += "Enable freeform windows"
        if (!settingOn("force_resizable_activities")) missing += "Force activities to be resizable"
        if (missing.isEmpty()) startFloating(p) else showFloatPrompt(p, missing)
    }

    private fun startFloating(p: String) {
        hidePanel()
        val comp = packageManager.getLaunchIntentForPackage(p)?.component?.flattenToShortString()
        if (comp == null || !Shell.ready()) { launchNormal(p); return }
        thread {
            val r = Shell.run("am start --user 0 --windowingMode 5 -n ${AeroAccess.sq(comp)}")
            if (r.startsWith("Error") || r.startsWith("exit") || r.contains("Error type", true))
                ui.post { toast("Floating window not supported here, opening normally"); launchNormal(p) }
        }
    }

    private fun showFloatPrompt(p: String, missing: List<String>) {
        var v: FrameLayout? = null
        val close = { v?.let { runCatching { wm.removeView(it) } }; v = null }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = box(BG, 14, LINE)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            isClickable = true
            addView(label("Turn on in Developer options", 13f, TXT, true))
            addView(label(missing.joinToString("\n") { "•  $it" }, 12f, BLUE).apply { setPadding(0, dp(8), 0, dp(4)) })
            addView(label("Floating windows need both switched on.", 10f, DIMT))
            val row = LinearLayout(this@OverlayService).apply { orientation = LinearLayout.HORIZONTAL }
            fun btn(t: String, fill: Boolean, c: () -> Unit) = label(t, 11f, if (fill) Color.WHITE else TXT, true).apply {
                gravity = Gravity.CENTER
                background = if (fill) box(0xFF3B82F6.toInt(), 8) else box(Color.TRANSPARENT, 8, LINE)
                setPadding(0, dp(8), 0, dp(8))
                setOnClickListener { c() }
            }
            row.addView(btn("Open settings", true) {
                close()
                hidePanel()
                runCatching {
                    startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }.onFailure { toast("Open Settings > Developer options") }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(btn("Try anyway", false) {
                close()
                thread {
                    Shell.run("settings put global enable_freeform_support 1; settings put global force_resizable_activities 1")
                    ui.post { startFloating(p) }
                }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(8) })
            addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) })
        }
        val root = FrameLayout(this).apply {
            setBackgroundColor(0x88000000.toInt())
            setOnClickListener { close() }
            addView(card, FrameLayout.LayoutParams(dp(280), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        }
        v = root
        wm.addView(
            root,
            WindowManager.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
        )
    }

    /** Small floating chooser above the Voice button: Hold (push-to-talk) or On/Off (live). */
    private fun showVoicePopup(anchor: View, liveOn: Boolean, onHold: () -> Unit, onToggle: () -> Unit) {
        voicePop?.dismiss()
        lateinit var pw: PopupWindow
        fun opt(res: Int, text: String, on: Boolean, c: () -> Unit) = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(8), dp(12), dp(8))
            background = box(if (on) 0x262EE6A6 else 0x264C9AFF, 10)
            addView(ic(res, if (on) LIME else BLUE), LinearLayout.LayoutParams(dp(16), dp(16)))
            addView(label(text, 11f, if (on) LIME else TXT, true).apply { setPadding(dp(6), 0, 0, 0) })
            setOnClickListener { pw.dismiss(); c() }
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = box(BG, 14, LINE)
            setPadding(dp(6), dp(6), dp(6), dp(6))
            addView(opt(R.drawable.ic_mic, "Hold", false, onHold))
            addView(opt(R.drawable.ic_bolt, if (liveOn) "Off" else "On", liveOn, onToggle),
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(6) })
        }
        content.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        pw = PopupWindow(content, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, false).apply {
            isOutsideTouchable = true
            setBackgroundDrawable(ColorDrawable(0))
            elevation = dp(8).toFloat()
        }
        voicePop = pw
        pw.showAsDropDown(anchor, (anchor.width - content.measuredWidth) / 2, -(anchor.height + content.measuredHeight + dp(4)))
    }

    private fun toast(t: String) = Toast.makeText(this, t.take(200), Toast.LENGTH_LONG).show()

    private fun act(name: String, f: () -> String) {
        toast("$name...")
        thread {
            val r = try { f() } catch (e: Throwable) { "Error: ${e.message}" }
            ui.post { toast("$name: $r") }
        }
    }

    private fun currentGame(): String {
        val r = Shell.run("dumpsys activity activities | grep -m1 -E 'topResumedActivity|mResumedActivity'")
        val p = Regex("([a-zA-Z][a-zA-Z0-9_]*(?:\\.[a-zA-Z0-9_]+)+)/").find(r)?.groupValues?.get(1)
        if (p != null && p != packageName && !p.startsWith("com.android.systemui")) return p
        return getSharedPreferences("games", MODE_PRIVATE).getString("sel", "") ?: ""
    }
}


/** Small line/area chart of the last ~60 FPS samples (0 to 120 FPS, grows if the game goes above 120). */
class FpsChart(c: android.content.Context, private val data: List<Int>, private val col: Int, private val dim: Int) : View(c) {
    private val line = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        style = android.graphics.Paint.Style.STROKE; strokeWidth = 2f * resources.displayMetrics.density; color = col
        strokeJoin = android.graphics.Paint.Join.ROUND
    }
    private val fill = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    private val grid = android.graphics.Paint().apply { color = 0x22FFFFFF; strokeWidth = 1f }
    private val txt = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = dim; textSize = 8f * resources.displayMetrics.scaledDensity
    }

    override fun onDraw(cv: android.graphics.Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val left = txt.measureText("120") + 6f
        val d = synchronized(data) { data.toList() }
        val top = if ((d.maxOrNull() ?: 0) > 120) 240 else 120
        fun y(v: Int) = h - (v.coerceIn(0, top) / top.toFloat()) * (h - 2f) - 1f
        for (v in listOf(0, top / 2, top)) {
            cv.drawLine(left, y(v), w, y(v), grid)
            cv.drawText(v.toString(), 0f, y(v) + txt.textSize / 3f, txt)
        }
        if (d.size < 2) return
        val step = (w - left) / 59f
        val path = android.graphics.Path()
        val area = android.graphics.Path()
        val x0 = w - (d.size - 1) * step
        d.forEachIndexed { i, v ->
            val x = x0 + i * step
            if (i == 0) { path.moveTo(x, y(v)); area.moveTo(x, h); area.lineTo(x, y(v)) } else { path.lineTo(x, y(v)); area.lineTo(x, y(v)) }
        }
        area.lineTo(w, h); area.close()
        fill.shader = android.graphics.LinearGradient(0f, 0f, 0f, h, (col and 0x00FFFFFF) or 0x99000000.toInt(), 0x00000000, android.graphics.Shader.TileMode.CLAMP)
        cv.drawPath(area, fill)
        cv.drawPath(path, line)
    }
}
