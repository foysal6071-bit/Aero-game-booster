package com.example.gameboost

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.TextView

/**
 * Our own floating web window (Facebook / YouTube), drawn as an overlay.
 *  - drag the top bar to move it
 *  - drag the bottom-right corner to resize
 *  - drag the window down to the bottom of the screen (the X circle lights up) and let go to close it
 */
object FloatWeb {
    private class Win(val root: FrameLayout, val web: WebView, val lp: WindowManager.LayoutParams)

    private val wins = LinkedHashMap<String, Win>()

    fun closeAll(wm: WindowManager) { wins.keys.toList().forEach { close(wm, it) } }

    private fun close(wm: WindowManager, key: String) {
        val w = wins.remove(key) ?: return
        runCatching { w.web.stopLoading(); w.web.loadUrl("about:blank") }
        runCatching { wm.removeView(w.root) }
        runCatching { w.root.removeAllViews(); w.web.destroy() }
    }

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    fun show(ctx: Context, wm: WindowManager, key: String, url: String) {
        wins[key]?.let { runCatching { wm.removeView(it.root); wm.addView(it.root, it.lp) }; return }   // already open: bring to front

        val d = ctx.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val dm = ctx.resources.displayMetrics
        val sw = dm.widthPixels; val sh = dm.heightPixels
        val portrait = sh > sw
        val minW = dp(200); val minH = dp(180)
        val w0 = if (portrait) (sw * 0.92f).toInt() else (sw * 0.5f).toInt()
        val h0 = if (portrait) (sh * 0.5f).toInt() else (sh * 0.78f).toInt()

        val lp = WindowManager.LayoutParams(
            w0, h0,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (sw - w0) / 2 + wins.size * dp(18)
            y = (sh * 0.1f).toInt() + wins.size * dp(18)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        }

        val web = WebView(ctx)
        val root = object : FrameLayout(ctx) {
            private val clip = android.graphics.Path()
            private val rr = dp(24).toFloat()
            override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
                super.onSizeChanged(w, h, ow, oh)
                clip.reset(); clip.addRoundRect(0f, 0f, w.toFloat(), h.toFloat(), rr, rr, android.graphics.Path.Direction.CW)
            }
            override fun dispatchDraw(c: android.graphics.Canvas) {
                val n = c.save(); c.clipPath(clip); super.dispatchDraw(c); c.restoreToCount(n)
            }
            override fun dispatchKeyEvent(e: KeyEvent): Boolean {
                if (e.keyCode == KeyEvent.KEYCODE_BACK) {
                    if (e.action == KeyEvent.ACTION_UP && web.canGoBack()) web.goBack()
                    return true
                }
                return super.dispatchKeyEvent(e)
            }
        }.apply {
            background = GradientDrawable().apply { setColor(0xFF10152A.toInt()); cornerRadius = dp(24).toFloat(); setStroke(dp(1), 0x55FFFFFF) }
            clipToOutline = true
            outlineProvider = object : android.view.ViewOutlineProvider() {
                override fun getOutline(v: View, o: android.graphics.Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(24).toFloat()) }
            }
        }

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            loadWithOverviewMode = true
            useWideViewPort = true
        }
        runCatching { CookieManager.getInstance().setAcceptThirdPartyCookies(web, true) }
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.setBackgroundColor(Color.BLACK)
        root.addView(web, FrameLayout.LayoutParams(-1, -1).apply { topMargin = dp(26) })

        // ---- top bar: drag to move ----
        val bar = FrameLayout(ctx).apply {
            setBackgroundColor(0xFF1B2240.toInt())
            addView(View(ctx).apply {
                background = GradientDrawable().apply { setColor(0x88FFFFFF.toInt()); cornerRadius = dp(2).toFloat() }
            }, FrameLayout.LayoutParams(dp(44), dp(4), Gravity.CENTER))
        }
        root.addView(bar, FrameLayout.LayoutParams(-1, dp(26), Gravity.TOP))

        // ---- bottom-right corner: drag to resize ----
        val grip = View(ctx).apply {
            background = GradientDrawable().apply { setColor(0x66000000); cornerRadii = floatArrayOf(dp(10).toFloat(), dp(10).toFloat(), 0f, 0f, dp(24).toFloat(), dp(24).toFloat(), 0f, 0f) }
        }
        root.addView(grip, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.BOTTOM or Gravity.END))
        val gripMark = TextView(ctx).apply {
            text = "↘"; setTextColor(0xCCFFFFFF.toInt()); textSize = 15f; gravity = Gravity.CENTER
        }
        root.addView(gripMark, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.BOTTOM or Gravity.END))

        // ---- close target shown while dragging ----
        var target: TextView? = null
        var hot = false
        fun targetOn(on: Boolean) {
            if (on && target == null) {
                val t = TextView(ctx).apply {
                    text = "✕"; textSize = 22f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
                    background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xCC333A55.toInt()) }
                }
                val tl = WindowManager.LayoutParams(
                    dp(64), dp(64), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    PixelFormat.TRANSLUCENT
                ).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = dp(36) }
                if (runCatching { wm.addView(t, tl) }.isSuccess) target = t
            } else if (!on) {
                target?.let { runCatching { wm.removeView(it) } }; target = null; hot = false
            }
        }
        fun setHot(h: Boolean) {
            if (h == hot) return
            hot = h
            target?.let {
                (it.background as GradientDrawable).setColor(if (h) 0xFFE53935.toInt() else 0xCC333A55.toInt())
                it.scaleX = if (h) 1.25f else 1f; it.scaleY = it.scaleX
            }
        }

        val w = Win(root, web, lp)

        var dx0 = 0f; var dy0 = 0f; var x0 = 0; var y0 = 0
        bar.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dx0 = e.rawX; dy0 = e.rawY; x0 = lp.x; y0 = lp.y; targetOn(true) }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = (x0 + (e.rawX - dx0)).toInt().coerceIn(-lp.width + dp(70), sw - dp(70))
                    lp.y = (y0 + (e.rawY - dy0)).toInt().coerceAtLeast(0)
                    runCatching { wm.updateViewLayout(root, lp) }
                    setHot(e.rawY > sh * 0.8f)
                }
                MotionEvent.ACTION_UP -> { val close = hot; targetOn(false); if (close) close(wm, key) }
                MotionEvent.ACTION_CANCEL -> targetOn(false)
            }
            true
        }

        var rx = 0f; var ry = 0f; var rw = 0; var rh = 0
        val resize = View.OnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { rx = e.rawX; ry = e.rawY; rw = lp.width; rh = lp.height }
                MotionEvent.ACTION_MOVE -> {
                    lp.width = (rw + (e.rawX - rx)).toInt().coerceIn(minW, sw)
                    lp.height = (rh + (e.rawY - ry)).toInt().coerceIn(minH, sh)
                    runCatching { wm.updateViewLayout(root, lp) }
                }
            }
            true
        }
        grip.setOnTouchListener(resize)
        gripMark.setOnTouchListener(resize)

        wins[key] = w
        if (runCatching { wm.addView(root, lp) }.isFailure) { wins.remove(key); runCatching { web.destroy() }; return }
        web.loadUrl(url)
    }
}
