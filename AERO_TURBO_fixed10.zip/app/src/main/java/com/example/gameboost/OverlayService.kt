package com.example.gameboost

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.PopupWindow
import android.graphics.drawable.ColorDrawable
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.min

/** In-game edge-swipe panel, styled like Xiaomi Aero Turbo. */
class OverlayService : Service() {

    companion object { @Volatile var running = false }

    // Aero Turbo palette: deep navy surfaces, cool blue accents, and crisp pale text
    private val BLUE = 0xFF08B8FF.toInt()
    private val VIOLET = 0xFF287BCE.toInt()
    private val RED = 0xFFFF526B.toInt()
    private val BG = 0xF20A1428.toInt()
    private val TILE = 0xFF14243D.toInt()
    private val LINE = 0x6687B7E8
    private val TXT = 0xFFEAF3FF.toInt()
    private val DIMT = 0xFF9EADC3.toInt()
    private val LIME = 0xFF45E98A.toInt()

    // GameTurbo-style panel palette
    private val GT_PANEL_TOP = 0xF51C2236.toInt()
    private val GT_PANEL_BOT = 0xF5141A2B.toInt()
    private val GT_TILE_TOP = 0xFF1B2238.toInt()
    private val GT_TILE_BOT = 0xFF141A2C.toInt()
    private val GT_BORDER = 0xCCA2AEC6.toInt()
    private val GT_ICON = 0xFFC9D1E0.toInt()
    private val GT_TXT = 0xFFE9EDF5.toInt()
    private val GT_DIM = 0xFFB3BBCB.toInt()
    private val GT_BLUE = 0xFF2F86FF.toInt()

    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private var handle: View? = null
    private var scrim: FrameLayout? = null
    private var panelView: View? = null
    private var panelSlide = 0f   // how far the panel travels off-screen when opening/closing
    private var timerTv: TextView? = null

    private var dnd = false
    private var rec = false
    private var recStart = 0L
    private var recTv: TextView? = null
    private var recView: LinearLayout? = null
    private val recTick = object : Runnable {
        override fun run() {
            if (!rec) return
            val t = ((System.currentTimeMillis() - recStart) / 1000).toInt()
            if (t >= 180) { rec = false; recTv?.text = "Record"; recView?.let { setOn(it, false) }; return }
            recTv?.text = "%02d:%02d".format(t / 60, t % 60)
            ui.postDelayed(this, 500)
        }
    }
    private var fps = 0
    private var fpsPop: PopupWindow? = null
    private var gmode = 2
    private var xhair = 0                 // 0 = off, 1 = dot, 2 = cross, 3 = circle
    private var xhairView: View? = null
    private var xcol = 0                  // index into XCOLORS
    private val XCOLORS = intArrayOf(0xFF39FF88.toInt(), 0xFFFF3B30.toInt(), 0xFF00E5FF.toInt(), 0xFFFFD60A.toInt(), 0xFFFFFFFF.toInt(), 0xFFFF2DCC.toInt())
    private var timerRunning = false
    private var timerStart = 0L

    // extra tools: live monitor, gesture lock, keep-awake/brightness lock, notification + call block
    private var mon = false
    private var glock = false
    private var awake = false
    private var blk = 0                   // 0 = off, 1 = no heads-up pop-ups, 2 = no pop-ups and auto-reject calls
    private var monView: TextView? = null
    private var guardView: View? = null
    private var awakeView: View? = null
    @Volatile private var monGen2 = 0
    private val syncLock = Any()
    private var lastCpu: LongArray? = null

    // boost + fps monitor state (lives in the service, so it survives closing/opening the panel)
    @Volatile private var boosted = false
    @Volatile private var boostBusy = false
    private var boostGame = ""
    private var fpsBefore = -1
    private val hist = ArrayList<Int>()
    @Volatile private var monGen = 0
    private var cardRender: (() -> Unit)? = null
    private var onFps: (() -> Unit)? = null
    private val sp by lazy { getSharedPreferences("panel", MODE_PRIVATE) }

    private fun save() {
        sp.edit().putBoolean("boosted", boosted).putString("game", boostGame).putInt("before", fpsBefore)
            .putBoolean("dnd", dnd).putInt("xhair", xhair).putInt("xcol", xcol).putInt("fps", fps).putInt("gmode", gmode)
            .putBoolean("mon", mon).putBoolean("glock", glock).putBoolean("awake", awake).putInt("blk", blk).apply()
    }

    private fun load() {
        boosted = sp.getBoolean("boosted", false); boostGame = sp.getString("game", "") ?: ""
        fpsBefore = sp.getInt("before", -1)
        dnd = sp.getBoolean("dnd", false); xhair = sp.getInt("xhair", 0); xcol = sp.getInt("xcol", 0).coerceIn(0, XCOLORS.size - 1); fps = sp.getInt("fps", if (sp.getBoolean("hz", false)) 120 else 0)
        gmode = sp.getInt("gmode", 2)
        mon = sp.getBoolean("mon", false); glock = sp.getBoolean("glock", false)
        awake = sp.getBoolean("awake", false); blk = sp.getInt("blk", 0).coerceIn(0, 2)
    }

    private fun fpsAfter(): Int = synchronized(hist) {
        if (hist.isEmpty()) -1 else hist.takeLast(3).average().toInt()
    }

    private fun startMonitor() {
        val g = ++monGen
        val game = boostGame
        thread(isDaemon = true) {
            while (monGen == g && boosted) {
                val f = FpsMon.sample(game)
                synchronized(hist) { if (f >= 0) { hist.add(f); if (hist.size > 60) hist.removeAt(0) } }
                ui.post { onFps?.invoke() }
                try { Thread.sleep(if (scrim != null) 1000L else 3000L) } catch (_: InterruptedException) {}
            }
        }
    }

    private fun startBoost() {
        if (boostBusy || boosted) return
        boostBusy = true
        toast("Boost...")
        thread {
            val g = currentGame()
            FpsMon.reset()
            val before = FpsMon.sample(g)
            if (g.isNotBlank()) Boost.gameMode(g, gmode)
            Boost.killBackground()
            // user's saved settings apply only inside the selected game
            val gp = getSharedPreferences("games", MODE_PRIVATE)
            val tp = gp.getInt("touchPct", 50)
            if (tp !in 45..55) Boost.touch(tp)
            if (gp.getBoolean("fast", false)) Boost.animations("0.5")
            val hz = gp.getInt("rate", 0)
            if (hz > 0 && fps == 0) Boost.refreshRate(hz)
            boostGame = g; fpsBefore = before
            synchronized(hist) { hist.clear() }
            boosted = true; boostBusy = false
            GameWatch.start(g)
            ui.post { save(); cardRender?.invoke(); toast("Boost ON"); startMonitor() }
        }
    }

    private fun stopBoost() {
        boosted = false; monGen++; fps = 0
        GameWatch.stop()
        save()
        cardRender?.invoke()
        thread {
            val r = SettingsBackup.restore()
            ui.post { toast(if (r.startsWith("restore failed")) r else "Boost stopped, settings restored") }
        }
    }

    private val gameEnded: () -> Unit = {
        if (running) {
            boosted = false; monGen++; fps = 0
            save()
            cardRender?.invoke()
            toast("Game closed, boost ended")
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        AeroAccess.init(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("overlay", "Game panel", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "overlay")
            .setContentTitle("AERO TURBO")
            .setContentText("Panel appears only inside your selected games")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else startForeground(1, n)
        load()
        startFgWatch()
        if (boosted) startMonitor()
        GameWatch.addListener(gameEnded)
        GameWatch.resume()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    /** App swiped from recents: restart the service so the panel keeps working. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        val pi = android.app.PendingIntent.getForegroundService(
            this, 7, Intent(this, OverlayService::class.java),
            android.app.PendingIntent.FLAG_ONE_SHOT or android.app.PendingIntent.FLAG_IMMUTABLE)
        (getSystemService(ALARM_SERVICE) as android.app.AlarmManager)
            .set(android.app.AlarmManager.ELAPSED_REALTIME, android.os.SystemClock.elapsedRealtime() + 1000, pi)
    }

    /** Screen rotated (landscape <-> portrait): close the open panel and move the edge tabs. */
    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        if (scrim != null) hidePanel(false)
        ui.postDelayed({
            listOf(handle, handleR).forEach { v ->
                val lp = v?.layoutParams as? WindowManager.LayoutParams ?: return@forEach
                lp.y = handleY()
                runCatching { wm.updateViewLayout(v, lp) }
            }
        }, 300)
    }

    override fun onDestroy() {
        running = false
        fgGen++
        monGen++
        GameWatch.removeListener(gameEnded)
        if (boosted || GameWatch.active) {   // panel closed while boosting: give the phone its settings back
            boosted = false
            GameWatch.stop()
            thread { SettingsBackup.restore() }
        }
        save()
        ui.removeCallbacksAndMessages(null)
        FloatWeb.closeAll(wm)
        hidePanel(false)
        handle?.let { runCatching { wm.removeView(it) } }
        handleR?.let { runCatching { wm.removeView(it) } }
        handle = null; handleR = null; handlesShown = false
        xhairView?.let { runCatching { wm.removeView(it) } }; xhairView = null
        monGen2++
        listOf(monView, guardView, awakeView).forEach { v -> v?.let { runCatching { wm.removeView(it) } } }
        monView = null; guardView = null; awakeView = null
        thread { SettingsBackup.restore(Keys.GESTURE + Keys.BRIGHT + Keys.NOTIF) }
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun ripple(content: android.graphics.drawable.Drawable, r: Int) =
        android.graphics.drawable.RippleDrawable(
            android.content.res.ColorStateList.valueOf(0x33FFFFFF), content, box(Color.WHITE, r)
        )

    /** Angular (chamfered-corner) neon frame, the core of the gaming look. */
    private fun gbox(fill: Int, stroke: Int, cut: Int = 8, fill2: Int = fill) =
        Chamfer(fill, fill2, stroke, cut * resources.displayMetrics.density, resources.displayMetrics.density)

    private fun gripple(content: android.graphics.drawable.Drawable, cut: Int = 8) =
        android.graphics.drawable.RippleDrawable(
            android.content.res.ColorStateList.valueOf(0x4400E5FF), content, gbox(Color.WHITE, 0, cut)
        )

    private fun frame(top: Int, bottom: Int, stroke: Int, r: Int, bevel: Int = 0, notch: Int = 0, ticks: Boolean = false) =
        TurboFrame(top, bottom, stroke, r * resources.displayMetrics.density, resources.displayMetrics.density,
            bevel * resources.displayMetrics.density, notch * resources.displayMetrics.density, ticks)

    private fun fripple(content: android.graphics.drawable.Drawable, r: Int) =
        android.graphics.drawable.RippleDrawable(
            android.content.res.ColorStateList.valueOf(0x33FFFFFF), content, box(Color.WHITE, r)
        )

    private fun panelBg() = frame(GT_PANEL_TOP, GT_PANEL_BOT, 0x33FFFFFF, 24)

    private fun stripBg() = frame(0xF2161C30.toInt(), 0xF2161C30.toInt(), 0x22FFFFFF, 24)

    private fun tileBg() = fripple(frame(GT_TILE_TOP, GT_TILE_BOT, GT_BORDER, 13), 13)

    private fun toolBg(on: Boolean) =
        fripple(if (on) frame(0x2608B8FF, 0x2608B8FF, 0x8808B8FF.toInt(), 9) else box(Color.TRANSPARENT, 9), 9)

    private fun glow(tv: TextView, color: Int) = tv.apply { setShadowLayer(dp(6).toFloat(), 0f, 0f, color) }

    private fun box(fill: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(r).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    // ---------- edge handle (single, left edge) ----------
    private var panelRight = false
    private var handleR: View? = null

    private fun screenH() = resources.displayMetrics.heightPixels.coerceAtLeast(1)
    private fun isPortrait() = resources.displayMetrics.heightPixels > resources.displayMetrics.widthPixels
    private fun handleKey() = if (isPortrait()) "handleY_port" else "handleY_land"
    private fun handleY(): Int {
        val h = screenH()
        val f = sp.getFloat(handleKey(), 0.18f)
        return (h * f).toInt().coerceIn(0, (h - dp(80)).coerceAtLeast(0))
    }

    private fun makeHandle(right: Boolean): View {
        val sideG = if (right) Gravity.END else Gravity.START
        val r = dp(8).toFloat()
        // slim MIUI-style tab: only 10dp wide on screen, the touch area around it stays wider
        val v = FrameLayout(this)
        val tab = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setColor(0xE60A0D18.toInt())
                setStroke(dp(1), 0xAA00E5FF.toInt())
                cornerRadii = if (right) floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r) else floatArrayOf(0f, 0f, r, r, r, r, 0f, 0f)
            }
        }
        tab.addView(View(this).apply { background = box(BLUE, 1) },
            FrameLayout.LayoutParams(dp(2), dp(20), Gravity.CENTER))
        v.addView(tab, FrameLayout.LayoutParams(dp(10), dp(56), sideG or Gravity.CENTER_VERTICAL))
        var downX = 0f; var downY = 0f; var startY = 0
        var fired = false; var moving = false
        val longPress = Runnable {
            moving = true
            tab.animate().scaleX(1.25f).scaleY(1.1f).alpha(0.85f).setDuration(100).start()
            v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
        }
        v.setOnTouchListener { _, e ->
            val lp = v.layoutParams as? WindowManager.LayoutParams
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; fired = false; moving = false
                    startY = lp?.y ?: 0
                    ui.postDelayed(longPress, 350)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (moving) {
                        // long-press, then slide up/down to place the tab
                        if (lp != null) {
                            val maxY = (screenH() - lp.height).coerceAtLeast(0)
                            lp.y = (startY + (e.rawY - downY).toInt()).coerceIn(0, maxY)
                            runCatching { wm.updateViewLayout(v, lp) }
                        }
                    } else {
                        if (abs(e.rawY - downY) > dp(8) || abs(e.rawX - downX) > dp(8)) ui.removeCallbacks(longPress)
                        val d = if (right) downX - e.rawX else e.rawX - downX
                        if (!fired && d > dp(14)) { fired = true; panelRight = right; showPanel() }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    ui.removeCallbacks(longPress)
                    if (moving) {
                        moving = false
                        tab.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(120).start()
                        if (lp != null) sp.edit().putFloat(handleKey(), lp.y.toFloat() / screenH()).apply()
                    } else if (e.actionMasked == MotionEvent.ACTION_UP && !fired && abs(e.rawX - downX) < dp(6) && abs(e.rawY - downY) < dp(6)) {
                        panelRight = right; showPanel()
                    }
                }
            }
            true
        }
        v.addOnLayoutChangeListener { view, l, t, rr, bt, _, _, _, _ ->
            if (Build.VERSION.SDK_INT >= 29)
                view.systemGestureExclusionRects = listOf(android.graphics.Rect(0, 0, rr - l, bt - t))
        }
        val dm = resources.displayMetrics
        val lp = WindowManager.LayoutParams(
            dp(24), dp(80),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = sideG or Gravity.TOP
            y = handleY()   // saved spot per orientation; default: upper part of the left edge
            if (Build.VERSION.SDK_INT >= 28)
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(v, lp)
        return v
    }

    private fun addHandle() {
        handle = makeHandle(false)   // one tab, left edge; long-press + slide to move up/down
    }

    // ---------- edge tabs exist only while a selected game is on screen ----------
    @Volatile private var fgGen = 0
    private var handlesShown = false

    private fun selectedGames(): Set<String> =
        (getSharedPreferences("games", MODE_PRIVATE).getString("list", "") ?: "")
            .split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()

    /** Package of the app on screen right now, or null if it could not be read. */
    private fun topPackage(): String? {
        val r = Shell.run("dumpsys activity activities | grep -m1 -E 'topResumedActivity|mResumedActivity'")
        return Regex("([a-zA-Z][a-zA-Z0-9_]*(?:\\.[a-zA-Z0-9_]+)+)/").find(r)?.groupValues?.get(1)
    }

    private fun showHandles() {
        if (handlesShown) return
        handlesShown = true
        addHandle()
        applyCrosshair()
        applyExtras()
    }

    /** Game left the screen: the edge tabs and an open panel disappear. */
    private fun hideHandles() {
        if (!handlesShown) return
        handlesShown = false
        if (scrim != null) hidePanel(false)
        handle?.let { runCatching { wm.removeView(it) } }
        handleR?.let { runCatching { wm.removeView(it) } }
        handle = null; handleR = null
        applyCrosshair()
        applyExtras()
    }

    private fun startFgWatch() {
        val g = ++fgGen
        val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
        thread(isDaemon = true) {
            while (fgGen == g) {
                if (pm.isInteractive) {
                    val top = topPackage()
                    // unreadable result or system UI (shade, recents) on top: keep the current state
                    if (top != null && !top.startsWith("com.android.systemui")) {
                        val shortcutsEnabled = getSharedPreferences("games", MODE_PRIVATE).getBoolean("inGameShortcuts", true)
                        val inGame = shortcutsEnabled && top in selectedGames()
                        ui.post { if (fgGen == g) { if (inGame) showHandles() else hideHandles() } }
                        if (inGame && blk == 2) rejectRingingCall()
                    }
                }
                try { Thread.sleep(1000) } catch (_: InterruptedException) {}
            }
        }
    }

    // ---------- panel window ----------
    private fun showPanel() {
        if (scrim != null) return
        AeroAccess.startPolling(this)
        val dm = resources.displayMetrics
        val right = panelRight
        val s = FrameLayout(this).apply {
            setBackgroundColor(0x99000000.toInt())
            setOnClickListener { hidePanel() }
        }
        val sw = dm.widthPixels.toFloat(); val sh = dm.heightPixels.toFloat()
        val portrait = sh > sw
        val stripW: Int; val gap: Int; val mainW: Int; val mainH: Int; val stripH: Int
        val edgeM: Float; val topM: Int
        if (portrait) {
            // portrait: nearly full width, height from content (scrolls if the screen is short)
            edgeM = sw * 0.02f
            stripW = (sw * 0.115f).toInt()
            gap = (sw * 0.012f).toInt()
            mainW = (sw - 2 * edgeM).toInt() - stripW - gap
            mainH = (sh * 0.58f).toInt().coerceIn(dp(400), dp(580)).coerceAtMost((sh * 0.82f).toInt())
            stripH = (mainH + dp(24)).coerceAtMost((sh * 0.92f).toInt())
            topM = (sh * 0.07f).toInt()
        } else {
            edgeM = sw * 0.048f
            stripW = (sw * 0.068f).toInt()
            gap = (sw * 0.012f).toInt()
            mainW = (sw * 0.333f).toInt()
            mainH = (sh * 0.814f).toInt()
            stripH = (sh * 0.91f).toInt()
            topM = (sh * 0.038f).toInt()
        }
        val p = buildPanel(stripW, stripH, mainW, mainH, gap)
        s.addView(p, FrameLayout.LayoutParams(stripW + gap + mainW, ViewGroup.LayoutParams.WRAP_CONTENT,
            if (portrait) Gravity.CENTER else (if (right) Gravity.END else Gravity.START) or Gravity.TOP).apply {
            if (!portrait) {
                val m = edgeM.toInt()
                if (right) rightMargin = m else leftMargin = m
                topMargin = topM
            }
        })
        wm.addView(
            s,
            WindowManager.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                if (Build.VERSION.SDK_INT >= 28)
                    layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        )
        scrim = s
        panelView = p
        // open animation: dim fades in, panel slides in from its edge with a soft fade
        val m = edgeM
        panelSlide = (stripW + gap + mainW) + m
        s.alpha = 0f
        p.translationX = if (right) panelSlide else -panelSlide
        p.alpha = 0f
        s.animate().alpha(1f).setDuration(240).setInterpolator(DecelerateInterpolator()).start()
        p.animate().translationX(0f).alpha(1f).setDuration(280)
            .setInterpolator(DecelerateInterpolator(1.8f)).start()
    }

    private fun hidePanel(animate: Boolean = true) {
        save()
        cardRender = null; onFps = null; recTv = null; recView = null
        fpsPop?.dismiss(); fpsPop = null
        AeroAccess.stopPolling()
        val s = scrim
        val p = panelView
        scrim = null
        panelView = null
        timerTv = null
        if (s == null) return
        val remove = { runCatching { wm.removeView(s) }; Unit }
        if (!animate || p == null) { remove(); return }
        // close animation: panel slides back out while the dim fades away, then the window is removed
        s.isClickable = false
        s.setOnClickListener(null)
        val out = if (panelRight) panelSlide else -panelSlide
        s.animate().alpha(0f).setDuration(200).setInterpolator(AccelerateInterpolator()).start()
        p.animate().translationX(out).alpha(0f).setDuration(220)
            .setInterpolator(AccelerateInterpolator(1.5f)).withEndAction { remove() }.start()
        ui.postDelayed({ remove() }, 400)   // safety net if the animation is cancelled
    }

    // ---------- UI pieces ----------
    private fun ic(res: Int, tint: Int) = ImageView(this).apply {
        setImageResource(res)
        setColorFilter(tint)
    }

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun badge(res: Int, tint: Int, bg: Int, size: Int = 34, icon: Int = 20) = FrameLayout(this).apply {
        background = box(bg, size / 2)
        addView(ic(res, tint), FrameLayout.LayoutParams(dp(icon), dp(icon), Gravity.CENTER))
        layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
    }

    private fun actionTile(res: Int, text: String, click: () -> Unit): LinearLayout {
        val me = this
        return LinearLayout(me).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = tileBg()
            setPadding(dp(2), dp(4), dp(2), dp(6))
            addView(ic(res, GT_ICON), LinearLayout.LayoutParams(dp(24), dp(24)))
            addView(label(text, 8.5f, GT_DIM).apply { gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0); maxLines = 2 })
            setOnClickListener { click() }
        }
    }

    private fun toolItem(res: Int, text: String, on: Boolean, click: (LinearLayout) -> Unit): LinearLayout {
        val me = this
        return LinearLayout(me).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = toolBg(on)
            clipChildren = true; clipToPadding = true
            setPadding(dp(1), dp(3), dp(1), dp(3))
            addView(ic(res, if (on) BLUE else GT_ICON), LinearLayout.LayoutParams(dp(24), dp(24)))
            addView(label(text, 9f, if (on) BLUE else GT_DIM).apply { gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0); maxLines = 1 })
            setOnClickListener { click(this) }
        }
    }

    private fun setOn(v: LinearLayout, on: Boolean) {
        v.background = toolBg(on)
        (v.getChildAt(0) as ImageView).setColorFilter(if (on) BLUE else GT_ICON)
        (v.getChildAt(1) as TextView).setTextColor(if (on) BLUE else GT_DIM)
    }

    /** Bottom-row tile. filled = solid grey (Timer), otherwise dark with a light border. */
    private fun wideTile(res: Int, text: String, filled: Boolean, click: () -> Unit): Pair<LinearLayout, TextView> {
        val me = this
        val tv = label(text, 10.5f, GT_TXT, true).apply { setPadding(dp(8), 0, 0, 0); maxLines = 2; includeFontPadding = false }
        val l = LinearLayout(me).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = if (filled) fripple(frame(0xFF4D5368.toInt(), 0xFF40465A.toInt(), 0, 10), 10)
                         else fripple(frame(GT_TILE_TOP, GT_TILE_BOT, GT_BORDER, 10), 10)
            setPadding(dp(10), dp(6), dp(8), dp(6))
            addView(ic(res, GT_ICON), LinearLayout.LayoutParams(dp(20), dp(20)))
            addView(tv)
            setOnClickListener { click() }
        }
        return l to tv
    }

    private fun gameName() = when (gmode) { 1 -> "Standard"; 3 -> "Saver"; else -> "Perform" }

    private fun buildPanel(stripW: Int, stripH: Int, mainW: Int, mainH: Int, gap: Int): LinearLayout {
        val me = this
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val root = LinearLayout(me).apply { orientation = LinearLayout.HORIZONTAL; isClickable = true }

        // --- left strip: apps added by the user (open in a floating window) + a "+" at the end ---
        val strip = LinearLayout(me).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(4), dp(10), dp(4), dp(10)) }
        val iconPx = (stripW - dp(8)).coerceAtLeast(dp(24))
        fun fillStrip() {
            strip.removeAllViews()
            floatApps().forEach { p ->
                try {
                    val iv = ImageView(me).apply {
                        setImageDrawable(packageManager.getApplicationIcon(p))
                        background = box(Color.TRANSPARENT, 10); clipToOutline = true
                        setOnClickListener { launchFloating(p) }
                        setOnLongClickListener { launchNormal(p); hidePanel(); true }   // long-press = full screen
                    }
                    strip.addView(iv, LinearLayout.LayoutParams(iconPx, iconPx).apply { setMargins(0, dp(5), 0, dp(5)) })
                } catch (_: Throwable) {}
            }
            val plus = ImageView(me).apply {
                setImageResource(R.drawable.ic_plus)
                setColorFilter(BLUE)
                scaleType = ImageView.ScaleType.CENTER
                setPadding(dp(6), dp(6), dp(6), dp(6))
                background = frame(Color.TRANSPARENT, Color.TRANSPARENT, GT_BORDER, 10)
                setOnClickListener { showAppPicker { fillStrip() } }
            }
            strip.addView(plus, LinearLayout.LayoutParams(iconPx, iconPx).apply { setMargins(0, dp(5), 0, dp(5)) })
        }
        fillStrip()
        root.addView(ScrollView(me).apply { background = stripBg(); addView(strip) }, LinearLayout.LayoutParams(stripW, stripH))

        // --- main panel (everything fits in 4 columns) ---
        val col = LinearLayout(me).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(9), dp(10), dp(10)) }
        val mainSv = ScrollView(me).apply { background = panelBg(); isFillViewport = true; addView(col) }

        val head = LinearLayout(me).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(label("AERO TURBO", 15f, GT_BLUE, true).apply {
            letterSpacing = 0.14f; setTypeface(Typeface.DEFAULT_BOLD, Typeface.BOLD_ITALIC)
            setShadowLayer(dp(5).toFloat(), 0f, 0f, 0xCC2F86FF.toInt())
        }, LinearLayout.LayoutParams(wrap, wrap))
        val linked = AeroAccess.state == AeroAccess.State.Ready
        head.addView(View(me).apply { background = box(if (linked) LIME else RED, 3) },
            LinearLayout.LayoutParams(dp(6), dp(6)).apply { leftMargin = dp(8) })
        head.addView(label(if (linked) "Linked" else "Not linked", 9f, GT_DIM).apply { setPadding(dp(4), 0, 0, 0) },
            LinearLayout.LayoutParams(0, wrap, 1f))
        col.addView(head)

        fun cell() = LinearLayout.LayoutParams(0, match, 1f).apply { leftMargin = dp(6) }
        fun cellFirst() = LinearLayout.LayoutParams(0, match, 1f)

        // ---- top block: [Clear memory / Free storage] | [Boost performance card] ----
        val top = LinearLayout(me).apply { orientation = LinearLayout.HORIZONTAL }

        val leftCol = LinearLayout(me).apply { orientation = LinearLayout.VERTICAL }
        leftCol.addView(actionTile(R.drawable.ic_rocket, "Clear memory") { act("Clear memory") { Boost.killBackground() } },
            LinearLayout.LayoutParams(match, 0, 1f))
        leftCol.addView(actionTile(R.drawable.ic_trash, "Free up storage") { act("Free storage") { Shell.run("pm trim-caches 100G") } },
            LinearLayout.LayoutParams(match, 0, 1f).apply { topMargin = dp(4) })
        top.addView(leftCol, LinearLayout.LayoutParams((mainW * 0.23f).toInt(), match))

        val card = LinearLayout(me).apply { orientation = LinearLayout.VERTICAL }
        val YEL = 0xFFFFD60A.toInt()
        var afterTv: TextView? = null
        var beforeTv: TextView? = null
        var chart: View? = null

        fun infoRow(res: Int, text: String, click: () -> Unit) {
            card.addView(LinearLayout(me).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = fripple(box(Color.TRANSPARENT, 6), 6)
                setPadding(0, dp(1), 0, dp(1))
                addView(ic(res, 0xFFBFD3F2.toInt()), LinearLayout.LayoutParams(dp(18), dp(18)))
                addView(label(text, 9.5f, GT_DIM).apply { maxLines = 1; setPadding(dp(10), 0, 0, 0) })
                setOnClickListener { click() }
            }, LinearLayout.LayoutParams(match, 0, 1f))
            card.addView(View(me).apply {
                background = android.graphics.drawable.GradientDrawable(
                    android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,
                    intArrayOf(0x00FFFFFF, 0x33FFFFFF, 0x00FFFFFF))
            }, LinearLayout.LayoutParams(match, dp(1)))
        }

        fun fmt(v: Int) = if (v < 0) "--" else v.toString()

        fun renderCard() {
            card.removeAllViews()
            card.setPadding(dp(8), dp(5), dp(8), dp(6))
            if (!boosted) {
                afterTv = null; beforeTv = null; chart = null
                card.background = frame(GT_TILE_TOP, GT_TILE_BOT, GT_BORDER, 13, bevel = 14, ticks = true)
                card.addView(label("Boost performance", 10.5f, Color.WHITE, true).apply { gravity = Gravity.END; setPadding(0, dp(3), dp(2), dp(3)) },
                    LinearLayout.LayoutParams(match, wrap))
                infoRow(R.drawable.ic_tune, "Clear memory automatically") { act("Clear memory") { Boost.killBackground() } }
                infoRow(R.drawable.ic_storage, "Free up storage space") { act("Free storage") { Shell.run("pm trim-caches 100G") } }
                infoRow(R.drawable.ic_chart, "Monitor performance") { act("Monitor") { Boost.stats() } }
                card.addView(label(if (boostBusy) "Boosting..." else "Boost", 12f, Color.WHITE, true).apply {
                    gravity = Gravity.CENTER
                    background = fripple(frame(0xFF2E9BE8.toInt(), 0xFF1B6DB0.toInt(), 0xFF5DB6F0.toInt(), 8), 8)
                    setPadding(0, dp(6), 0, dp(6))
                    setOnClickListener { startBoost(); text = "Boosting..." }
                }, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(4) })
            } else {
                card.background = frame(GT_TILE_TOP, GT_TILE_BOT, GT_BORDER, 13, bevel = 14, ticks = true)
                // header: "Performance" + small toggle (monitor on/off), like GameTurbo
                val sw = View(me)
                fun paintSw() {
                    sw.background = android.graphics.drawable.GradientDrawable().apply {
                        cornerRadius = dp(3).toFloat()
                        setColor(if (mon) 0xFF2E9BE8.toInt() else 0x33FFFFFF)
                        setStroke(dp(1), if (mon) 0xFF5DB6F0.toInt() else 0x66FFFFFF)
                    }
                }
                val thumb = View(me).apply {
                    background = android.graphics.drawable.GradientDrawable().apply { cornerRadius = dp(2).toFloat(); setColor(Color.WHITE) }
                }
                val swBox = android.widget.FrameLayout(me).apply {
                    addView(sw, android.widget.FrameLayout.LayoutParams(dp(24), dp(11)))
                    addView(thumb, android.widget.FrameLayout.LayoutParams(dp(9), dp(7)).apply {
                        topMargin = dp(2); leftMargin = if (mon) dp(13) else dp(2)
                    })
                    setOnClickListener {
                        mon = !mon; save(); applyExtras(); paintSw()
                        (thumb.layoutParams as android.widget.FrameLayout.LayoutParams).leftMargin = if (mon) dp(13) else dp(2)
                        thumb.requestLayout()
                    }
                }
                paintSw()
                card.addView(LinearLayout(me).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL or Gravity.END
                    addView(label("Performance", 10.5f, Color.WHITE, true))
                    addView(swBox, LinearLayout.LayoutParams(dp(24), dp(11)).apply { leftMargin = dp(6) })
                }, LinearLayout.LayoutParams(match, wrap))
                val cv = FpsChart(me, hist, BLUE, DIMT)
                chart = cv
                card.addView(cv, LinearLayout.LayoutParams(match, 0, 1f).apply { topMargin = dp(2) })
                val stats = LinearLayout(me).apply { orientation = LinearLayout.HORIZONTAL }
                val aT = label("", 9.5f, TXT, true); val bT = label("", 9.5f, DIMT, true)
                afterTv = aT; beforeTv = bT
                stats.addView(aT, LinearLayout.LayoutParams(0, wrap, 1f))
                stats.addView(bT, LinearLayout.LayoutParams(wrap, wrap))
                card.addView(stats, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(2) })
                card.addView(label("Stop", 11f, Color.WHITE, true).apply {
                    gravity = Gravity.CENTER
                    background = fripple(frame(0xFF2E9BE8.toInt(), 0xFF1B6DB0.toInt(), 0xFF5DB6F0.toInt(), 8), 8)
                    setPadding(0, dp(4), 0, dp(4))
                    setOnClickListener { stopBoost() }
                }, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(3) })
                onFps = {
                    afterTv?.text = "\u25CF ${fmt(fpsAfter())} FPS  After"
                    beforeTv?.text = "\u25CB ${fmt(fpsBefore)} FPS  Before"
                    (chart as? FpsChart)?.onNew() ?: chart?.invalidate()
                }
                onFps?.invoke()
            }
        }
        cardRender = { renderCard() }
        renderCard()
        top.addView(card, LinearLayout.LayoutParams(0, match, 1f).apply { leftMargin = dp(4) })
        col.addView(top, LinearLayout.LayoutParams(match, 0, 2.1f).apply { topMargin = dp(6) })

        // ---- tools strip (scrolls sideways) ----
        // exactly 4 tools fit the visible width (no half-cut tile); the rest scroll in and snap to a tile edge
        val toolSlot = (mainW - dp(20) - dp(2)) / 4
        val toolW = toolSlot - dp(2)
        var dragActive = false
        val tp = { LinearLayout.LayoutParams(toolW, match).apply { setMargins(dp(1), dp(1), dp(1), dp(1)) } }
        val strip2 = LinearLayout(me).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(2), dp(2), dp(2), dp(2)) }
        val tools = LinkedHashMap<String, LinearLayout>()
        fun reg(id: String, v: LinearLayout) { tools[id] = v }
        reg("shot", toolItem(R.drawable.ic_cut, "Screenshot", false) {
            hidePanel()
            ui.postDelayed({
                thread {
                    val r = Shell.run("mkdir -p /sdcard/Pictures/AeroBoost; screencap -p /sdcard/Pictures/AeroBoost/shot_${System.currentTimeMillis()}.png")
                    ui.post { toast(if (r == "OK") "Screenshot saved" else r) }
                }
            }, 400)
        })
        reg("rec", toolItem(R.drawable.ic_video, "Record", rec) { v ->
            rec = !rec; setOn(v, rec)
            if (rec) {
                recStart = System.currentTimeMillis()
                recView = v; recTv = v.getChildAt(1) as TextView
                recTv?.text = "00:00"
                ui.removeCallbacks(recTick); ui.post(recTick)
                hidePanel()
                thread {
                    val r = RecEngine.start(me)
                    ui.post { toast(r) }
                }
            } else {
                ui.removeCallbacks(recTick)
                (v.getChildAt(1) as TextView).text = "Record"
                act("Record stop") { RecEngine.stop() }
            }
        }.also { v ->
            if (rec) { recView = v; recTv = v.getChildAt(1) as TextView; ui.removeCallbacks(recTick); ui.post(recTick) }
        })
        reg("dnd", toolItem(R.drawable.ic_dnd, "DND", dnd) { v ->
            dnd = !dnd; setOn(v, dnd)
            act("DND " + if (dnd) "on" else "off") { Shell.run("cmd notification set_dnd " + if (dnd) "on" else "off") }
        })
        reg("xhair", toolItem(R.drawable.ic_crosshair, xhairName(), xhair > 0) { v ->
            showXhairPopup(v) {
                setOn(v, xhair > 0)
                (v.getChildAt(1) as TextView).text = xhairName()
                save(); applyCrosshair()
            }
        })
        reg("mon", toolItem(R.drawable.ic_chart, "Monitor", mon) { v ->
            mon = !mon; setOn(v, mon); save(); applyExtras()
        })
        reg("glock", toolItem(R.drawable.ic_lock, "Gesture lock", glock) { v ->
            glock = !glock; setOn(v, glock); save(); applyExtras()
            toast(if (glock) "Edge gestures blocked while in game" else "Edge gestures back to normal")
        })
        reg("awake", toolItem(R.drawable.ic_sun, "Awake", awake) { v ->
            awake = !awake; setOn(v, awake); save(); applyExtras()
            toast(if (awake) "Screen stays on, auto-brightness off" else "Screen and brightness back to normal")
        })
        reg("blk", toolItem(R.drawable.ic_bell_off, blkName(), blk > 0) { v ->
            blk = (blk + 1) % 3; setOn(v, blk > 0)
            (v.getChildAt(1) as TextView).text = blkName()
            save(); applyExtras()
        })
        reg("settings", toolItem(R.drawable.ic_gear, "Settings", false) {
            hidePanel()
            startActivity(Intent(me, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        })
        reg("fps", toolItem(R.drawable.ic_bolt, if (fps > 0) "FPS $fps" else "FPS", fps > 0) { v ->
            showFpsPopup(v) { n ->
                fps = n; setOn(v, n > 0)
                (v.getChildAt(1) as TextView).text = if (n > 0) "FPS $n" else "FPS"
                save()
                act(if (n > 0) "FPS $n" else "FPS auto") { Boost.refreshRate(n) }
            }
        })
        reg("mode", toolItem(R.drawable.ic_rocket, gameName(), false) { v ->
            gmode = gmode % 3 + 1
            (v.getChildAt(1) as TextView).text = gameName()
            act("Mode " + gameName()) { Boost.gameMode(currentGame(), gmode) }
        })

        // ---- saved order (long-press + drag to rearrange) ----
        val saved = (sp.getString("toolOrder", "") ?: "").split(",").filter { it in tools }
        val order = (saved + tools.keys.filter { it !in saved }).toMutableList()
        fun fillStrip() {
            strip2.removeAllViews()
            order.forEach { strip2.addView(tools[it]!!, tp()) }
        }
        fillStrip()

        val hsv = HorizontalScrollView(me).apply {
            isHorizontalScrollBarEnabled = false
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
            background = frame(GT_TILE_TOP, GT_TILE_BOT, GT_BORDER, 12)
            addView(strip2, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, match))
        }
        col.addView(hsv, LinearLayout.LayoutParams(match, 0, 0.9f).apply { topMargin = dp(6) })
        val snap = Runnable {
            if (!dragActive && toolSlot > 0) {
                val target = Math.round(hsv.scrollX / toolSlot.toFloat()) * toolSlot
                if (target != hsv.scrollX) hsv.smoothScrollTo(target, 0)
            }
        }
        hsv.setOnScrollChangeListener { _, _, _, _, _ -> ui.removeCallbacks(snap); ui.postDelayed(snap, 120) }

        // Long-press a tool, then slide it left/right to a new spot. The others make room; order is saved.
        fun attachDrag(v: LinearLayout) {
            var dragging = false
            var fromIdx = 0; var curIdx = 0
            var downRawX = 0f; var lastRawX = 0f; var downScroll = 0
            var slotW = 1f
            var origBg: android.graphics.drawable.Drawable? = null

            fun update() {
                val n = strip2.childCount
                val raw = (lastRawX - downRawX) + (hsv.scrollX - downScroll)
                val tx = raw.coerceIn(-fromIdx * slotW, (n - 1 - fromIdx) * slotW)
                v.translationX = tx
                val target = Math.round(fromIdx + tx / slotW).coerceIn(0, n - 1)
                if (target != curIdx) {
                    curIdx = target
                    for (j in 0 until n) {
                        if (j == fromIdx) continue
                        val d = when {
                            fromIdx < curIdx && j in (fromIdx + 1)..curIdx -> -slotW
                            fromIdx > curIdx && j in curIdx until fromIdx -> slotW
                            else -> 0f
                        }
                        strip2.getChildAt(j).animate().translationX(d).setDuration(130).start()
                    }
                }
            }

            val autoScroll = object : Runnable {
                override fun run() {
                    if (!dragging) return
                    val loc = IntArray(2); hsv.getLocationOnScreen(loc)
                    val x = lastRawX - loc[0]
                    val edge = dp(28)
                    val dx = when { x < edge -> -dp(5); x > hsv.width - edge -> dp(5); else -> 0 }
                    if (dx != 0) { hsv.scrollBy(dx, 0); update() }
                    ui.postDelayed(this, 16)
                }
            }

            fun drop() {
                dragging = false; dragActive = false
                ui.removeCallbacks(autoScroll)
                v.isPressed = false
                v.animate().translationX((curIdx - fromIdx) * slotW).scaleX(1f).scaleY(1f).alpha(1f)
                    .setDuration(130).withEndAction {
                        if (curIdx != fromIdx) {
                            val id = order.removeAt(fromIdx); order.add(curIdx, id)
                            sp.edit().putString("toolOrder", order.joinToString(",")).apply()
                        }
                        for (i in 0 until strip2.childCount) strip2.getChildAt(i).apply {
                            animate().cancel(); translationX = 0f; translationZ = 0f
                        }
                        v.background = origBg
                        fillStrip()
                    }.start()
            }

            v.setOnLongClickListener {
                val n = strip2.childCount
                if (n < 2) return@setOnLongClickListener true
                dragging = true; dragActive = true
                fromIdx = strip2.indexOfChild(v); curIdx = fromIdx
                slotW = (strip2.getChildAt(1).left - strip2.getChildAt(0).left).toFloat().coerceAtLeast(1f)
                downScroll = hsv.scrollX; downRawX = lastRawX
                hsv.requestDisallowInterceptTouchEvent(true)
                v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                origBg = v.background
                v.background = frame(0x55FFFFFF, 0x33FFFFFF, GT_BORDER, 9)
                v.translationZ = dp(12).toFloat()
                v.animate().scaleX(1.1f).scaleY(1.1f).alpha(0.95f).setDuration(120).start()
                ui.post(autoScroll)
                true
            }
            v.setOnTouchListener { _, e ->
                lastRawX = e.rawX
                if (!dragging) false else {
                    when (e.actionMasked) {
                        MotionEvent.ACTION_MOVE -> update()
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> drop()
                    }
                    true
                }
            }
        }
        tools.values.forEach { attachDrag(it) }

        // ---- bottom row: Timer ----
        val (timerTile, ttv) = wideTile(R.drawable.ic_hourglass, timerText(), true) {}
        timerTv = ttv
        timerTile.setOnClickListener {
            timerRunning = !timerRunning
            if (timerRunning) { timerStart = System.currentTimeMillis(); tick() }
            timerTv?.text = timerText()
        }
        if (timerRunning) tick()
        val bottom = LinearLayout(me).apply { orientation = LinearLayout.HORIZONTAL }
        fun appTile(res: Int, pkg: String, url: String) = LinearLayout(me).apply {
            gravity = Gravity.CENTER
            background = fripple(frame(GT_TILE_TOP, GT_TILE_BOT, GT_BORDER, 10), 10)
            addView(ImageView(me).apply { setImageResource(res) }, LinearLayout.LayoutParams(dp(26), dp(26)))
            setOnClickListener { launchFloatingWeb(pkg, url) }
        }
        val social = LinearLayout(me).apply { orientation = LinearLayout.HORIZONTAL }
        social.addView(appTile(R.drawable.ic_facebook, "com.facebook.katana", "https://m.facebook.com"), LinearLayout.LayoutParams(0, match, 1f))
        social.addView(appTile(R.drawable.ic_youtube, "com.google.android.youtube", "https://m.youtube.com"),
            LinearLayout.LayoutParams(0, match, 1f).apply { leftMargin = dp(6) })
        bottom.addView(social, LinearLayout.LayoutParams(0, match, 1f))
        bottom.addView(timerTile, LinearLayout.LayoutParams(0, match, 1f).apply { leftMargin = dp(6) })
        col.addView(bottom, LinearLayout.LayoutParams(match, 0, 0.75f).apply { topMargin = dp(6) })

        root.addView(mainSv, LinearLayout.LayoutParams(mainW, mainH).apply { leftMargin = gap })
        return root
    }

    // ---------- helpers ----------
    private fun timerText(): String {
        if (!timerRunning) return "Timer"
        val s = (System.currentTimeMillis() - timerStart) / 1000
        return "%02d:%02d".format(s / 60, s % 60)
    }

    private fun tick() {
        ui.removeCallbacks(tickRun)
        ui.postDelayed(tickRun, 1000)
    }

    private val tickRun = object : Runnable {
        override fun run() {
            if (!timerRunning) return
            timerTv?.text = timerText()
            ui.postDelayed(this, 1000)
        }
    }

    private fun launchNormal(p: String) {
        packageManager.getLaunchIntentForPackage(p)?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); runCatching { startActivity(it) }
        }
    }

    private fun settingOn(key: String) = runCatching {
        android.provider.Settings.Global.getInt(contentResolver, key, 0) == 1
    }.getOrDefault(false)

    /** Opens the app in a freeform (floating) window. If the two developer options are off, asks the user to enable them first. */
    private fun launchFloating(p: String) {
        val missing = mutableListOf<String>()
        if (!settingOn("enable_freeform_support")) missing += "Enable freeform windows"
        if (!settingOn("force_resizable_activities")) missing += "Force activities to be resizable"
        if (missing.isEmpty()) startFloating(p) else showFloatPrompt(p, missing)
    }

    /** Facebook / YouTube: our own floating web window (move: top bar, resize: bottom-right corner, close: drag to bottom). */
    private fun launchFloatingWeb(key: String, url: String) {
        hidePanel()
        FloatWeb.show(this, wm, key, url)
    }

    private fun startFloating(p: String) {
        hidePanel()
        val comp = packageManager.getLaunchIntentForPackage(p)?.component?.flattenToShortString()
        if (comp == null || !Shell.ready()) { launchNormal(p); return }
        thread {
            val r = Shell.run("am start --user 0 --windowingMode 5 -n ${AeroAccess.sq(comp)}")
            if (r.startsWith("Error") || r.startsWith("exit") || r.contains("Error type", true))
                ui.post { toast("Floating window not supported here, opening normally"); launchNormal(p) }
        }
    }

    // ---------- floating-app list (left strip of the panel) ----------
    private fun floatApps(): List<String> =
        (sp.getString("floatApps", "") ?: "").split(",").filter { it.isNotBlank() }

    private fun saveFloatApps(l: List<String>) { sp.edit().putString("floatApps", l.joinToString(",")).apply() }

    /** App list drawn inside the panel window: games first, then the other apps. Tap = add, tap again = remove. */
    private fun showAppPicker(onChange: () -> Unit) {
        val s = scrim ?: return
        val me = this
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        var host: FrameLayout? = null
        val close = { host?.let { runCatching { s.removeView(it) } }; host = null }
        val list = LinearLayout(me).apply { orientation = LinearLayout.VERTICAL }
        val card = LinearLayout(me).apply {
            orientation = LinearLayout.VERTICAL
            background = frame(GT_PANEL_TOP, GT_PANEL_BOT, GT_BORDER, 14)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            isClickable = true
            addView(label("Add app", 13f, TXT, true))
            addView(label("Opens in a floating window. Tap again to remove.", 10f, DIMT).apply { setPadding(0, dp(2), 0, dp(6)) })
        }
        val maxH = (resources.displayMetrics.heightPixels * 0.6f).toInt().coerceAtMost(dp(440))
        card.addView(ScrollView(me).apply { addView(list) }, LinearLayout.LayoutParams(match, maxH))
        card.addView(label("Close", 11f, TXT, true).apply {
            gravity = Gravity.CENTER
            background = frame(Color.TRANSPARENT, Color.TRANSPARENT, GT_BORDER, 8)
            setPadding(0, dp(8), 0, dp(8))
            setOnClickListener { close() }
        }, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(8) })
        val root = FrameLayout(me).apply {
            setBackgroundColor(0x88000000.toInt())
            isClickable = true
            setOnClickListener { close() }
            addView(card, FrameLayout.LayoutParams(dp(290), wrap, Gravity.CENTER))
        }
        host = root
        s.addView(root, FrameLayout.LayoutParams(match, match))

        thread {
            val pm = packageManager
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            class Item(val label: String, val pkg: String, val isGame: Boolean)
            val items = runCatching {
                pm.queryIntentActivities(i, 0)
                    .distinctBy { it.activityInfo.packageName }
                    .filter { it.activityInfo.packageName != packageName }
                    .map { r ->
                        val ai = r.activityInfo.applicationInfo
                        @Suppress("DEPRECATION")
                        val game = ai.category == android.content.pm.ApplicationInfo.CATEGORY_GAME ||
                            (ai.flags and android.content.pm.ApplicationInfo.FLAG_IS_GAME) != 0
                        Item(r.loadLabel(pm).toString(), r.activityInfo.packageName, game)
                    }
                    .sortedWith(compareByDescending<Item> { it.isGame }.thenBy { it.label.lowercase() })
            }.getOrDefault(emptyList())
            ui.post {
                if (host == null) return@post
                var shown = ""
                items.forEach { it0 ->
                    val head = if (it0.isGame) "GAMES" else "APPS"
                    if (head != shown) {
                        shown = head
                        list.addView(label(head, 10f, BLUE, true).apply { setPadding(0, dp(6), 0, dp(4)) })
                    }
                    val mark = label("", 14f, BLUE, true)
                    fun refresh() { mark.text = if (floatApps().contains(it0.pkg)) "\u2713" else "" }
                    refresh()
                    val row = LinearLayout(me).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        setPadding(dp(4), dp(5), dp(4), dp(5))
                        addView(ImageView(me).apply {
                            runCatching { setImageDrawable(pm.getApplicationIcon(it0.pkg)) }
                        }, LinearLayout.LayoutParams(dp(34), dp(34)))
                        addView(label(it0.label, 12f, TXT).apply {
                            maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
                        }, LinearLayout.LayoutParams(0, wrap, 1f).apply { leftMargin = dp(10) })
                        addView(mark, LinearLayout.LayoutParams(dp(24), wrap))
                        setOnClickListener {
                            val cur = floatApps()
                            saveFloatApps(if (cur.contains(it0.pkg)) cur - it0.pkg else cur + it0.pkg)
                            refresh(); onChange()
                        }
                    }
                    list.addView(row, LinearLayout.LayoutParams(match, wrap))
                }
            }
        }
    }

    private fun showFloatPrompt(p: String, missing: List<String>) {
        var v: FrameLayout? = null
        val close = { v?.let { runCatching { wm.removeView(it) } }; v = null }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = frame(GT_PANEL_TOP, GT_PANEL_BOT, GT_BORDER, 14)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            isClickable = true
            addView(label("Turn on in Developer options", 13f, TXT, true))
            addView(label(missing.joinToString("\n") { "•  $it" }, 12f, BLUE).apply { setPadding(0, dp(8), 0, dp(4)) })
            addView(label("Floating windows need both switched on.", 10f, DIMT))
            val row = LinearLayout(this@OverlayService).apply { orientation = LinearLayout.HORIZONTAL }
            fun btn(t: String, fill: Boolean, c: () -> Unit) = label(t, 11f, if (fill) Color.WHITE else TXT, true).apply {
                gravity = Gravity.CENTER
                background = if (fill) frame(0xFF2E9BE8.toInt(), 0xFF1B6DB0.toInt(), 0xFF5DB6F0.toInt(), 8) else frame(Color.TRANSPARENT, Color.TRANSPARENT, GT_BORDER, 8)
                setPadding(0, dp(8), 0, dp(8))
                setOnClickListener { c() }
            }
            row.addView(btn("Open settings", true) {
                close()
                hidePanel()
                runCatching {
                    startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }.onFailure { toast("Open Settings > Developer options") }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(btn("Try anyway", false) {
                close()
                thread {
                    SettingsBackup.save(Keys.FREEFORM)
                    Shell.run("settings put global enable_freeform_support 1; settings put global force_resizable_activities 1")
                    ui.post { startFloating(p) }
                }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(8) })
            addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) })
        }
        val root = FrameLayout(this).apply {
            setBackgroundColor(0x88000000.toInt())
            setOnClickListener { close() }
            addView(card, FrameLayout.LayoutParams(dp(280), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        }
        v = root
        wm.addView(
            root,
            WindowManager.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
        )
    }

    /** Small floating chooser above the FPS tool: 30 / 60 / 90 / 120. */
    private fun showFpsPopup(anchor: View, onPick: (Int) -> Unit) {
        fpsPop?.dismiss()
        lateinit var pw: PopupWindow
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = frame(GT_PANEL_TOP, GT_PANEL_BOT, GT_BORDER, 12)
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }
        val rates = Boost.supportedRates(this).ifEmpty { listOf(60, 90, 120) }
        (listOf(0) + rates).forEachIndexed { i, n ->
            val sel = n == fps
            content.addView(label(if (n == 0) "AUTO" else n.toString(), 12f, if (sel) BLUE else TXT, true).apply {
                gravity = Gravity.CENTER
                background = frame(if (sel) 0x2645E98A else 0x22FFFFFF, if (sel) 0x2645E98A else 0x22FFFFFF, if (sel) 0xCC39FF88.toInt() else GT_BORDER, 8)
                setPadding(dp(12), dp(8), dp(12), dp(8))
                setOnClickListener { pw.dismiss(); onPick(n) }
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { if (i > 0) leftMargin = dp(6) })
        }
        content.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        pw = PopupWindow(content, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, false).apply {
            isOutsideTouchable = true
            setBackgroundDrawable(ColorDrawable(0))
            elevation = dp(8).toFloat()
        }
        fpsPop = pw
        pw.showAsDropDown(anchor, (anchor.width - content.measuredWidth) / 2, -(anchor.height + content.measuredHeight + dp(4)))
    }

    /** Style row (Off / Dot / Cross / Circle) and colour row; the popup stays open so the change can be seen at once. */
    private fun showXhairPopup(anchor: View, onChange: () -> Unit) {
        fpsPop?.dismiss()
        lateinit var pw: PopupWindow
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = frame(GT_PANEL_TOP, GT_PANEL_BOT, GT_BORDER, 14)
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val styles = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Off", "Dot", "Cross", "Circle").forEachIndexed { i, n ->
            val sel = i == xhair
            styles.addView(label(n, 12f, if (sel) BLUE else TXT, true).apply {
                gravity = Gravity.CENTER
                background = frame(if (sel) 0x2645E98A else 0x22FFFFFF, if (sel) 0x2645E98A else 0x22FFFFFF, if (sel) 0xCC39FF88.toInt() else GT_BORDER, 8)
                setPadding(dp(12), dp(8), dp(12), dp(8))
                setOnClickListener { xhair = i; onChange(); pw.dismiss(); showXhairPopup(anchor, onChange) }
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { if (i > 0) leftMargin = dp(6) })
        }
        content.addView(styles)
        val colors = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        XCOLORS.forEachIndexed { i, c ->
            val sel = i == xcol
            colors.addView(View(this).apply {
                background = box(c, 16, if (sel) Color.WHITE else 0x55FFFFFF)
                setOnClickListener {
                    xcol = i
                    if (xhair == 0) xhair = 2   // picking a colour while Off turns the crosshair on
                    onChange(); pw.dismiss(); showXhairPopup(anchor, onChange)
                }
            }, LinearLayout.LayoutParams(dp(30), dp(30)).apply { leftMargin = dp(if (i > 0) 8 else 0) })
        }
        content.addView(colors, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) })
        content.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        pw = PopupWindow(content, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, false).apply {
            isOutsideTouchable = true
            setBackgroundDrawable(ColorDrawable(0))
            elevation = dp(8).toFloat()
        }
        fpsPop = pw
        pw.showAsDropDown(anchor, (anchor.width - content.measuredWidth) / 2, -(anchor.height + content.measuredHeight + dp(4)))
    }

    private fun xhairName() = when (xhair) { 1 -> "Dot"; 2 -> "Cross"; 3 -> "Circle"; else -> "Crosshair" }

    /** Draws a centred, touch-through crosshair above the game. Only shown while the edge tabs are (i.e. inside a selected game). */
    private fun applyCrosshair() {
        xhairView?.let { runCatching { wm.removeView(it) } }
        xhairView = null
        if (xhair == 0 || !handlesShown) return
        val d = resources.displayMetrics.density
        val kind = xhair
        val col = XCOLORS[xcol]
        val v = object : View(this) {
            private val line = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                style = android.graphics.Paint.Style.STROKE; strokeCap = android.graphics.Paint.Cap.ROUND
            }
            private val fill = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
            override fun onDraw(c: android.graphics.Canvas) {
                val cx = width / 2f; val cy = height / 2f
                fun stroke(color: Int, w: Float) { line.color = color; line.strokeWidth = w }
                val dark = 0xAA000000.toInt(); val main = col
                when (kind) {
                    1 -> {
                        fill.color = dark; c.drawCircle(cx, cy, 3.6f * d, fill)
                        fill.color = main; c.drawCircle(cx, cy, 2.4f * d, fill)
                    }
                    2 -> for ((col, w) in listOf(dark to 3.4f * d, main to 1.8f * d)) {
                        stroke(col, w)
                        c.drawLine(cx - 11 * d, cy, cx - 3 * d, cy, line); c.drawLine(cx + 3 * d, cy, cx + 11 * d, cy, line)
                        c.drawLine(cx, cy - 11 * d, cx, cy - 3 * d, line); c.drawLine(cx, cy + 3 * d, cx, cy + 11 * d, line)
                    }
                    else -> {
                        stroke(dark, 3.4f * d); c.drawCircle(cx, cy, 9 * d, line)
                        stroke(main, 1.8f * d); c.drawCircle(cx, cy, 9 * d, line)
                        fill.color = dark; c.drawCircle(cx, cy, 2.9f * d, fill)
                        fill.color = main; c.drawCircle(cx, cy, 1.8f * d, fill)
                    }
                }
            }
        }
        val lp = WindowManager.LayoutParams(
            dp(40), dp(40),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        runCatching { wm.addView(v, lp); xhairView = v }
    }

    private fun blkName() = when (blk) { 1 -> "No popup"; 2 -> "No calls"; else -> "Block" }

    /** Rejects a ringing call (needs AeroHUB shell). Only runs while the game is on screen and "No calls" is chosen. */
    private fun rejectRingingCall() {
        val r = Shell.run("dumpsys telephony.registry | grep -m1 mCallState")
        if (r.contains("mCallState=1")) Shell.run("input keyevent KEYCODE_ENDCALL")
    }

    /** Applies monitor / gesture lock / awake / block to the current state (in game = on, outside = off). */
    private fun applyExtras() {
        applyMonitor(); applyGuard(); applyAwake()
        val inGame = handlesShown
        val g = glock && inGame; val a = awake && inGame; val b = blk > 0 && inGame
        thread {
            synchronized(syncLock) {
                if (g) {
                    SettingsBackup.save(Keys.GESTURE)
                    Shell.run("settings put secure back_gesture_inset_scale_left 0; settings put secure back_gesture_inset_scale_right 0")
                } else SettingsBackup.restore(Keys.GESTURE)
                if (a) { SettingsBackup.save(Keys.BRIGHT); Shell.run("settings put system screen_brightness_mode 0") }
                else SettingsBackup.restore(Keys.BRIGHT)
                if (b) { SettingsBackup.save(Keys.NOTIF); Shell.run("settings put global heads_up_notifications_enabled 0") }
                else SettingsBackup.restore(Keys.NOTIF)
            }
        }
    }

    private fun overlayLp(w: Int, h: Int, flags: Int, grav: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = grav }

    /** Thin strip along the top edge that swallows touches so a pull-down from the very edge does not open the shade. Best effort. */
    private fun applyGuard() {
        guardView?.let { runCatching { wm.removeView(it) } }; guardView = null
        if (!glock || !handlesShown) return
        val v = View(this).apply { setOnTouchListener { _, _ -> true } }
        val lp = overlayLp(ViewGroup.LayoutParams.MATCH_PARENT, dp(10), 0, Gravity.TOP)
        runCatching { wm.addView(v, lp); guardView = v }
    }

    /** 1px invisible window that keeps the screen on while the game is in front. */
    private fun applyAwake() {
        awakeView?.let { runCatching { wm.removeView(it) } }; awakeView = null
        if (!awake || !handlesShown) return
        val v = View(this).apply { keepScreenOn = true }
        val lp = overlayLp(1, 1, WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, Gravity.TOP or Gravity.START)
        runCatching { wm.addView(v, lp); awakeView = v }
    }

    /** Small, touch-through readout: CPU %, RAM free, battery % and temperature, ping. Refreshes about every 2 s. */
    private fun applyMonitor() {
        monGen2++
        monView?.let { runCatching { wm.removeView(it) } }; monView = null
        if (!mon || !handlesShown) return
        val g = monGen2
        val tv = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 10f; typeface = Typeface.MONOSPACE
            setShadowLayer(dp(3).toFloat(), 0f, 0f, Color.BLACK)
            background = box(0x99000000.toInt(), dp(6))
            setPadding(dp(6), dp(3), dp(6), dp(3)); text = "CPU -- | RAM -- | BAT -- | PING --"
        }
        val lp = overlayLp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, Gravity.TOP or Gravity.START).apply { x = dp(60); y = dp(4) }
        if (runCatching { wm.addView(tv, lp) }.isFailure) return
        monView = tv
        lastCpu = null
        thread(isDaemon = true) {
            while (monGen2 == g) {
                val out = Shell.run(
                    "head -1 /proc/stat; dumpsys battery | grep -E 'level|temperature'; " +
                    "grep -E 'MemTotal|MemAvailable' /proc/meminfo; ping -c 1 -W 1 8.8.8.8 | grep -o 'time=[0-9.]*'; true"
                ).replace(Regex("^exit \\d+: "), "")
                val txt = parseMon(out)
                ui.post { if (monGen2 == g) tv.text = txt }
                try { Thread.sleep(1500) } catch (_: InterruptedException) {}
            }
        }
    }

    private fun parseMon(out: String): String {
        val lines = out.lines().map { it.trim() }
        var cpu = "--"; var ram = "--"; var bat = "--"; var ping = "--"
        lines.firstOrNull { it.startsWith("cpu") }?.let { l ->
            val n = l.split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
            if (n.size >= 5) {
                val total = n.sum(); val idle = n[3] + n[4]
                lastCpu?.let { p -> val dt = total - p[0]; if (dt > 0) cpu = "${((dt - (idle - p[1])) * 100 / dt).coerceIn(0, 100)}%" }
                lastCpu = longArrayOf(total, idle)
            }
        }
        val tot = lines.firstOrNull { it.startsWith("MemTotal") }?.filter { it.isDigit() }?.toLongOrNull()
        val av = lines.firstOrNull { it.startsWith("MemAvailable") }?.filter { it.isDigit() }?.toLongOrNull()
        if (tot != null && av != null) ram = "%.1fG".format(av / 1048576f)
        val lvl = lines.firstOrNull { it.startsWith("level") }?.filter { it.isDigit() }
        val tmp = lines.firstOrNull { it.startsWith("temperature") }?.filter { it.isDigit() }?.toIntOrNull()
        if (!lvl.isNullOrEmpty()) bat = lvl + "%" + if (tmp != null) " " + "%.1f".format(tmp / 10f) + "C" else ""
        lines.firstOrNull { it.startsWith("time=") }?.removePrefix("time=")?.toFloatOrNull()?.let { ping = "${it.toInt()}ms" }
        return "CPU $cpu | RAM $ram free | BAT $bat | PING $ping"
    }

    private fun toast(t: String) = Toast.makeText(this, t.take(200), Toast.LENGTH_LONG).show()

    private fun act(name: String, f: () -> String) {
        toast("$name...")
        thread {
            val r = try { f() } catch (e: Throwable) { "Error: ${e.message}" }
            ui.post { toast("$name: $r") }
        }
    }

    private fun currentGame(): String {
        val r = Shell.run("dumpsys activity activities | grep -m1 -E 'topResumedActivity|mResumedActivity'")
        val p = Regex("([a-zA-Z][a-zA-Z0-9_]*(?:\\.[a-zA-Z0-9_]+)+)/").find(r)?.groupValues?.get(1)
        if (p != null && p != packageName && !p.startsWith("com.android.systemui")) return p
        return getSharedPreferences("games", MODE_PRIVATE).getString("sel", "") ?: ""
    }
}


/** Small line/area chart of the last ~60 FPS samples (0 to 120 FPS, grows if the game goes above 120). */
class FpsChart(c: android.content.Context, private val data: List<Int>, private val col: Int, private val dim: Int) : View(c) {
    private val line = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        style = android.graphics.Paint.Style.STROKE; strokeWidth = 2f * resources.displayMetrics.density; color = col
        strokeJoin = android.graphics.Paint.Join.ROUND
    }
    private val fill = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    private val grid = android.graphics.Paint().apply { color = 0x22FFFFFF; strokeWidth = 1f }
    private val txt = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = dim; textSize = 8f * resources.displayMetrics.scaledDensity
    }

    override fun onDraw(cv: android.graphics.Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val left = txt.measureText("120") + 6f
        val d = synchronized(data) { data.toList() }
        val mx = d.maxOrNull() ?: 0
        val top = if (mx > 120) 240 else if (mx > 60) 120 else 60
        fun y(v: Int) = h - (v.coerceIn(0, top) / top.toFloat()) * (h - 2f) - 1f
        for (v in listOf(0, top / 2, top)) {
            cv.drawLine(left, y(v), w, y(v), grid)
            cv.drawText(v.toString(), 0f, y(v) + txt.textSize / 3f, txt)
        }
        if (d.size < 2) return
        val step = (w - left) / 59f
        // smooth animation: newest segment grows out of the previous point; when full the line slides left
        val t = ((android.os.SystemClock.uptimeMillis() - animStart) / 400f).coerceIn(0f, 1f)
        val e = 1f - (1f - t) * (1f - t)
        val slide = if (d.size >= 60 && prevSize >= 60) (1f - e) * step else 0f
        val path = android.graphics.Path()
        val area = android.graphics.Path()
        val last = d.size - 1
        var lastX = left
        d.forEachIndexed { i, v ->
            var x = left + i * step + slide
            var yy = y(v)
            if (i == last && last >= 1 && t < 1f) {
                val px = left + (i - 1) * step + slide
                val py = y(d[i - 1])
                x = px + (x - px) * e; yy = py + (yy - py) * e
            }
            if (i == 0) { path.moveTo(x, yy); area.moveTo(x, h); area.lineTo(x, yy) } else { path.lineTo(x, yy); area.lineTo(x, yy) }
            lastX = x
        }
        area.lineTo(lastX, h); area.close()
        cv.save(); cv.clipRect(left, 0f, w, h)
        fill.shader = android.graphics.LinearGradient(0f, 0f, 0f, h, (col and 0x00FFFFFF) or 0x99000000.toInt(), 0x00000000, android.graphics.Shader.TileMode.CLAMP)
        cv.drawPath(area, fill)
        cv.drawPath(path, line)
        cv.restore()
        if (t < 1f) postInvalidateOnAnimation()
    }

    private var animStart = 0L
    private var prevSize = 0
    private var seen = 0

    /** Call after a new sample was added. */
    fun onNew() {
        val n = synchronized(data) { data.size }
        prevSize = if (n == 0) 0 else seen
        seen = n
        animStart = android.os.SystemClock.uptimeMillis()
        invalidate()
    }
}


/** Neon panel with two cut corners (top-left, bottom-right) and a soft glow outline. */
class Chamfer(
    private val c1: Int, private val c2: Int, private val strokeCol: Int,
    private val cut: Float, private val d: Float
) : android.graphics.drawable.Drawable() {
    private val fillP = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    private val lineP = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { style = android.graphics.Paint.Style.STROKE }
    private val path = android.graphics.Path()

    override fun onBoundsChange(b: android.graphics.Rect) {
        val i = d * 0.75f
        val l = b.left + i; val t = b.top + i; val r = b.right - i; val bt = b.bottom - i
        val k = minOf(cut, (r - l) / 2.2f, (bt - t) / 2.2f)
        path.reset()
        path.moveTo(l + k, t); path.lineTo(r, t); path.lineTo(r, bt - k)
        path.lineTo(r - k, bt); path.lineTo(l, bt); path.lineTo(l, t + k); path.close()
        fillP.shader = if (c1 != c2) android.graphics.LinearGradient(
            b.left.toFloat(), b.top.toFloat(), b.right.toFloat(), b.bottom.toFloat(), c1, c2, android.graphics.Shader.TileMode.CLAMP
        ) else null
    }

    override fun draw(cv: android.graphics.Canvas) {
        fillP.color = c1
        cv.drawPath(path, fillP)
        if (strokeCol != 0) {
            lineP.color = (strokeCol and 0x00FFFFFF) or 0x22000000; lineP.strokeWidth = d * 3.5f   // glow
            cv.drawPath(path, lineP)
            lineP.color = strokeCol; lineP.strokeWidth = d * 1.2f
            cv.drawPath(path, lineP)
        }
    }

    override fun setAlpha(a: Int) { fillP.alpha = a; lineP.alpha = a }
    override fun setColorFilter(f: android.graphics.ColorFilter?) { fillP.colorFilter = f; lineP.colorFilter = f }
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity() = android.graphics.PixelFormat.TRANSLUCENT
}


/**
 * GameTurbo-style frame: dark vertical gradient, thin light border, rounded corners,
 * optional bevelled top-left corner, small bottom-right notch and dashed top ticks.
 */
class TurboFrame(
    private val top: Int, private val bottom: Int, private val strokeCol: Int,
    private val radius: Float, private val d: Float,
    private val bevel: Float = 0f, private val notch: Float = 0f, private val ticks: Boolean = false,
    private val strokeW: Float = 1.2f
) : android.graphics.drawable.Drawable() {
    private val fillP = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    private val lineP = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { style = android.graphics.Paint.Style.STROKE }
    private val tickP = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { style = android.graphics.Paint.Style.STROKE }
    private val notchP = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    private val path = android.graphics.Path()
    private val notchPath = android.graphics.Path()
    private val tickPath = android.graphics.Path()

    override fun onBoundsChange(b: android.graphics.Rect) {
        val i = d * strokeW / 2f + 0.5f
        val l = b.left + i; val t = b.top + i; val r = b.right - i; val bt = b.bottom - i
        val rad = minOf(radius, (r - l) / 2.5f, (bt - t) / 2.5f)
        val bv = minOf(bevel, (r - l) / 2.5f, (bt - t) / 2.5f)
        path.reset()
        path.moveTo(l + bv, t)
        path.lineTo(r - rad, t); path.quadTo(r, t, r, t + rad)
        path.lineTo(r, bt - rad); path.quadTo(r, bt, r - rad, bt)
        path.lineTo(l + rad, bt); path.quadTo(l, bt, l, bt - rad)
        if (bv > 0f) path.lineTo(l, t + bv) else { path.lineTo(l, t + rad); path.quadTo(l, t, l + rad, t) }
        path.close()
        fillP.shader = android.graphics.LinearGradient(0f, b.top.toFloat(), 0f, b.bottom.toFloat(), top, bottom, android.graphics.Shader.TileMode.CLAMP)
        notchPath.reset()
        if (notch > 0f) {
            val n = notch
            notchPath.moveTo(r - n, bt - d); notchPath.lineTo(r - d, bt - n); notchPath.lineTo(r - d, bt - d); notchPath.close()
        }
        tickPath.reset()
        if (ticks) {
            val y = t + d * 3.5f
            tickPath.moveTo(l + bv + d * 10f, y); tickPath.lineTo(r - rad, y)
        }
    }

    override fun draw(cv: android.graphics.Canvas) {
        cv.drawPath(path, fillP)
        if (ticks) {
            tickP.color = (strokeCol and 0x00FFFFFF) or 0x66000000
            tickP.strokeWidth = d * 2f
            tickP.pathEffect = android.graphics.DashPathEffect(floatArrayOf(d * 2.5f, d * 2f), 0f)
            cv.drawPath(tickPath, tickP)
        }
        if (strokeCol != 0) {
            lineP.color = strokeCol; lineP.strokeWidth = d * strokeW
            cv.drawPath(path, lineP)
        }
        if (notch > 0f) { notchP.color = if (strokeCol != 0) strokeCol else 0xFFB4BCCB.toInt(); cv.drawPath(notchPath, notchP) }
    }

    override fun setAlpha(a: Int) { fillP.alpha = a; lineP.alpha = a; notchP.alpha = a; tickP.alpha = a }
    override fun setColorFilter(f: android.graphics.ColorFilter?) { fillP.colorFilter = f; lineP.colorFilter = f }
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity() = android.graphics.PixelFormat.TRANSLUCENT
}
