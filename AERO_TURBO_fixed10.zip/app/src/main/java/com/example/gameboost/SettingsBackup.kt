package com.example.gameboost

import android.content.Context
import android.content.SharedPreferences
import android.hardware.display.DisplayManager
import android.os.Handler
import android.os.Looper
import android.view.Display
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.concurrent.thread

/** One phone setting this app may change: namespace (system / secure / global) and name. */
class Key(val ns: String, val name: String) { val id get() = "$ns:$name" }

object Keys {
    val REFRESH = listOf(Key("system", "min_refresh_rate"), Key("system", "peak_refresh_rate"))
    val ANIM = listOf(
        Key("global", "window_animation_scale"),
        Key("global", "transition_animation_scale"),
        Key("global", "animator_duration_scale")
    )
    val TOUCH = listOf(Key("secure", "long_press_timeout"), Key("secure", "multi_press_timeout"), Key("system", "high_touch_sensitivity_enable"))
    val FREEFORM = listOf(Key("global", "enable_freeform_support"), Key("global", "force_resizable_activities"))
    val GESTURE = listOf(Key("secure", "back_gesture_inset_scale_left"), Key("secure", "back_gesture_inset_scale_right"))
    val BRIGHT = listOf(Key("system", "screen_brightness_mode"))
    val NOTIF = listOf(Key("global", "heads_up_notifications_enabled"))
    val ALL = REFRESH + ANIM + TOUCH + FREEFORM + GESTURE + BRIGHT + NOTIF
}

/**
 * Remembers the phone's ORIGINAL value of every setting before the app first changes it,
 * so it can be put back exactly (including "was not set at all" -> delete).
 * An existing snapshot is never overwritten, so repeated changes keep the true original.
 * All functions talk to AeroHUB: call from a background thread.
 */
object SettingsBackup {
    private const val UNSET = "@@unset@@"
    private const val GAME = "@@game@@"

    private fun prefs(): SharedPreferences? =
        AeroAccess.context()?.getSharedPreferences("backup", Context.MODE_PRIVATE)

    /** null = could not read; UNSET = setting does not exist. */
    private fun read(k: Key): String? {
        val (code, out) = try { AeroAccess.run("settings get ${k.ns} ${k.name}") } catch (_: Throwable) { return null }
        val t = out.trim()
        return when {
            code != 0 -> null
            t.isEmpty() || t == "null" -> UNSET
            else -> t
        }
    }

    fun has(keys: List<Key> = Keys.ALL): Boolean = prefs()?.let { p -> keys.any { p.contains(it.id) } } ?: false

    /** Saves the current value of each key that has no snapshot yet. Returns false if something could not be read. */
    @Synchronized fun save(keys: List<Key>): Boolean {
        val p = prefs() ?: return false
        val e = p.edit()
        var ok = true
        for (k in keys) {
            if (p.contains(k.id)) continue
            val v = read(k)
            if (v == null) ok = false else e.putString(k.id, v)
        }
        e.commit()
        return ok
    }

    /** Puts the saved originals back. Only keys that have a snapshot are touched. */
    @Synchronized fun restore(keys: List<Key> = Keys.ALL): String {
        val p = prefs() ?: return "nothing to restore"
        val todo = keys.filter { p.contains(it.id) }
        if (todo.isEmpty()) return "nothing to restore"
        val cmd = todo.joinToString("; ") { k ->
            val v = p.getString(k.id, UNSET) ?: UNSET
            if (v == UNSET) "settings delete ${k.ns} ${k.name}"
            else "settings put ${k.ns} ${k.name} ${AeroAccess.sq(v)}"
        }
        val r = Shell.run(cmd)
        if (r.startsWith("exit ") || r.startsWith("Error:")) return "restore failed: $r"   // keep the snapshot, try again later
        val e = p.edit()
        todo.forEach { e.remove(it.id) }
        e.commit()
        return "restored ${todo.size} settings"
    }

    fun setGame(pkg: String) { prefs()?.edit()?.putString(GAME, pkg)?.commit() }
    fun game(): String = prefs()?.getString(GAME, "") ?: ""
}

/**
 * Watches the boosted game. When its process is gone (or never started within a minute),
 * the phone settings are restored automatically and listeners are told on the main thread.
 */
object GameWatch {
    @Volatile private var gen = 0
    @Volatile var active = false; private set
    private val main = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArrayList<() -> Unit>()

    fun addListener(f: () -> Unit) { listeners.add(f) }
    fun removeListener(f: () -> Unit) { listeners.remove(f) }

    /** true = running, false = gone, null = unknown (AeroHUB not reachable). */
    private fun alive(pkg: String): Boolean? = try {
        val (code, out) = AeroAccess.run("pidof ${AeroAccess.sq(pkg)}")
        code == 0 && out.isNotBlank()
    } catch (_: Throwable) { null }

    fun start(pkg: String) {
        if (pkg.isBlank()) return
        SettingsBackup.setGame(pkg)
        val g = ++gen
        active = true
        thread(isDaemon = true) {
            var seen = false
            var misses = 0
            val t0 = System.currentTimeMillis()
            while (gen == g) {
                try { Thread.sleep(5000) } catch (_: InterruptedException) {}
                if (gen != g) return@thread
                val a = alive(pkg) ?: continue
                if (a) { seen = true; misses = 0 }
                else if (seen || System.currentTimeMillis() - t0 > 60_000) { if (++misses >= 2) break }
            }
            if (gen != g) return@thread
            SettingsBackup.restore()
            SettingsBackup.setGame("")
            active = false
            main.post { listeners.forEach { it() } }
        }
    }

    /** Stops watching (no restore). */
    fun stop() { gen++; active = false; SettingsBackup.setGame("") }

    /** After the app/service was killed: keep watching the last boosted game so settings still get restored. */
    fun resume() {
        if (active) return
        val g = SettingsBackup.game()
        if (g.isNotBlank() && SettingsBackup.has()) start(g)
    }
}
