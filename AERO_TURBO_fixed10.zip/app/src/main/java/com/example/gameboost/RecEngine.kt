package com.example.gameboost

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Point
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.os.Build
import android.view.WindowManager
import androidx.core.content.ContextCompat
import java.io.File
import java.nio.ByteBuffer
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/**
 * Lightweight screen-record engine.
 * Uses the system screenrecord tool with a reduced resolution, a capped frame rate and a low
 * bitrate, and runs at low CPU priority so the game keeps its FPS while recording.
 * Values come from Settings > Recording (prefs "games": recFps, recMbps, recRes, recAudio).
 *
 * Audio = Mic: screenrecord cannot capture sound, so the microphone is recorded separately
 * (MediaRecorder, inside a microphone foreground service) and, when recording stops, joined with
 * the video into one mp4 (MediaExtractor + MediaMuxer, no re-encoding).
 */
object RecEngine {
    val FPS = listOf(15, 24, 30, 60)
    val MBPS = listOf(2, 4, 8, 12)
    val RES = listOf(50, 75, 100)          // % of the screen size
    val AUDIO = listOf("Off", "Mic")

    const val D_FPS = 30
    const val D_MBPS = 4
    const val D_RES = 75
    private const val MAX_SEC = 180
    private const val OUT_DIR = "/sdcard/Movies/AeroBoost"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("games", Context.MODE_PRIVATE)

    fun fps(ctx: Context) = prefs(ctx).getInt("recFps", D_FPS)
    fun mbps(ctx: Context) = prefs(ctx).getInt("recMbps", D_MBPS)
    fun res(ctx: Context) = prefs(ctx).getInt("recRes", D_RES)
    fun audio(ctx: Context) = prefs(ctx).getInt("recAudio", 1).coerceIn(0, AUDIO.lastIndex)

    fun hasMic(ctx: Context) =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    @Suppress("DEPRECATION")
    private fun size(ctx: Context, pct: Int): String? {
        if (pct >= 100) return null
        val p = Point()
        (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealSize(p)
        if (p.x <= 0 || p.y <= 0) return null
        val w = (p.x * pct / 100) / 2 * 2      // encoders need even sizes
        val h = (p.y * pct / 100) / 2 * 2
        return "${w}x$h"
    }

    // ---- microphone session ----
    private class Session(val video: String, val audio: String, val mr: MediaRecorder?, val app: Context)
    private val lock = Any()
    private var session: Session? = null
    @Volatile private var micUp: CountDownLatch? = null

    @Suppress("DEPRECATION")
    private fun legacyRecorder() = MediaRecorder()

    /** Called by MicRecService once it is in the foreground. */
    fun serviceUp() { micUp?.countDown() }

    private fun startScreen(ctx: Context, out: String): String {
        val common = StringBuilder("--bit-rate ${mbps(ctx) * 1_000_000} --time-limit $MAX_SEC")
        size(ctx, res(ctx))?.let { common.append(" --size $it") }
        // 1st try: low priority + frame-rate cap (needs a newer screenrecord);
        // 2nd try: same without the cap, for phones whose screenrecord has no --max-fps
        val a = "nice -n 10 screenrecord --max-fps ${fps(ctx)} $common $out"
        val b = "screenrecord $common $out"
        return Shell.run("nohup sh -c '$a || $b' >/dev/null 2>&1 &")
    }

    /** Starts recording in the background (max 3 min). Call from a worker thread. */
    fun start(ctx: Context): String {
        val app = ctx.applicationContext
        val wantMic = audio(app) == 1
        val dir = app.getExternalFilesDir(null)?.let { File(it, "rec").apply { mkdirs() } }
        if (!wantMic || !hasMic(app) || dir == null || !dir.isDirectory) {
            Shell.run("mkdir -p $OUT_DIR")
            startScreen(app, "$OUT_DIR/rec_${System.currentTimeMillis()}.mp4")
            return if (wantMic) "recording WITHOUT sound (allow microphone in Settings > Recording > Audio)" else "recording"
        }

        val t = System.currentTimeMillis()
        val video = "${dir.absolutePath}/v_$t.mp4"
        val audio = "${dir.absolutePath}/a_$t.m4a"
        startScreen(app, video)

        // microphone foreground service first (Android needs it to keep the mic while the game is in front)
        val latch = CountDownLatch(1)
        micUp = latch
        runCatching { ContextCompat.startForegroundService(app, Intent(app, MicRecService::class.java)) }
        latch.await(2, TimeUnit.SECONDS)

        var mr: MediaRecorder? = null
        try {
            mr = (if (Build.VERSION.SDK_INT >= 31) MediaRecorder(app) else legacyRecorder()).apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(128_000)
                setAudioSamplingRate(44_100)
                setMaxDuration(MAX_SEC * 1000)
                setOutputFile(audio)
                setOnInfoListener { _, what, _ ->
                    if (what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_DURATION_REACHED) thread { this@RecEngine.stop() }
                }
                prepare()
                start()
            }
        } catch (e: Throwable) {
            runCatching { mr?.release() }
            mr = null
            app.stopService(Intent(app, MicRecService::class.java))
            synchronized(lock) { session = Session(video, audio, null, app) }
            return "recording WITHOUT sound (mic error: ${e.message})"
        }
        synchronized(lock) { session = Session(video, audio, mr, app) }
        return "recording with mic"
    }

    /** Stops the recording. With mic sound it also joins video + sound (takes a few seconds). */
    fun stop(): String {
        val s = synchronized(lock) { val x = session; session = null; x }
        Shell.run("pkill -2 screenrecord")
        if (s == null) return "saved"

        var micOk = false
        s.mr?.let {
            micOk = runCatching { it.stop() }.isSuccess
            runCatching { it.release() }
        }
        s.app.stopService(Intent(s.app, MicRecService::class.java))

        // wait until screenrecord has finished writing the mp4
        var i = 0
        while (i < 30 && !Shell.run("pidof screenrecord").startsWith("exit")) { Thread.sleep(200); i++ }

        val name = "rec_${System.currentTimeMillis()}.mp4"
        val tmp = "${File(s.video).parent}/$name"
        var joined = false
        if (micOk) joined = runCatching { mux(s.video, s.audio, tmp); true }.getOrDefault(false)

        val src = if (joined) tmp else s.video
        Shell.run(
            "mkdir -p $OUT_DIR; mv $src $OUT_DIR/$name; rm -f ${s.video} ${s.audio} $tmp; " +
            "am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file://$OUT_DIR/$name >/dev/null 2>&1"
        )
        return if (joined) "saved with sound" else "saved (no sound)"
    }

    private fun mux(video: String, audio: String, out: String) {
        val vx = MediaExtractor()
        val ax = MediaExtractor()
        var mm: MediaMuxer? = null
        try {
            vx.setDataSource(video)
            ax.setDataSource(audio)
            val vt = (0 until vx.trackCount).first { vx.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true }
            val at = (0 until ax.trackCount).first { ax.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true }
            vx.selectTrack(vt)
            ax.selectTrack(at)
            mm = MediaMuxer(out, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val vi = mm.addTrack(vx.getTrackFormat(vt))
            val ai = mm.addTrack(ax.getTrackFormat(at))
            mm.start()
            copy(vx, mm, vi)
            copy(ax, mm, ai)
            mm.stop()
        } finally {
            runCatching { mm?.release() }
            runCatching { vx.release() }
            runCatching { ax.release() }
        }
    }

    private fun copy(ex: MediaExtractor, mm: MediaMuxer, track: Int) {
        val buf = ByteBuffer.allocate(4 * 1024 * 1024)
        val info = MediaCodec.BufferInfo()
        while (true) {
            buf.clear()
            val n = ex.readSampleData(buf, 0)
            if (n < 0) break
            val key = (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0
            info.set(0, n, ex.sampleTime, if (key) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
            mm.writeSampleData(track, buf, info)
            ex.advance()
        }
    }
}
