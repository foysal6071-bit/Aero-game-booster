package com.example.gameboost

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

/** Starts the panel again after a reboot or an app update. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent?) {
        if (Settings.canDrawOverlays(c) && !OverlayService.running)
            runCatching { c.startForegroundService(Intent(c, OverlayService::class.java)) }
    }
}
