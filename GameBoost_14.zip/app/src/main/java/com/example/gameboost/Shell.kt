package com.example.gameboost

object Shell {
    fun ready() = AeroAccess.state == AeroAccess.State.Ready

    fun run(cmd: String): String = try {
        val (code, out) = AeroAccess.run(cmd)
        val t = out.trim()
        if (code != 0) "exit $code: $t" else t.ifEmpty { "OK" }
    } catch (e: Throwable) { "Error: ${e.message}" }
}

object Boost {
    fun gameMode(pkg: String, mode: Int = 2) = Shell.run("cmd game set --mode $mode --user 0 ${AeroAccess.sq(pkg)}")
    fun compileSpeed(pkg: String) = Shell.run("cmd package compile -m speed -f ${AeroAccess.sq(pkg)}")
    fun killBackground() = Shell.run("am kill-all")
    fun refreshRate(hz: Int) =
        Shell.run("settings put system min_refresh_rate $hz; settings put system peak_refresh_rate $hz")
    fun animations(scale: String) = Shell.run(
        "settings put global window_animation_scale $scale; " +
        "settings put global transition_animation_scale $scale; " +
        "settings put global animator_duration_scale $scale"
    )
    /** level 1..5. Touch-and-hold delay works on every phone; the OEM high-sensitivity flag only where the maker supports it. */
    fun touch(level: Int): String {
        val delay = when (level) { 1 -> 1000; 2 -> 500; 3 -> 400; 4 -> 300; else -> 200 }
        val hi = if (level >= 4) 1 else 0
        return Shell.run("settings put secure long_press_timeout $delay; settings put system high_touch_sensitivity_enable $hi")
    }
    fun stats() = Shell.run("cat /proc/meminfo | head -3; dumpsys battery | grep temperature")
}
