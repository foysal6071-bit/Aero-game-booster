package com.example.gameboost

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.PopupWindow
import android.graphics.drawable.ColorDrawable
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.min

/** In-game edge-swipe panel, styled like Xiaomi Game Turbo. */
class OverlayService : Service() {

    companion object { @Volatile var running = false }

    private val BLUE = 0xFF4C9AFF.toInt()
    private val BG = 0xF2121822.toInt()
    private val TILE = 0xFF1A2130.toInt()
    private val LINE = 0x26FFFFFF
    private val TXT = 0xFFEAF0FA.toInt()
    private val DIMT = 0xFF8B97AE.toInt()
    private val LIME = 0xFF2EE6A6.toInt()

    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private var handle: View? = null
    private var scrim: FrameLayout? = null
    private var timerTv: TextView? = null
    private var voicePop: PopupWindow? = null

    private var dnd = false
    private var rec = false
    private var hz = false
    private var gmode = 2
    private var vmode = 0
    private var timerRunning = false
    private var timerStart = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        AeroAccess.init(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("overlay", "Game panel", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "overlay")
            .setContentTitle("Aero Boost")
            .setContentText("Swipe from either screen edge in game")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            var t = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                t = t or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            startForeground(1, n, t)
        } else startForeground(1, n)
        addHandle()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onDestroy() {
        running = false
        VoiceFx.liveStop()
        ui.removeCallbacksAndMessages(null)
        hidePanel()
        handle?.let { runCatching { wm.removeView(it) } }
        handleR?.let { runCatching { wm.removeView(it) } }
        handle = null; handleR = null
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun ripple(content: android.graphics.drawable.Drawable, r: Int) =
        android.graphics.drawable.RippleDrawable(
            android.content.res.ColorStateList.valueOf(0x33FFFFFF), content, box(Color.WHITE, r)
        )

    private fun panelBg() = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xF2182030.toInt(), 0xF20F141E.toInt())).apply {
        cornerRadius = dp(16).toFloat()
        setStroke(dp(1), 0x26FFFFFF)
    }

    private fun tileBg(on: Boolean) =
        ripple(if (on) box(0x1F2EE6A6, 12, 0x662EE6A6) else box(TILE, 12, LINE), 12)

    private fun box(fill: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(r).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    // ---------- edge handles (left + right) ----------
    private var panelRight = false
    private var handleR: View? = null

    private fun makeHandle(right: Boolean): View {
        val sideG = if (right) Gravity.END else Gravity.START
        val r = dp(8).toFloat()
        // slim MIUI-style tab: only 10dp wide on screen, the touch area around it stays wider
        val v = FrameLayout(this)
        val tab = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setColor(0x99262B36.toInt())
                cornerRadii = if (right) floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r) else floatArrayOf(0f, 0f, r, r, r, r, 0f, 0f)
            }
        }
        tab.addView(View(this).apply { background = box(0xCCFFFFFF.toInt(), 1) },
            FrameLayout.LayoutParams(dp(2), dp(16), Gravity.CENTER))
        v.addView(tab, FrameLayout.LayoutParams(dp(10), dp(56), sideG or Gravity.CENTER_VERTICAL))
        var downX = 0f
        var fired = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; fired = false }
                MotionEvent.ACTION_MOVE -> {
                    val d = if (right) downX - e.rawX else e.rawX - downX
                    if (!fired && d > dp(14)) { fired = true; panelRight = right; showPanel() }
                }
                MotionEvent.ACTION_UP -> if (!fired && abs(e.rawX - downX) < dp(6)) { panelRight = right; showPanel() }
            }
            true
        }
        v.addOnLayoutChangeListener { view, l, t, rr, bt, _, _, _, _ ->
            if (Build.VERSION.SDK_INT >= 29)
                view.systemGestureExclusionRects = listOf(android.graphics.Rect(0, 0, rr - l, bt - t))
        }
        val dm = resources.displayMetrics
        val lp = WindowManager.LayoutParams(
            dp(24), dp(80),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = sideG or Gravity.TOP
            y = (dm.heightPixels * 0.62f).toInt()   // lower-middle, like MIUI Game Turbo
            if (Build.VERSION.SDK_INT >= 28)
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(v, lp)
        return v
    }

    private fun addHandle() {
        handle = makeHandle(false)
        handleR = makeHandle(true)
    }

    // ---------- panel window ----------
    private fun showPanel() {
        if (scrim != null) return
        AeroAccess.startPolling(this)
        val dm = resources.displayMetrics
        val right = panelRight
        val s = FrameLayout(this).apply {
            setBackgroundColor(0x66000000)
            setOnClickListener { hidePanel() }
        }
        val pw = (dm.widthPixels * 0.46f).toInt() - dp(8)
        val ph = min(dm.heightPixels - dp(16), dp(300))
        val p = buildPanel()
        s.addView(p, FrameLayout.LayoutParams(pw, ph, (if (right) Gravity.END else Gravity.START) or Gravity.CENTER_VERTICAL).apply {
            if (right) rightMargin = dp(8) else leftMargin = dp(8)
        })
        wm.addView(
            s,
            WindowManager.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                if (Build.VERSION.SDK_INT >= 28)
                    layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        )
        scrim = s
        p.translationX = if (right) pw.toFloat() else -pw.toFloat()
        p.animate().translationX(0f).setDuration(200).start()
    }

    private fun hidePanel() {
        voicePop?.dismiss(); voicePop = null
        AeroAccess.stopPolling()
        scrim?.let { runCatching { wm.removeView(it) } }
        scrim = null
        timerTv = null
    }

    // ---------- UI pieces ----------
    private fun ic(res: Int, tint: Int) = ImageView(this).apply {
        setImageResource(res)
        setColorFilter(tint)
    }

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun badge(res: Int, tint: Int, bg: Int, size: Int = 34, icon: Int = 20) = FrameLayout(this).apply {
        background = box(bg, size / 2)
        addView(ic(res, tint), FrameLayout.LayoutParams(dp(icon), dp(icon), Gravity.CENTER))
        layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
    }

    private fun actionTile(res: Int, text: String, click: () -> Unit): LinearLayout {
        val me = this
        return LinearLayout(me).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = tileBg(false)
            setPadding(dp(2), dp(4), dp(2), dp(4))
            addView(badge(res, BLUE, 0x264C9AFF, 26, 16))
            addView(label(text, 9f, TXT).apply { gravity = Gravity.CENTER; setPadding(0, dp(3), 0, 0); maxLines = 1 })
            setOnClickListener { click() }
        }
    }

    private fun toolItem(res: Int, text: String, on: Boolean, click: (LinearLayout) -> Unit): LinearLayout {
        val me = this
        return LinearLayout(me).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = tileBg(on)
            setPadding(dp(1), dp(5), dp(1), dp(5))
            addView(badge(res, if (on) LIME else BLUE, if (on) 0x262EE6A6 else 0x264C9AFF, 26, 16))
            addView(label(text, 8f, if (on) LIME else DIMT).apply { gravity = Gravity.CENTER; setPadding(0, dp(3), 0, 0); maxLines = 1 })
            setOnClickListener { click(this) }
        }
    }

    private fun setOn(v: LinearLayout, on: Boolean) {
        val b = v.getChildAt(0) as FrameLayout
        v.background = tileBg(on)
        b.background = box(if (on) 0x262EE6A6 else 0x264C9AFF, 13)
        (b.getChildAt(0) as ImageView).setColorFilter(if (on) LIME else BLUE)
        (v.getChildAt(1) as TextView).setTextColor(if (on) LIME else DIMT)
    }

    private fun wideTile(res: Int, text: String, filled: Boolean, click: () -> Unit): Pair<LinearLayout, TextView> {
        val me = this
        val tv = label(text, 13f, TXT).apply { setPadding(dp(10), 0, 0, 0) }
        val l = LinearLayout(me).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = box(TILE, 10, LINE)
            setPadding(dp(10), dp(12), dp(10), dp(12))
            addView(ic(res, BLUE), LinearLayout.LayoutParams(dp(20), dp(20)))
            addView(tv)
            setOnClickListener { click() }
        }
        return l to tv
    }

    private fun gameName() = when (gmode) { 1 -> "Standard"; 3 -> "Saver"; else -> "Perform" }

    private fun buildPanel(): LinearLayout {
        val me = this
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val root = LinearLayout(me).apply { orientation = LinearLayout.HORIZONTAL; isClickable = true }

        // --- left strip: games ---
        val strip = LinearLayout(me).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(4), dp(6), dp(4), dp(6)) }
        (getSharedPreferences("games", MODE_PRIVATE).getString("list", "") ?: "")
            .split(",").filter { it.isNotBlank() }.forEach { p ->
                try {
                    val iv = ImageView(me).apply {
                        setImageDrawable(packageManager.getApplicationIcon(p))
                        background = box(Color.TRANSPARENT, 9); clipToOutline = true
                        setOnClickListener { launchFloating(p) }
                        setOnLongClickListener { launchNormal(p); hidePanel(); true }   // long-press = full screen
                    }
                    strip.addView(iv, LinearLayout.LayoutParams(dp(34), dp(34)).apply { setMargins(0, dp(3), 0, dp(3)) })
                } catch (_: Throwable) {}
            }
        root.addView(ScrollView(me).apply { background = panelBg(); addView(strip) }, LinearLayout.LayoutParams(dp(42), match))

        // --- main panel (everything fits in 4 columns) ---
        val col = LinearLayout(me).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(6), dp(8), dp(8)) }
        val mainSv = ScrollView(me).apply { background = panelBg(); addView(col) }

        val head = LinearLayout(me).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(label("Aero Turbo", 13f, TXT, true).apply { letterSpacing = 0.03f }, LinearLayout.LayoutParams(wrap, wrap))
        val linked = AeroAccess.state == AeroAccess.State.Ready
        head.addView(View(me).apply { background = box(if (linked) LIME else 0xFFFFB84D.toInt(), 3) },
            LinearLayout.LayoutParams(dp(6), dp(6)).apply { leftMargin = dp(8) })
        head.addView(label(if (linked) "Linked" else "Not linked", 9f, DIMT).apply { setPadding(dp(4), 0, 0, 0) },
            LinearLayout.LayoutParams(0, wrap, 1f))
        head.addView(ic(R.drawable.ic_close, DIMT).apply { setOnClickListener { hidePanel() }; setPadding(dp(3), dp(3), dp(3), dp(3)) },
            LinearLayout.LayoutParams(dp(22), dp(22)))
        col.addView(head)

        fun cell() = LinearLayout.LayoutParams(0, match, 1f).apply { leftMargin = dp(6) }
        fun cellFirst() = LinearLayout.LayoutParams(0, match, 1f)

        // row 1: Boost | Clear RAM | Storage | Timer
        val r1 = LinearLayout(me).apply { orientation = LinearLayout.HORIZONTAL }
        val boostTile = LinearLayout(me).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = ripple(GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF3B82F6.toInt(), 0xFF22C7EE.toInt()))
                .apply { cornerRadius = dp(12).toFloat() }, 12)
            addView(ic(R.drawable.ic_rocket, Color.WHITE), LinearLayout.LayoutParams(dp(22), dp(22)))
            addView(label("Boost", 10f, Color.WHITE, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(3), 0, 0) })
            setOnClickListener {
                act("Boost") {
                    val g = currentGame()
                    val a = if (g.isNotBlank()) Boost.gameMode(g, gmode) else "no game found"
                    "mode: $a | ram: ${Boost.killBackground()}"
                }
            }
        }
        r1.addView(boostTile, cellFirst())
        r1.addView(actionTile(R.drawable.ic_tune, "Clear RAM") { act("Clear memory") { Boost.killBackground() } }, cell())
        r1.addView(actionTile(R.drawable.ic_storage, "Storage") { act("Free storage") { Shell.run("pm trim-caches 100G") } }, cell())
        val timerTile = actionTile(R.drawable.ic_hourglass, timerText()) {}
        timerTv = timerTile.getChildAt(1) as TextView
        timerTile.setOnClickListener {
            timerRunning = !timerRunning
            if (timerRunning) { timerStart = System.currentTimeMillis(); tick() }
            timerTv?.text = timerText()
        }
        if (timerRunning) tick()
        r1.addView(timerTile, cell())
        col.addView(r1, LinearLayout.LayoutParams(match, dp(58)).apply { topMargin = dp(6) })

        // voice changer box (opens under the grid)
        val voiceBox = LinearLayout(me).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            background = box(TILE, 10, LINE)
            setPadding(dp(8), dp(6), dp(8), dp(8))
        }

        // rows 2-3: tools
        val tp = { LinearLayout.LayoutParams(0, wrap, 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) } }
        val grid = LinearLayout(me).apply { orientation = LinearLayout.VERTICAL }
        val g1 = LinearLayout(me).apply { orientation = LinearLayout.HORIZONTAL }
        val g2 = LinearLayout(me).apply { orientation = LinearLayout.HORIZONTAL }
        g1.addView(toolItem(R.drawable.ic_dnd, "DND", dnd) { v ->
            dnd = !dnd; setOn(v, dnd)
            act("DND " + if (dnd) "on" else "off") { Shell.run("cmd notification set_dnd " + if (dnd) "on" else "off") }
        }, tp())
        g1.addView(toolItem(R.drawable.ic_cut, "Shot", false) {
            hidePanel()
            ui.postDelayed({
                thread {
                    val r = Shell.run("mkdir -p /sdcard/Pictures/AeroBoost; screencap -p /sdcard/Pictures/AeroBoost/shot_${System.currentTimeMillis()}.png")
                    ui.post { toast(if (r == "OK") "Screenshot saved" else r) }
                }
            }, 400)
        }, tp())
        g1.addView(toolItem(R.drawable.ic_video, "Record", rec) { v ->
            rec = !rec; setOn(v, rec)
            if (rec) {
                hidePanel()
                thread {
                    Shell.run("mkdir -p /sdcard/Movies/AeroBoost; nohup screenrecord --time-limit 180 /sdcard/Movies/AeroBoost/rec_${System.currentTimeMillis()}.mp4 >/dev/null 2>&1 &")
                    ui.post { toast("Recording...") }
                }
            } else act("Record stop") { Shell.run("pkill -2 screenrecord"); "saved" }
        }, tp())
        g1.addView(toolItem(R.drawable.ic_bolt, "120Hz", hz) { v ->
            hz = !hz; setOn(v, hz)
            act(if (hz) "120Hz" else "60Hz") { Boost.refreshRate(if (hz) 120 else 60) }
        }, tp())
        g2.addView(toolItem(R.drawable.ic_rocket, gameName(), false) { v ->
            gmode = gmode % 3 + 1
            (v.getChildAt(1) as TextView).text = gameName()
            act("Mode " + gameName()) { Boost.gameMode(currentGame(), gmode) }
        }, tp())
        g2.addView(toolItem(R.drawable.ic_chart, "Monitor", false) { act("Monitor") { Boost.stats() } }, tp())
        var showVoiceBox: (Boolean) -> Unit = {}
        g2.addView(toolItem(R.drawable.ic_mic, "Voice", VoiceFx.liveOn) { v ->
            showVoicePopup(
                v, VoiceFx.liveOn,
                onHold = { if (VoiceFx.liveOn) { VoiceFx.liveStop(); setOn(v, false) }; showVoiceBox(false) },
                onToggle = {
                    if (VoiceFx.liveOn) {
                        VoiceFx.liveStop(); setOn(v, false); voiceBox.visibility = View.GONE
                    } else if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                        toast("Allow the microphone in Aero Boost first")
                    } else {
                        VoiceFx.liveMode = vmode
                        if (VoiceFx.liveStart()) { setOn(v, true); showVoiceBox(true) } else toast("Microphone is busy")
                    }
                }
            )
        }, tp())
        g2.addView(toolItem(R.drawable.ic_gear, "Settings", false) {
            hidePanel()
            startActivity(Intent(me, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }, tp())
        grid.addView(g1); grid.addView(g2)
        col.addView(grid, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(4); leftMargin = -dp(2); rightMargin = -dp(2) })

        // voice changer content
        val names = listOf("Girl", "Robot", "Cat")
        val chipRow = LinearLayout(me).apply { orientation = LinearLayout.HORIZONTAL }
        val chips = names.map { n -> label(n, 11f, TXT, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(6)) } }
        fun paint() {
            chips.forEachIndexed { i, v ->
                val sel = i == vmode
                v.background = if (sel) box(BLUE, 6) else box(Color.TRANSPARENT, 6, LINE)
                v.setTextColor(if (sel) 0xFF05070D.toInt() else TXT)
            }
        }
        chips.forEachIndexed { i, v ->
            v.setOnClickListener { vmode = i; VoiceFx.liveMode = i; paint() }
            chipRow.addView(v, LinearLayout.LayoutParams(0, wrap, 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        }
        paint()
        val hint = label("Pick a voice, hold the button and talk. It plays when you let go.", 9f, DIMT)
        voiceBox.addView(hint)
        voiceBox.addView(chipRow, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(6) })
        val talk = label("Hold to talk", 12f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF3B82F6.toInt(), 0xFF22C7EE.toInt()))
                .apply { cornerRadius = dp(6).toFloat() }
            setPadding(0, dp(9), 0, dp(9))
        }
        talk.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                        toast("Allow the microphone in Aero Boost first")
                    } else if (VoiceFx.start()) {
                        talk.text = "Recording..."
                    } else toast("Microphone is busy")
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (VoiceFx.active) {
                        talk.text = "Hold to talk"
                        VoiceFx.finish(vmode)
                    }
                }
            }
            true
        }
        voiceBox.addView(talk, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(6) })
        col.addView(voiceBox, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(6) })
        showVoiceBox = { live ->
            hint.text = if (live) "Voice changer is ON. Your voice plays back changed (use earphones to avoid echo)."
                        else "Pick a voice, hold the button and talk. It plays when you let go."
            talk.visibility = if (live) View.GONE else View.VISIBLE
            voiceBox.visibility = View.VISIBLE
            mainSv.post { mainSv.fullScroll(View.FOCUS_DOWN) }
        }
        if (VoiceFx.liveOn) showVoiceBox(true)

        root.addView(mainSv, LinearLayout.LayoutParams(0, match, 1f).apply { leftMargin = dp(6) })
        return root
    }

    // ---------- helpers ----------
    private fun timerText(): String {
        if (!timerRunning) return "Timer"
        val s = (System.currentTimeMillis() - timerStart) / 1000
        return "%02d:%02d".format(s / 60, s % 60)
    }

    private fun tick() {
        ui.removeCallbacks(tickRun)
        ui.postDelayed(tickRun, 1000)
    }

    private val tickRun = object : Runnable {
        override fun run() {
            if (!timerRunning) return
            timerTv?.text = timerText()
            ui.postDelayed(this, 1000)
        }
    }

    private fun launchNormal(p: String) {
        packageManager.getLaunchIntentForPackage(p)?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); runCatching { startActivity(it) }
        }
    }

    private fun settingOn(key: String) = runCatching {
        android.provider.Settings.Global.getInt(contentResolver, key, 0) == 1
    }.getOrDefault(false)

    /** Opens the app in a freeform (floating) window. If the two developer options are off, asks the user to enable them first. */
    private fun launchFloating(p: String) {
        val missing = mutableListOf<String>()
        if (!settingOn("enable_freeform_support")) missing += "Enable freeform windows"
        if (!settingOn("force_resizable_activities")) missing += "Force activities to be resizable"
        if (missing.isEmpty()) startFloating(p) else showFloatPrompt(p, missing)
    }

    private fun startFloating(p: String) {
        hidePanel()
        val comp = packageManager.getLaunchIntentForPackage(p)?.component?.flattenToShortString()
        if (comp == null || !Shell.ready()) { launchNormal(p); return }
        thread {
            val r = Shell.run("am start --user 0 --windowingMode 5 -n ${AeroAccess.sq(comp)}")
            if (r.startsWith("Error") || r.startsWith("exit") || r.contains("Error type", true))
                ui.post { toast("Floating window not supported here, opening normally"); launchNormal(p) }
        }
    }

    private fun showFloatPrompt(p: String, missing: List<String>) {
        var v: FrameLayout? = null
        val close = { v?.let { runCatching { wm.removeView(it) } }; v = null }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = box(BG, 14, LINE)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            isClickable = true
            addView(label("Turn on in Developer options", 13f, TXT, true))
            addView(label(missing.joinToString("\n") { "•  $it" }, 12f, BLUE).apply { setPadding(0, dp(8), 0, dp(4)) })
            addView(label("Floating windows need both switched on.", 10f, DIMT))
            val row = LinearLayout(this@OverlayService).apply { orientation = LinearLayout.HORIZONTAL }
            fun btn(t: String, fill: Boolean, c: () -> Unit) = label(t, 11f, if (fill) Color.WHITE else TXT, true).apply {
                gravity = Gravity.CENTER
                background = if (fill) box(0xFF3B82F6.toInt(), 8) else box(Color.TRANSPARENT, 8, LINE)
                setPadding(0, dp(8), 0, dp(8))
                setOnClickListener { c() }
            }
            row.addView(btn("Open settings", true) {
                close()
                hidePanel()
                runCatching {
                    startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }.onFailure { toast("Open Settings > Developer options") }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(btn("Try anyway", false) {
                close()
                thread {
                    Shell.run("settings put global enable_freeform_support 1; settings put global force_resizable_activities 1")
                    ui.post { startFloating(p) }
                }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(8) })
            addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) })
        }
        val root = FrameLayout(this).apply {
            setBackgroundColor(0x88000000.toInt())
            setOnClickListener { close() }
            addView(card, FrameLayout.LayoutParams(dp(280), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        }
        v = root
        wm.addView(
            root,
            WindowManager.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
        )
    }

    /** Small floating chooser above the Voice button: Hold (push-to-talk) or On/Off (live). */
    private fun showVoicePopup(anchor: View, liveOn: Boolean, onHold: () -> Unit, onToggle: () -> Unit) {
        voicePop?.dismiss()
        lateinit var pw: PopupWindow
        fun opt(res: Int, text: String, on: Boolean, c: () -> Unit) = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(8), dp(12), dp(8))
            background = box(if (on) 0x262EE6A6 else 0x264C9AFF, 10)
            addView(ic(res, if (on) LIME else BLUE), LinearLayout.LayoutParams(dp(16), dp(16)))
            addView(label(text, 11f, if (on) LIME else TXT, true).apply { setPadding(dp(6), 0, 0, 0) })
            setOnClickListener { pw.dismiss(); c() }
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = box(BG, 14, LINE)
            setPadding(dp(6), dp(6), dp(6), dp(6))
            addView(opt(R.drawable.ic_mic, "Hold", false, onHold))
            addView(opt(R.drawable.ic_bolt, if (liveOn) "Off" else "On", liveOn, onToggle),
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(6) })
        }
        content.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        pw = PopupWindow(content, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, false).apply {
            isOutsideTouchable = true
            setBackgroundDrawable(ColorDrawable(0))
            elevation = dp(8).toFloat()
        }
        voicePop = pw
        pw.showAsDropDown(anchor, (anchor.width - content.measuredWidth) / 2, -(anchor.height + content.measuredHeight + dp(4)))
    }

    private fun toast(t: String) = Toast.makeText(this, t.take(200), Toast.LENGTH_LONG).show()

    private fun act(name: String, f: () -> String) {
        toast("$name...")
        thread {
            val r = try { f() } catch (e: Throwable) { "Error: ${e.message}" }
            ui.post { toast("$name: $r") }
        }
    }

    private fun currentGame(): String {
        val r = Shell.run("dumpsys activity activities | grep -m1 -E 'topResumedActivity|mResumedActivity'")
        val p = Regex("([a-zA-Z][a-zA-Z0-9_]*(?:\\.[a-zA-Z0-9_]+)+)/").find(r)?.groupValues?.get(1)
        if (p != null && p != packageName && !p.startsWith("com.android.systemui")) return p
        return getSharedPreferences("games", MODE_PRIVATE).getString("sel", "") ?: ""
    }
}
