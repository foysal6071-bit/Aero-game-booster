package com.example.gameboost

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/** Record while held, apply an effect, play it back. Modes: 0 girl, 1 robot, 2 cat. */
object VoiceFx {
    private const val RATE = 16000
    private const val MAX = RATE * 15
    @Volatile private var recording = false
    private var worker: Thread? = null
    private val chunks = ArrayList<ShortArray>()
    @Volatile private var total = 0

    val active: Boolean get() = recording

    // ---- live ("On") mode: mic -> effect -> speaker, in ~0.25 s blocks ----
    @Volatile var liveMode = 0
    @Volatile private var live = false
    val liveOn: Boolean get() = live

    fun liveStart(): Boolean {
        if (live || recording) return false
        val blk = 4096
        val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val r = try {
            AudioRecord(MediaRecorder.AudioSource.MIC, RATE, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, max(min, blk * 4))
        } catch (e: Throwable) { return false }
        if (r.state != AudioRecord.STATE_INITIALIZED) { r.release(); return false }
        live = true
        thread {
            val tmin = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val t = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(RATE).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(max(tmin, blk * 4))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            try {
                r.startRecording(); t.play()
                val b = ShortArray(blk)
                while (live) {
                    var got = 0
                    while (live && got < blk) {
                        val n = r.read(b, got, blk - got)
                        if (n <= 0) { live = false; break }
                        got += n
                    }
                    if (got < blk) break
                    val x = FloatArray(blk) { b[it] / 32768f }
                    var peak = 0f
                    for (v in x) peak = max(peak, abs(v))
                    val y = if (peak < 0.02f) FloatArray(blk) else {
                        val o = when (liveMode) { 0 -> pitch(x, 1.3f, 0f); 2 -> pitch(x, 1.75f, 0.25f); else -> robot(x) }
                        val m = minOf(128, o.size / 2)
                        for (i in 0 until m) { val k = i / m.toFloat(); o[i] *= k; o[o.size - 1 - i] *= k }
                        o
                    }
                    val sh = ShortArray(y.size) { (y[it].coerceIn(-1f, 1f) * 32767).toInt().toShort() }
                    t.write(sh, 0, sh.size)
                }
            } catch (_: Throwable) {
            } finally {
                live = false
                try { r.stop() } catch (_: Throwable) {}
                r.release()
                try { t.stop() } catch (_: Throwable) {}
                t.release()
            }
        }
        return true
    }

    fun liveStop() { live = false }

    fun start(): Boolean {
        if (recording) return false
        val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val r = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC, RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(min, RATE)
            )
        } catch (e: Throwable) { return false }
        if (r.state != AudioRecord.STATE_INITIALIZED) { r.release(); return false }
        synchronized(chunks) { chunks.clear() }
        total = 0
        recording = true
        worker = thread {
            try {
                r.startRecording()
                val b = ShortArray(1024)
                while (recording && total < MAX) {
                    val n = r.read(b, 0, b.size)
                    if (n > 0) { synchronized(chunks) { chunks.add(b.copyOf(n)) }; total += n }
                    else if (n < 0) break
                }
            } catch (_: Throwable) {
            } finally {
                try { r.stop() } catch (_: Throwable) {}
                r.release()
            }
        }
        return true
    }

    fun finish(mode: Int) {
        recording = false
        thread {
            worker?.join(800)
            val n = total
            if (n < RATE / 4) return@thread
            val x = FloatArray(n)
            var p = 0
            synchronized(chunks) { for (c in chunks) for (v in c) if (p < n) x[p++] = v / 32768f }
            val y = when (mode) {
                0 -> pitch(x, 1.3f, 0f)
                2 -> pitch(x, 1.75f, 0.25f)
                else -> robot(x)
            }
            play(y)
        }
    }

    private fun pitch(x: FloatArray, f: Float, vib: Float): FloatArray {
        val n = (x.size / f).toInt()
        val r = FloatArray(n)
        for (i in 0 until n) {
            val pos = i * f
            val a = pos.toInt()
            val fr = pos - a
            val b = if (a + 1 < x.size) x[a + 1] else x[a]
            r[i] = x[a] * (1 - fr) + b * fr
        }
        val s = stretch(r, f)
        if (vib > 0f) for (i in s.indices) s[i] *= 1f - vib + vib * sin(2.0 * PI * 7 * i / RATE).toFloat()
        return norm(s)
    }

    private fun stretch(x: FloatArray, ratio: Float): FloatArray {
        val win = 512
        val hs = 256
        val ha = hs / ratio
        val outLen = (x.size * ratio).toInt()
        val out = FloatArray(outLen + win)
        val nm = FloatArray(outLen + win)
        val w = FloatArray(win) { (0.5 - 0.5 * cos(2.0 * PI * it / (win - 1))).toFloat() }
        var pos = 0
        var ap = 0f
        while (pos < outLen) {
            val a = ap.toInt()
            if (a + win > x.size) break
            for (i in 0 until win) { out[pos + i] += x[a + i] * w[i]; nm[pos + i] += w[i] }
            pos += hs
            ap += ha
        }
        for (i in out.indices) if (nm[i] > 1e-3f) out[i] /= nm[i]
        return out.copyOf(outLen)
    }

    private fun robot(x: FloatArray): FloatArray {
        val y = FloatArray(x.size)
        var held = 0f
        for (i in x.indices) {
            if (i % 3 == 0) held = x[i]
            val m = sin(2.0 * PI * 70 * i / RATE).toFloat()
            y[i] = held * (0.15f + 0.85f * m)
        }
        return norm(y)
    }

    private fun norm(x: FloatArray): FloatArray {
        var peak = 0f
        for (v in x) peak = max(peak, abs(v))
        if (peak > 1e-4f) { val k = 0.9f / peak; for (i in x.indices) x[i] *= k }
        return x
    }

    private fun play(y: FloatArray) {
        if (y.isEmpty()) return
        val s = ShortArray(y.size) { (y[it].coerceIn(-1f, 1f) * 32767).toInt().toShort() }
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(s.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        t.write(s, 0, s.size)
        t.play()
        Thread.sleep(s.size * 1000L / RATE + 300)
        t.release()
    }
}
