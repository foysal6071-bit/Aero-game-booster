# AERO TURBO
AeroHUB ভিত্তিক Android gaming tool (root ছাড়া)।

## AeroHUB access
1. AeroHUB app install করে server চালু করুন
2. Aero Boost খুলে CONNECT চাপুন, Allow দিন
3. AeroHUB > Apps এ এই app এর switch চালু রাখুন

## ফিচার
Game Mode, speed compile, RAM clean, refresh rate, animation scale, stats।

## In-game panel
Aero Boost এ "IN-GAME PANEL" চালু করুন (Display over other apps permission দিন)।
প্যানেল (কিনারার ট্যাব/স্লাইডার) শুধু মূল স্ক্রিনের গেম তালিকায় যোগ করা গেমের ভিতরে দেখা যায়; গেম থেকে বের হলে বা অন্য অ্যাপে গেলে ট্যাবগুলো (ও খোলা প্যানেল) সরে যায়। গেমের ভিতর বাম বা ডান যেকোনো কিনারা থেকে ভিতরের দিকে টান দিন (নেভিগেশন জেসচারের জন্য কিনারার একটু ভিতর থেকে শুরু করুন)।

## মূল স্ক্রিন
MIUI Aero Turbo-র মতো: বামে গেমের তালিকা, মাঝে প্রিভিউ, ডানে "Start playing" (boost করে গেম চালু করে), নিচে মোড (Default/Performance/Battery saver, চাপলে বদলায়)।
উপরে ডানে: + গেম যোগ, রেকর্ড, সেটিংস, বের হওয়া। বাকি সব সেটিংসে (AeroHUB link, 120Hz, animation, in-game panel, tools)।

## Floating window
In-game panel এর বামের গেম/অ্যাপ আইকনে চাপ দিলে app floating (freeform) window তে খোলে; লং-প্রেস করলে পুরো স্ক্রিনে। Developer options এ "Enable freeform windows" ও "Force activities to be resizable" বন্ধ থাকলে app চালু করার সময় সেটা চালু করতে বলবে (Open settings বা Try anyway)। ROM সাপোর্ট না করলে স্বাভাবিকভাবে খোলে।

## Tools সাজানো (নতুন)
In-game panel এর নিচের tools strip (Screenshot, Record, DND, Settings, FPS, Mode) এ যেকোনো tool লং-প্রেস (tap & hold) করে ডানে/বামে swipe করলে জায়গা বদলানো যায়। টানার সময় tool টি উঁচু হয়ে ভাইব্রেট করে, বাকিগুলো সরে জায়গা করে দেয়; কিনারার কাছে নিলে strip নিজে স্ক্রল করে। ছাড়লে নতুন ক্রম সেভ হয় (SharedPreferences "panel" > toolOrder)।

## Gaming UI
নিয়ন সায়ান + ভায়োলেট থিম, কোণা-কাটা (chamfer) ফ্রেম ও glow বর্ডার, বোল্ড ইটালিক হেডার, গ্র্যাডিয়েন্ট BOOST/START PLAYING বাটন। প্যানেল ও মূল অ্যাপ দুটোতেই প্রযোজ্য।

## Game launching animation (নতুন)
"START PLAYING" চাপলে ফুলস্ক্রিন লঞ্চ অ্যানিমেশন চলে: গেমের আইকনের চারপাশে ঘূর্ণায়মান নিয়ন রিং ও শকওয়েভ, "LAUNCHING" লেখা, প্রগ্রেস বার ও ধাপের নাম (Game mode, Clean RAM, Fast animation, Refresh rate)। সব ধাপ শেষ হলে গেম চালু হয় এবং অ্যানিমেশন ফেড-আউট হয়। চলার সময় Back চাপলে কিছু হয় না। কোড: `LaunchOverlay` (MainActivity.kt)।

## Recording audio (নতুন)
- Settings > Recording > Audio তে **Mic** বেছে নিলে মাইক্রোফোনের শব্দ ভিডিওর সাথে সেভ হয়। প্রথমবার মাইক্রোফোনের পারমিশন চাইবে। রেকর্ডিং থামালে ভিডিও ও শব্দ জোড়া লেগে একটাই mp4 হয় (কয়েক সেকেন্ড লাগে)। গেমের ভেতরের সাউন্ড (internal audio) এখনো ধরা যায় না।

## Launch sound ও Touch response (নতুন)
- **Launch sound:** গেম লঞ্চ হওয়ার সময় মেকানিক্যাল সাউন্ড বাজে: boost চলার সময় গিয়ার-র‍্যাচেট ও সার্ভো ঘোরার লুপ, শেষে "Launching game" এর মুহূর্তে ভারী লক/ক্লাংক। সাউন্ড ফাইল `res/raw/mech_spin.wav` ও `mech_lock.wav`। Settings > General এ "Launch sound" সুইচে চালু/বন্ধ করা যায়।
- **Touch response:** Settings > Performance এ 0–100% স্লাইডার (50% = ফোনের নিজের মান)। বাড়ালে touch-and-hold ও double-tap দ্রুত সাড়া দেয় (hold 1000ms → 150ms, double-tap 600ms → 200ms), 70% থেকে সাপোর্টেড ফোনে OEM high-sensitivity চালু হয়। স্লাইডার ছাড়লে প্রয়োগ হয়; গেম বন্ধ হলে বা Restore চাপলে আবার 50% এ ফিরে যায়।

## Portrait mode (নতুন)
গেম portrait এ থাকলে প্যানেল প্রায় পুরো প্রস্থে খোলে (গেম আইকন স্ট্রিপ + ৪ কলামের মূল প্যানেল), উচ্চতা কনটেন্ট অনুযায়ী, ছোট স্ক্রিনে স্ক্রল হয়। স্ক্রিন ঘোরালে খোলা প্যানেল বন্ধ হয় ও কিনারার ট্যাব নতুন জায়গায় সরে যায়। কোড: `OverlayService.showPanel()`, `onConfigurationChanged()`।

## Tools strip মাপ (নতুন)
Tools strip এ এখন ঠিক ৪টি tool পুরো দেখা যায় (আধা-কাটা tile নেই); বাকিগুলো সোয়াইপ করলে আসে ও থামার পর নিকটতম tile এর কিনারায় সেট হয়ে যায়।

## Edge tab (নতুন)
এখন শুধু একটি tab, বাম কিনারায় (landscape ও portrait দুটোতেই), ডিফল্ট উপরের দিকে। tab এ লং-প্রেস করে উপর-নিচ টেনে জায়গা বদলানো যায়; জায়গা প্রতিটি orientation এর জন্য আলাদা সেভ হয়। ভিতরের দিকে টানলে বা চাপলে প্যানেল খোলে।

## Swipe দিয়ে গেম বদল (নতুন)
মূল স্ক্রিনে বামের তালিকায় উপর/নিচ সোয়াইপ করলে পরের/আগের গেম সিলেক্ট হয় (তালিকা নিজে স্ক্রল করে সিলেক্টেড গেম দেখায়); মাঝের প্রিভিউ কার্ডে বামে/ডানে সোয়াইপ করলে একটি করে গেম বদলায় ও প্রিভিউ স্লাইড করে আসে। চাপ দিয়ে সিলেক্ট ও লং-প্রেসে সরানো আগের মতোই। কোড: `HomeScreen` (MainActivity.kt)।

## Fullscreen (নতুন)
অ্যাপ ফুলস্ক্রিনে চলে: স্ট্যাটাস বার ও নেভিগেশন বার দেখা যায় না (কিনারা থেকে সোয়াইপ করলে সাময়িকভাবে আসে)। কোড: `MainActivity.hideSystemBars()`।


## AERO TURBO Premium update
- Settings categories are separated: General settings, Performance, Game Data, Sensitivity, Recording, and Tools.
- In-game shortcuts now controls whether the edge handle appears while a selected game is in the foreground.
- Content recommendations controls the optional local gaming tip in General settings.
- Game Data lists saved games, lets you select one, and can clear the saved game library.
- The embedded development keystore was removed. Debug builds use Android's default debug key; configure a private release key outside the project before publishing.
- Touch Sensy is a stored preference. Touch response commands can change Android settings only when the connected AeroHUB service and device firmware permit those settings; it cannot change the physical touchscreen controller's hardware sensitivity on every phone.

## In-game panel redesign (GameTurbo look)
Panel now follows the GameTurbo layout: rounded dark-navy panel with a separate game-icon strip, blue italic glow title, "Boost performance" card with bevelled corner and solid blue Boost button, Clear memory / Free up storage tiles, one bordered tools container (Screenshot, Record, DND, Settings + scrollable FPS/Mode), and a bottom row with Facebook and YouTube tiles (tap = own floating web window: drag top bar to move, bottom-right corner to resize, drag down to the X at the bottom to close) and a grey Timer tile. Code: `OverlayService.buildPanel()`, `TurboFrame`.

## নতুন tools (Monitor, Gesture lock, Awake, Block)
In-game panel এর tools strip এ ৪টি নতুন tool (লং-প্রেস করে জায়গা বদলানো যায়)। সবগুলো গেম স্ক্রিনে থাকলে চালু হয়, গেম থেকে বের হলে ফোনের আগের সেটিং ফিরে আসে।
- **Monitor:** ছোট touch-through readout: CPU %, free RAM, ব্যাটারি % ও তাপমাত্রা, ping (8.8.8.8)। AeroHUB লাগে।
- **Gesture lock:** `back_gesture_inset_scale_left/right` 0 করে কিনারার back জেসচার বন্ধ + উপরের কিনারায় 10dp touch-guard (shade নামা আটকানোর best effort)। ফোন ভেদে কাজ ভিন্ন হতে পারে।
- **Awake:** স্ক্রিন জাগিয়ে রাখে ও auto-brightness বন্ধ করে (brightness যেমন আছে তেমন থাকে)।
- **Block:** চাপলে ঘোরে: Block (বন্ধ) > No popup (heads-up নোটিফিকেশন বন্ধ) > No calls (popup বন্ধ + ইনকামিং কল auto-reject)।
কোড: `OverlayService.applyExtras()`, `applyMonitor()`, `applyGuard()`, `applyAwake()`।


## Floating app list (নতুন)
In-game panel এর বাম স্ট্রিপে এখন আপনার যোগ করা app দেখায় (প্রথমে খালি, শুধু + আইকন)। + চাপলে app list খোলে (গেম আগে, তারপর বাকি app); app চাপলে যোগ হয়, আবার চাপলে বাদ যায়। স্ট্রিপের app আইকনে চাপলে floating window তে খোলে, লং-প্রেসে ফুলস্ক্রিনে। app বেশি হলে স্ট্রিপ স্ক্রল করে, + সবসময় সর্বশেষ app এর নিচে। কোড: `OverlayService.buildPanel()`, `showAppPicker()`।

- DND tool now uses a real Priority-mode DND that allows media/system/alarms (media is never muted); original DND settings restored on off. Code: `Dnd` in Shell.kt.
